# The Stem Array / Gaṇḍavyūha — Technosutra visual novel.
# Generated from chapters.json by tools/generate_renpy_script.py.
# Detailed, source-grounded Portuguese adaptation of all 56 chapters, based on the complete supplied PDF.
# All VN dialogue is newly written adaptation, not a quotation or claim of canonical wording.
# Player choices are optional reflections and reconverge; quizzes are original learning activities.
# Translation: Peter Alan Roberts; editor: Emily Bower; source: 84000, Toh 44–45.
# Adaptation permission was separately confirmed by the project owner.
# Original chapter environments; no Google Street View imagery or derivatives are used.

define narrator = Character("Narrador")
define speaker_001 = Character("Mañjuśrī")
define speaker_002 = Character("Buddha")
define speaker_003 = Character("Vairocanapraṇidhānanābhiraśmiprabha")
define speaker_004 = Character("Duryodhanavīryavegarāja")
define speaker_005 = Character("Śāriputra")
define speaker_006 = Character("Samantaśrīsamudgatatejorāja")
define speaker_007 = Character("Dharmadhātupraṇidhitalanirbheda")
define speaker_008 = Character("Samantabhadra")
define speaker_009 = Character("Bodhisattva da assembleia")
define speaker_010 = Character("Bhagavat")
define speaker_011 = Character("Monge")
define speaker_012 = Character("Sudhana")
define speaker_013 = Character("Meghaśrī")
define speaker_014 = Character("Sāgaramegha")
define speaker_015 = Character("Supratiṣṭhita")
define speaker_016 = Character("Megha")
define speaker_017 = Character("Muktaka")
define speaker_018 = Character("Sāgaradhvaja")
define speaker_019 = Character("Āśā")
define speaker_020 = Character("Bhīṣmottaranirghoṣa")
define speaker_021 = Character("Jovem brâmane")
define speaker_022 = Character("Jayoṣmāyatana")
define speaker_023 = Character("Brahmās")
define speaker_024 = Character("Māras")
define speaker_025 = Character("Śakras")
define speaker_026 = Character("Nāgas")
define speaker_027 = Character("Garuḍas")
define speaker_028 = Character("Kinnaras")
define speaker_029 = Character("Devas do reino do desejo")
define speaker_030 = Character("Pessoa entre a multidão")
define speaker_031 = Character("Maitrayaṇī")
define speaker_032 = Character("Sudarśana")
define speaker_033 = Character("Seres celestiais")
define speaker_034 = Character("Indriyeśvara")
define speaker_035 = Character("Prabhūtā")
define speaker_036 = Character("Vidvān")
define speaker_037 = Character("Ratnacūḍa")
define speaker_038 = Character("Samantanetra")
define speaker_039 = Character("Moradores de Tāladhvaja")
define speaker_040 = Character("Devas")
define speaker_041 = Character("Anala")
define speaker_042 = Character("Moradores de Suprabha")
define speaker_043 = Character("Mahāprabha")
define speaker_044 = Character("Devas bodhisattvas")
define speaker_045 = Character("Acalā")
define speaker_046 = Character("Sarvagamin")
define speaker_047 = Character("Utpalabhūti")
define speaker_048 = Character("Vaira")
define speaker_049 = Character("Jayottama")
define speaker_050 = Character("Chefe de família")
define speaker_051 = Character("Siṃhavijṛmbhitā")
define speaker_052 = Character("Morador cético")
define speaker_053 = Character("Morador que conhece Vasumitrā")
define speaker_054 = Character("Vasumitrā")
define speaker_055 = Character("Veṣṭhila")
define speaker_056 = Character("Avalokiteśvara")
define speaker_057 = Character("Ananyagāmin")
define speaker_058 = Character("Mahādeva")
define speaker_059 = Character("Deusas da terra")
define speaker_060 = Character("Sthāvarā")
define speaker_061 = Character("Vāsantī")
define speaker_062 = Character("Samantagambhīraśrīvimalaprabhā")
define speaker_063 = Character("Pramuditanayanajagadvirocanā")
define speaker_064 = Character("Samantasattvatrāṇojaḥśrī")
define speaker_065 = Character("Praśantarutasāgaravatī")
define speaker_066 = Character("Sarvanagararakṣāsaṃbhavatejaḥśrī")
define speaker_067 = Character("Sarvavṛkṣpraphullanasukhasaṃvāsā")
define speaker_068 = Character("Rei Sarvadharmanirnādacchatramaṇḍalanirghoṣa")
define speaker_069 = Character("Ratnaprabhā")
define speaker_070 = Character("Sarvajagadrakṣāpraṇidhānavīryaprabhā")
define speaker_071 = Character("Vijitāvin")
define speaker_072 = Character("Jayaprabha")
define speaker_073 = Character("Mãe de Vijitāvin")
define speaker_074 = Character("Sutejomaṇḍalaratiśrī")
define speaker_075 = Character("Aśokaśrī")
define speaker_076 = Character("Gopā")
define speaker_077 = Character("Sudarśanā")
define speaker_078 = Character("Tejodhipati")
define speaker_079 = Character("Sucalitaratiprabhāsaśrī")
define speaker_080 = Character("Ratnanetrā")
define speaker_081 = Character("Sunetra")
define speaker_082 = Character("Māyādevī")
define speaker_083 = Character("Surendrābhā")
define speaker_084 = Character("Viśvāmitra")
define speaker_085 = Character("Śilpābhijña")
define speaker_086 = Character("Bhadrottamā")
define speaker_087 = Character("Muktāsāra")
define speaker_088 = Character("Sucandra")
define speaker_089 = Character("Ajitasena")
define speaker_090 = Character("Śivarāgra")
define speaker_091 = Character("Śrīsaṃbhava")
define speaker_092 = Character("Śrīmati")
define speaker_093 = Character("Maitreya")
define speaker_094 = Character("Mañjuśrī Kumārabhūta")

image bg_intro_scene = "images/bg_intro_scene.jpg"
image bg_ch01 = "images/optimized/bg_ch01.jpg"
image bg_ch02 = "images/optimized/bg_ch02.jpg"
image bg_ch03 = "images/optimized/bg_ch03.jpg"
image bg_ch04 = "images/optimized/bg_ch04.jpg"
image bg_ch05 = "images/optimized/bg_ch05.jpg"
image bg_ch06 = "images/optimized/bg_ch06.jpg"
image bg_ch07 = "images/optimized/bg_ch07.jpg"
image bg_ch08 = "images/optimized/bg_ch08.jpg"
image bg_ch09 = "images/optimized/bg_ch09.jpg"
image bg_ch10 = "images/optimized/bg_ch10.jpg"
image bg_ch11 = "images/optimized/bg_ch11.jpg"
image bg_ch12 = "images/optimized/bg_ch12.jpg"
image bg_ch13 = "images/optimized/bg_ch13.jpg"
image bg_ch14 = "images/optimized/bg_ch14.jpg"
image bg_ch15 = "images/optimized/bg_ch15.jpg"
image bg_ch16 = "images/optimized/bg_ch16.jpg"
image bg_ch17 = "images/optimized/bg_ch17.jpg"
image bg_ch18 = "images/optimized/bg_ch18.jpg"
image bg_ch19 = "images/optimized/bg_ch19.jpg"
image bg_ch20 = "images/optimized/bg_ch20.jpg"
image bg_ch21 = "images/optimized/bg_ch21.jpg"
image bg_ch22 = "images/optimized/bg_ch22.jpg"
image bg_ch23 = "images/optimized/bg_ch23.jpg"
image bg_ch24 = "images/optimized/bg_ch24.jpg"
image bg_ch25 = "images/optimized/bg_ch25.jpg"
image bg_ch26 = "images/optimized/bg_ch26.jpg"
image bg_ch27 = "images/optimized/bg_ch27.jpg"
image bg_ch28 = "images/optimized/bg_ch28.jpg"
image bg_ch29 = "images/optimized/bg_ch29.jpg"
image bg_ch30 = "images/optimized/bg_ch30.jpg"
image bg_ch31 = "images/optimized/bg_ch31.jpg"
image bg_ch32 = "images/optimized/bg_ch32.jpg"
image bg_ch33 = "images/optimized/bg_ch33.jpg"
image bg_ch34 = "images/optimized/bg_ch34.jpg"
image bg_ch35 = "images/optimized/bg_ch35.jpg"
image bg_ch36 = "images/optimized/bg_ch36.jpg"
image bg_ch37 = "images/optimized/bg_ch37.jpg"
image bg_ch38 = "images/optimized/bg_ch38.jpg"
image bg_ch39 = "images/optimized/bg_ch39.jpg"
image bg_ch40 = "images/optimized/bg_ch40.jpg"
image bg_ch41 = "images/optimized/bg_ch41.jpg"
image bg_ch42 = "images/optimized/bg_ch42.jpg"
image bg_ch43 = "images/optimized/bg_ch43.jpg"
image bg_ch44 = "images/optimized/bg_ch44.jpg"
image bg_ch45 = "images/optimized/bg_ch45.jpg"
image bg_ch46 = "images/optimized/bg_ch46.jpg"
image bg_ch47 = "images/optimized/bg_ch47.jpg"
image bg_ch48 = "images/optimized/bg_ch48.jpg"
image bg_ch49 = "images/optimized/bg_ch49.jpg"
image bg_ch50 = "images/optimized/bg_ch50.jpg"
image bg_ch51 = "images/optimized/bg_ch51.jpg"
image bg_ch52 = "images/optimized/bg_ch52.jpg"
image bg_ch53 = "images/optimized/bg_ch53.jpg"
image bg_ch54 = "images/optimized/bg_ch54.jpg"
image bg_ch55 = "images/optimized/bg_ch55.jpg"
image bg_ch56 = "images/optimized/bg_ch56.jpg"
image master_ch01_provisional = "images/masters/sprites/provisional/master_ch01_provisional.png"
image master_ch02_provisional = "images/masters/sprites/provisional/master_ch02_provisional.png"
image master_ch03_provisional = "images/masters/sprites/provisional/master_ch03_provisional.png"
image master_ch04_provisional = "images/masters/sprites/provisional/master_ch04_provisional.png"
image master_ch05_provisional = "images/masters/sprites/provisional/master_ch05_provisional.png"
image master_ch06_provisional = "images/masters/sprites/provisional/master_ch06_provisional.png"
image master_ch07_provisional = "images/masters/sprites/provisional/master_ch07_provisional.png"
image master_ch08_provisional = "images/masters/sprites/provisional/master_ch08_provisional.png"
image master_ch09_provisional = "images/masters/sprites/provisional/master_ch09_provisional.png"
image master_ch10_provisional = "images/masters/sprites/provisional/master_ch10_provisional.png"
image master_ch11_provisional = "images/masters/sprites/provisional/master_ch11_provisional.png"
image master_ch12_provisional = "images/masters/sprites/provisional/master_ch12_provisional.png"
image master_ch13_provisional = "images/masters/sprites/provisional/master_ch13_provisional.png"
image master_ch14_provisional = "images/masters/sprites/provisional/master_ch14_provisional.png"
image master_ch15_provisional = "images/masters/sprites/provisional/master_ch15_provisional.png"
image master_ch16_provisional = "images/masters/sprites/provisional/master_ch16_provisional.png"
image master_ch17_provisional = "images/masters/sprites/provisional/master_ch17_provisional.png"
image master_ch18_provisional = "images/masters/sprites/provisional/master_ch18_provisional.png"
image master_ch19_provisional = "images/masters/sprites/provisional/master_ch19_provisional.png"
image master_ch20_provisional = "images/masters/sprites/provisional/master_ch20_provisional.png"
image master_ch21_provisional = "images/masters/sprites/provisional/master_ch21_provisional.png"
image master_ch22_provisional = "images/masters/sprites/provisional/master_ch22_provisional.png"
image master_ch23_provisional = "images/masters/sprites/provisional/master_ch23_provisional.png"
image master_ch24_provisional = "images/masters/sprites/provisional/master_ch24_provisional.png"
image master_ch25_provisional = "images/masters/sprites/provisional/master_ch25_provisional.png"
image master_ch26_provisional = "images/masters/sprites/provisional/master_ch26_provisional.png"
image master_ch27_provisional = "images/masters/sprites/provisional/master_ch27_provisional.png"
image master_ch28_provisional = "images/masters/sprites/provisional/master_ch28_provisional.png"
image master_ch29_provisional = "images/masters/sprites/provisional/master_ch29_provisional.png"
image master_ch30_provisional = "images/masters/sprites/provisional/master_ch30_provisional.png"
image master_ch31_provisional = "images/masters/sprites/provisional/master_ch31_provisional.png"
image master_ch32_provisional = "images/masters/sprites/provisional/master_ch32_provisional.png"
image master_ch33_provisional = "images/masters/sprites/provisional/master_ch33_provisional.png"
image master_ch34_provisional = "images/masters/sprites/provisional/master_ch34_provisional.png"
image master_ch35_provisional = "images/masters/sprites/provisional/master_ch35_provisional.png"
image master_ch36_provisional = "images/masters/sprites/provisional/master_ch36_provisional.png"
image master_ch37_provisional = "images/masters/sprites/provisional/master_ch37_provisional.png"
image master_ch38_provisional = "images/masters/sprites/provisional/master_ch38_provisional.png"
image master_ch39_provisional = "images/masters/sprites/provisional/master_ch39_provisional.png"
image master_ch40_provisional = "images/masters/sprites/provisional/master_ch40_provisional.png"
image master_ch41_provisional = "images/masters/sprites/provisional/master_ch41_provisional.png"
image master_ch42_provisional = "images/masters/sprites/provisional/master_ch42_provisional.png"
image master_ch44_provisional = "images/masters/sprites/provisional/master_ch44_provisional.png"
image master_ch45_provisional = "images/masters/sprites/provisional/master_ch45_provisional.png"
image master_ch46_provisional = "images/masters/sprites/provisional/master_ch46_provisional.png"
image master_ch47_provisional = "images/masters/sprites/provisional/master_ch47_provisional.png"
image master_ch48_provisional = "images/masters/sprites/provisional/master_ch48_provisional.png"
image master_ch49_provisional = "images/masters/sprites/provisional/master_ch49_provisional.png"
image master_ch50_provisional = "images/masters/sprites/provisional/master_ch50_provisional.png"
image master_ch51_provisional = "images/masters/sprites/provisional/master_ch51_provisional.png"
image master_ch53_provisional = "images/masters/sprites/provisional/master_ch53_provisional.png"
image master_ch54_provisional = "images/masters/sprites/provisional/master_ch54_provisional.png"
image master_ch55_provisional = "images/masters/sprites/provisional/master_ch55_provisional.png"
image master_ch56_provisional = "images/masters/sprites/provisional/master_ch56_provisional.png"

# Temporary static portraits from raw transparent captures; no animation or lip-sync.
transform master_provisional_portrait:
    xalign 0.84
    yalign 1.0
    zoom 0.8

screen master_provisional_badge():
    zorder 10
    frame:
        xalign 0.02
        yalign 0.04
        xpadding 18
        ypadding 10
        background Solid("#101326ee")
        vbox:
            spacing 3
            text "PROVISÓRIO" size 24 color "#ffd35a" bold True
            text "render frontal estático · sem fundo" size 16 color "#edf1ff"

label start:
    hide screen master_provisional_badge
    scene bg_intro_scene with fade
    centered "The Stem Array — visual novel"
    narrator "Esta abertura usa um cenário original independente. A imagem enviada pelo projeto não foi incluída porque sua origem ainda precisa ser confirmada."
    narrator "As cenas recontam os capítulos com base no texto integral autorizado. As falas da VN são criações de adaptação, não citações da tradução."
    menu:
        "Galeria de renders provisórios":
            jump technosutra_master_gallery
        "Começar a jornada — capítulo 1":
            jump chapter_01
        "Abrir o índice de capítulos":
            jump chapter_index
        "Encerrar":
            return

label chapter_index:
    hide screen master_provisional_badge
    scene bg_ch01 with dissolve
    centered "The Stem Array — índice de capítulos"
    menu:
        "Capítulos 1–10":
            jump chapter_group_01
        "Capítulos 11–20":
            jump chapter_group_11
        "Capítulos 21–30":
            jump chapter_group_21
        "Capítulos 31–40":
            jump chapter_group_31
        "Capítulos 41–50":
            jump chapter_group_41
        "Capítulos 51–56":
            jump chapter_group_51
        "Começar do início":
            jump chapter_01
        "Voltar à abertura":
            jump start

label chapter_group_01:
    scene bg_ch01 with dissolve
    centered "Capítulos 1–10"
    menu:
        "Capítulo 1 — The Setting":
            jump chapter_01
        "Capítulo 2 — Samantabhadra":
            jump chapter_02
        "Capítulo 3 — Mañjuśrī":
            jump chapter_03
        "Capítulo 4 — Meghaśrī":
            jump chapter_04
        "Capítulo 5 — Sāgaramegha":
            jump chapter_05
        "Capítulo 6 — Supratiṣṭhita":
            jump chapter_06
        "Capítulo 7 — Megha":
            jump chapter_07
        "Capítulo 8 — Muktaka":
            jump chapter_08
        "Capítulo 9 — Sāgaradhvaja":
            jump chapter_09
        "Capítulo 10 — Āśā":
            jump chapter_10
        "Voltar ao índice":
            jump chapter_index

label chapter_group_11:
    scene bg_ch11 with dissolve
    centered "Capítulos 11–20"
    menu:
        "Capítulo 11 — Bhīṣmottaranirghoṣa":
            jump chapter_11
        "Capítulo 12 — Jayoṣmāyatana":
            jump chapter_12
        "Capítulo 13 — Maitrayaṇī":
            jump chapter_13
        "Capítulo 14 — Sudarśana":
            jump chapter_14
        "Capítulo 15 — Indriyeśvara":
            jump chapter_15
        "Capítulo 16 — Prabhūtā":
            jump chapter_16
        "Capítulo 17 — Vidvān":
            jump chapter_17
        "Capítulo 18 — Ratnacūḍa":
            jump chapter_18
        "Capítulo 19 — Samantanetra":
            jump chapter_19
        "Capítulo 20 — Anala":
            jump chapter_20
        "Voltar ao índice":
            jump chapter_index

label chapter_group_21:
    scene bg_ch21 with dissolve
    centered "Capítulos 21–30"
    menu:
        "Capítulo 21 — Mahāprabha":
            jump chapter_21
        "Capítulo 22 — Acalā":
            jump chapter_22
        "Capítulo 23 — Sarvagamin":
            jump chapter_23
        "Capítulo 24 — Utpalabhūti":
            jump chapter_24
        "Capítulo 25 — Vaira":
            jump chapter_25
        "Capítulo 26 — Jayottama":
            jump chapter_26
        "Capítulo 27 — Siṃhavijṛmbhitā":
            jump chapter_27
        "Capítulo 28 — Vasumitrā":
            jump chapter_28
        "Capítulo 29 — Veṣṭhila":
            jump chapter_29
        "Capítulo 30 — Avalokiteśvara":
            jump chapter_30
        "Voltar ao índice":
            jump chapter_index

label chapter_group_31:
    scene bg_ch31 with dissolve
    centered "Capítulos 31–40"
    menu:
        "Capítulo 31 — Ananyagāmin":
            jump chapter_31
        "Capítulo 32 — Mahādeva":
            jump chapter_32
        "Capítulo 33 — Sthāvarā":
            jump chapter_33
        "Capítulo 34 — Vāsantī":
            jump chapter_34
        "Capítulo 35 — Samantagambhīraśrīvimalaprabhā":
            jump chapter_35
        "Capítulo 36 — Pramuditanayanajagadvirocanā":
            jump chapter_36
        "Capítulo 37 — Samantasattvatrāṇojaḥśrī":
            jump chapter_37
        "Capítulo 38 — Praśantarutasāgaravatī":
            jump chapter_38
        "Capítulo 39 — Sarvanagararakṣāsaṃbhavatejaḥśrī":
            jump chapter_39
        "Capítulo 40 — Sarvavṛkṣpraphullanasukhasaṃvāsā":
            jump chapter_40
        "Voltar ao índice":
            jump chapter_index

label chapter_group_41:
    scene bg_ch41 with dissolve
    centered "Capítulos 41–50"
    menu:
        "Capítulo 41 — Sarvajagadrakṣāpraṇidhānavīryaprabhā":
            jump chapter_41
        "Capítulo 42 — Sutejomaṇḍalaratiśrī":
            jump chapter_42
        "Capítulo 43 — Gopā":
            jump chapter_43
        "Capítulo 44 — Māyādevī":
            jump chapter_44
        "Capítulo 45 — Surendrābhā":
            jump chapter_45
        "Capítulo 46 — Viśvāmitra":
            jump chapter_46
        "Capítulo 47 — Śilpābhijña":
            jump chapter_47
        "Capítulo 48 — Bhadrottamā":
            jump chapter_48
        "Capítulo 49 — Muktāsāra":
            jump chapter_49
        "Capítulo 50 — Sucandra":
            jump chapter_50
        "Voltar ao índice":
            jump chapter_index

label chapter_group_51:
    scene bg_ch51 with dissolve
    centered "Capítulos 51–56"
    menu:
        "Capítulo 51 — Ajitasena":
            jump chapter_51
        "Capítulo 52 — Śivarāgra":
            jump chapter_52
        "Capítulo 53 — Śrīsaṃbhava and Śrīmati":
            jump chapter_53
        "Capítulo 54 — Maitreya":
            jump chapter_54
        "Capítulo 55 — Mañjuśrī":
            jump chapter_55
        "Capítulo 56 — Samantabhadra and “The Prayer for Completely Good Conduct”":
            jump chapter_56
        "Voltar ao índice":
            jump chapter_index

label chapter_01:
    hide screen master_provisional_badge
    scene bg_ch01 with dissolve
    show master_ch01_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 1 — The Setting"
    centered "Cena 1 — A assembleia em Jetavana"
    narrator "Em Śrāvastī, o Bhagavat está em Jetavana acompanhado por Samantabhadra, Mañjuśrī e uma grande assembleia de bodhisattvas. O texto conta cinco mil bodhisattvas, cujas qualidades incluem conduta e aspirações vastas, presença junto aos tathāgatas e sabedoria que alcança os limites do espaço. Há também quinhentos śrāvakas dotados de poderes milagrosos. Diante do domínio inconcebível do Tathāgata, os presentes reconhecem que seres comuns não o compreenderiam sem bênção, mérito, fé e orientação de um bom amigo espiritual. Pedem ao Bhagavat que ensine sobre a trajetória dos bodhisattvas, a iluminação e os meios de guiar os seres. Sudhana não está nesta cena nem aparece no capítulo."
    narrator "A assembleia reúne seres com capacidades e níveis de compreensão distintos."
    speaker_001 "Que o ensinamento alcance os seres conforme suas diferentes aspirações e faculdades."
    centered "Cena 2 — O samādhi e a transformação do bosque"
    narrator "Conhecendo os pensamentos da assembleia, o Bhagavat repousa no samādhi chamado “Leão de Boca Aberta”, associado à grande compaixão. Surge um kūṭāgāra imenso e adornado, sem centro ou limite discernível, com estandartes de vajra, joias, flores, pilares, pórticos e escadarias luminosas. Jetavana recebe rios perfumados, lótus, palácios, sons de louvor e assentos de leão. O texto atribui essa transformação às qualidades, ao mérito e ao poder inconcebível do Tathāgata, incluindo manifestações que mostram muitos mundos em um só corpo ou átomo. Por seu poder, os mundos nas dez direções também se purificam e se adornam como Jetavana."
    narrator "O samādhi é apresentado como vasto e ligado à grande compaixão."
    speaker_002 "Que esta manifestação torne visível a amplitude do campo búdico."
    centered "Cena 3 — As assembleias das dez direções"
    narrator "Do leste, sul, oeste, norte, direções intermediárias, acima e abaixo, chegam bodhisattvas acompanhados por comitivas tão numerosas quanto átomos em incontáveis mundos búdicos. Entre os líderes nomeados estão Vairocanapraṇidhānanābhiraśmiprabha, Duryodhanavīryavegarāja e Dharmadhātupraṇidhitalanirbheda. Cada grupo manifesta adornos próprios — flores, perfumes, joias, tecidos, luzes, imagens ou sons que evocam as práticas e os ensinamentos dos tathāgatas. Os visitantes aproximam-se do Bhagavat, prestam homenagem e emanam kūṭāgāras com tronos de leão e lótus; sentam-se neles. A reunião preenche Jetavana. O texto atribui as qualidades desses bodhisattvas à conduta excelente, às aspirações e às bênçãos dos tathāgatas."
    speaker_003 "Viemos de um mundo búdico distante para saudar o Bhagavat."
    speaker_004 "Que os adornos manifestados acompanhem nossa homenagem nesta assembleia."
    centered "Cena 4 — Ver o que a sabedoria alcança"
    narrator "Os grandes śrāvakas, entre eles Śāriputra, Maudgalyāyana e Mahākāśyapa, estão em Jetavana, mas não veem as manifestações do Buda nem a assembleia de bodhisattvas. O capítulo explica que a visão da sabedoria búdica não é a mesma que a dos śrāvakas e associa a capacidade de perceber esses milagres às raízes de mérito, à visão pura e à aspiração pela onisciência. Para esclarecer, compara a diferença a pessoas que não veem um rio como os outros, a quem dorme e sonha, ou a quem está vendado entre joias. São analogias explicativas, não novos acontecimentos ocorridos com a assembleia."
    narrator "Estar no mesmo lugar não significa perceber o mesmo campo de experiência."
    speaker_005 "A presença aqui não me faz ver aquilo que o texto descreve como domínio búdico."
    centered "Cena 5 — Versos sobre o inconcebível"
    narrator "Bodhisattvas de diferentes mundos voltam-se às dez direções e recitam versos. Vairocanapraṇidhānanābhiraśmiprabha e Duryodhanavīryavegarāja celebram as manifestações e a assembleia; outros, entre eles Samantaśrīsamudgatatejorāja e Asaṅgaśrīgarbharāja, expõem por imagens a sabedoria e a atividade inconcebíveis do Buda. Os versos afirmam que as palavras não esgotam esse domínio e destacam a aspiração, a fé, a compaixão e o benefício de ver o Tathāgata. Ao final, Dharmadhātupraṇidhitalanirbheda recita sobre o valor de ver e ouvir o Buda e sobre a remoção de dúvidas e obscuridades. O capítulo termina com essa exaltação; não narra uma visita de Sudhana a um mestre."
    speaker_006 "A sabedoria do Buda não cabe em medida comum; seus ensinamentos alcançam os seres no tempo apropriado."
    speaker_007 "Ver e ouvir o Buda é apresentado como fonte de mérito e clareza para os seres."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual reflexão você leva desta assembleia sobre a possibilidade de perceber as manifestações do Tathāgata?"
        "A percepção depende de condições como sabedoria e raízes de mérito.":
            narrator "Essa reflexão acompanha a explicação e as analogias do capítulo."
        "A simples presença física garante que todos vejam o mesmo.":
            narrator "O capítulo contrasta presença compartilhada com percepções diferentes."
        "Os versos afirmam que as palavras descrevem por completo o domínio búdico.":
            narrator "Os versos ressaltam que esse domínio ultrapassa a descrição comum."
    call quiz_ch01
    menu:
        "Continuar — capítulo 2":
            jump chapter_02
        "Voltar ao índice":
            jump chapter_index

label quiz_ch01:
    centered "Lembrança do samādhi"
    narrator "Escolha a resposta apoiada explicitamente pelo capítulo. Esta atividade é não canônica e não altera a narrativa."
    while True:
        menu:
            "Em qual samādhi o Bhagavat repousa antes da transformação de Jetavana?"
            "No samādhi chamado “Leão de Boca Aberta”.":
                if 0 == 0:
                    narrator "Correto: o capítulo nomeia o samādhi “Leão de Boca Aberta”."
                    return
                else:
                    narrator "Releia a passagem em que o Bhagavat repousa em meditação: o texto dá nome ao samādhi."
            "No samādhi chamado “Ilha das Joias”.":
                if 1 == 0:
                    narrator "Correto: o capítulo nomeia o samādhi “Leão de Boca Aberta”."
                    return
                else:
                    narrator "Releia a passagem em que o Bhagavat repousa em meditação: o texto dá nome ao samādhi."
            "No samādhi chamado “Olhos sem Mancha”.":
                if 2 == 0:
                    narrator "Correto: o capítulo nomeia o samādhi “Leão de Boca Aberta”."
                    return
                else:
                    narrator "Releia a passagem em que o Bhagavat repousa em meditação: o texto dá nome ao samādhi."

label chapter_02:
    hide screen master_provisional_badge
    scene bg_ch02 with dissolve
    show master_ch02_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 2 — Samantabhadra"
    centered "Cena 1 — O samādhi e seus dez modos"
    narrator "Samantabhadra volta-se à assembleia e ensina o samādhi do Tathāgata chamado Leão de Boca Aberta. Sua exposição organiza essa sabedoria por igualdades: do reino dos fenômenos com o espaço; dos três tempos; dos seres e dos mundos; do curso do karma; dos pensamentos e aspirações; das aparências, dos tempos de amadurecimento e das faculdades. Em dez modos, descreve manifestações de budas e seus ensinamentos através de mundos incontáveis, assembleias, emanações e rodas do Dharma. Ao concluir, indica que os ensinamentos desse samādhi são tão numerosos quanto átomos de incontáveis reinos de budas e pertencem ao campo de atividade da sabedoria dos tathāgatas."
    speaker_008 "Contemplem este samādhi por suas muitas igualdades: a vastidão dos fenômenos não se limita a um só mundo ou tempo."
    speaker_009 "Os dez modos apontam para manifestações e ensinamentos que atravessam incontáveis reinos."
    centered "Cena 2 — Uma visão que atravessa os mundos"
    narrator "Para firmar os bodhisattvas no samādhi, o Bhagavat emite da ūrṇā uma grande luz chamada Iluminação dos Três Tempos, acompanhada por raios incontáveis que iluminam reinos de budas nas dez direções. Os bodhisattvas reunidos em Jetavana veem mundos de nomes, cores e graus de purificação diversos. Neles, budas alcançam a iluminação, ensinam o Dharma e aparecem em diferentes domínios e comunidades. A assembleia contempla ainda manifestações de samādhi em direções incontáveis e percebe que as formas dos tathāgatas surgem de acordo com as aspirações dos seres. Suas percepções variam conforme raízes de mérito, ensinamentos ouvidos e samādhis acessados."
    speaker_010 "Que esta luz conduza a assembleia a contemplar a extensão dos reinos e das manifestações dos tathāgatas."
    speaker_009 "Em cada domínio, a percepção se abre de modo diverso, conforme as condições e aspirações dos seres."
    centered "Cena 3 — A assembleia reconhece os milagres"
    narrator "A fonte descreve os bodhisattvas reunidos diante do Bhagavat em Jetavana, sentados sobre lótus em tronos de leão. Eles percebem o oceano de milagres de Vairocana por numerosos samādhis, entre eles os que abrangem os três tempos, a compaixão pelos seres, a compreensão dos fenômenos e a presença de budas em incontáveis mundos. O texto enumera extensamente suas qualidades: grande compaixão, sabedoria, eloquência e capacidade de conduzir seres. Os bodhisattvas recordam milagres realizados no passado pelo Tathāgata e os compreendem em escala que permeia o reino dos fenômenos a cada instante da mente."
    speaker_009 "A visão dos milagres alcança muitos samādhis, sem se reduzir a uma única perspectiva."
    narrator "O capítulo associa essas realizações à sabedoria, à compaixão e ao benefício dos seres."
    centered "Cena 4 — Manifestações em Jetavana"
    narrator "Iluminados pelos raios do Tathāgata e tomados por grande alegria, os bodhisattvas fazem surgir manifestações que se estendem de Jetavana por todo o reino dos fenômenos. Há nuvens de luz, sinos preciosos, sons, louvores, imagens de budas, aspectos da conduta dos bodhisattvas e representações de reinos puros. Mañjuśrī contempla esses milagres e recita versos sobre sua vastidão, incluindo emanações que surgem de pelos, árvores, objetos sensoriais e poros dos tathāgatas. As imagens apresentam budas e bodhisattvas em muitos reinos; a cena reúne essas descrições como manifestações do poder miraculoso relatado no capítulo."
    speaker_001 "As manifestações que se espalham de Jetavana tornam visível a vastidão dos milagres descritos à assembleia."
    narrator "Os versos de Mañjuśrī contemplam as emanações e os reinos que aparecem em todas as direções."
    centered "Cena 5 — Emanações para orientar os seres"
    narrator "Sem se afastarem dos pés do Tathāgata, os bodhisattvas irradiam luz e emanações que alcançam seres nas dez direções, para inspirá-los, amadurecê-los e guiá-los conforme suas aspirações. O texto enumera caminhos de ensinamento ligados à conduta, às perfeições, à meditação, à sabedoria e à compreensão das capacidades e do karma dos seres. As emanações aparecem em diferentes domínios e podem assumir formas variadas — como ascetas, médicos, mercadores, discípulos ou pessoas hábeis em ofícios —, em lugares como vilas, cidades e capitais. O capítulo termina destacando essa atividade de condução, sem narrar uma visita de Sudhana a Samantabhadra."
    speaker_008 "A orientação descrita aqui se ajusta às aspirações e capacidades dos seres."
    narrator "As emanações aparecem em diferentes formas e lugares, enquanto os bodhisattvas permanecem junto ao Tathāgata."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o ensinamento de Samantabhadra, que aspecto você escolheria destacar?"
        "A igualdade entre os três tempos":
            narrator "Uma das perspectivas enumeradas na exposição do samādhi."
        "As diferentes formas de orientar os seres":
            narrator "O capítulo descreve emanações que aparecem em formas e lugares variados."
        "A relação entre visão e aspiração":
            narrator "A assembleia percebe aparições dos tathāgatas de acordo com as aspirações dos seres."
    call quiz_ch02
    menu:
        "Continuar — capítulo 3":
            jump chapter_03
        "Voltar ao índice":
            jump chapter_index

label quiz_ch02:
    centered "Recordação do ensinamento"
    narrator "Escolha a afirmação que corresponde ao texto do capítulo."
    while True:
        menu:
            "De onde o Bhagavat emite a grande luz chamada Iluminação dos Três Tempos?"
            "Da ūrṇā entre as sobrancelhas":
                if 0 == 0:
                    narrator "Correto: a luz emana da ūrṇā entre as sobrancelhas do Bhagavat."
                    return
                else:
                    narrator "Releia a passagem em que o Bhagavat emite a luz para firmar os bodhisattvas no samādhi."
            "Das árvores de Jetavana":
                if 1 == 0:
                    narrator "Correto: a luz emana da ūrṇā entre as sobrancelhas do Bhagavat."
                    return
                else:
                    narrator "Releia a passagem em que o Bhagavat emite a luz para firmar os bodhisattvas no samādhi."
            "Dos tronos de leão da assembleia":
                if 2 == 0:
                    narrator "Correto: a luz emana da ūrṇā entre as sobrancelhas do Bhagavat."
                    return
                else:
                    narrator "Releia a passagem em que o Bhagavat emite a luz para firmar os bodhisattvas no samādhi."

label chapter_03:
    hide screen master_provisional_badge
    scene bg_ch03 with dissolve
    show master_ch03_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 3 — Mañjuśrī"
    centered "Cena 1 — A partida para o sul"
    narrator "Mañjuśrī está acompanhado por bodhisattvas, vajrapāṇis e uma grande variedade de devas e outros seres, cujas aspirações incluem servir os budas, ouvir o Dharma, proteger seres e dissipar a ignorância. Ele presta homenagens e oferendas ao Buda, circunda-o e parte para a região sul. Pela bênção do Buda, Śāriputra o vê partir e pede autorização para segui-lo. Com a permissão recebida, deixa Jetavana conduzindo sessenta monges recém-renunciantes, entre eles Sāgarabuddhi. No caminho, Śāriputra chama a atenção dos monges para Mañjuśrī e começa a descrever a presença e as manifestações associadas ao seu percurso."
    speaker_005 "Mañjuśrī segue para o sul; peço licença para acompanhá-lo com estes monges."
    speaker_005 "Sāgarabuddhi, observa o caminho e a presença do bodhisattva enquanto avançamos."
    centered "Cena 2 — O caminho que inspira os monges"
    narrator "Śāriputra descreve o corpo puro de Mañjuśrī, adornado pelas marcas de um grande ser, e a luz que dele irradia, levando alegria a incontáveis seres e encerrando sofrimentos. Fala das manifestações de mérito que se estendem pelas direções e das oferendas que surgem junto às árvores, bem como das luzes dos tathāgatas que descem sobre a cabeça do bodhisattva. Quanto mais Śāriputra enumera essas qualidades, mais os monges se purificam e se alegram: sua fé e compaixão crescem, e eles se voltam ao Dharma do Buda. Inspirados, expressam o desejo de estar diante de Mañjuśrī."
    speaker_005 "Contemplem como a luz e o mérito de Mañjuśrī alcançam seres em todas as direções."
    speaker_011 "Ouvindo sobre essas qualidades, desejo vê-lo e seguir a aspiração ao despertar."
    centered "Cena 3 — Dez motivações perseverantes"
    narrator "Os monges reverenciam Mañjuśrī e desejam tornar-se semelhantes a ele. Mañjuśrī ensina dez motivações perseverantes: ver, honrar, oferecer e servir a todos os tathāgatas; nunca abandonar as raízes de mérito; buscar todos os Dharmas; praticar as perfeições e realizar as samādhis dos bodhisattvas; entrar em todos os tempos sucessivos; purificar os campos de buda; amadurecer e guiar os seres; praticar a conduta do bodhisattva em todos os domínios e eras; e realizar uma capacidade dos tathāgatas ao amadurecer seres por meio das perfeições. A fé nessas motivações conduz às qualidades do caminho dos tathāgatas. Os monges alcançam a samādhi da visão desimpedida de todos os budas e são estabelecidos na conduta completamente boa."
    speaker_001 "Perseverem no serviço aos budas, na busca do Dharma e na prática que beneficia os seres."
    speaker_011 "O ensinamento abriu nossa visão para os budas e para a vastidão dos seres."
    centered "Cena 4 — O bosque sagrado e o ensinamento aos nāgas"
    narrator "Após estabelecer os monges na aspiração à iluminação completa, Mañjuśrī viaja a Dhanyākara e segue com sua comitiva para o bosque Vicitrasāladhvajavyūha, lugar consagrado pelos tathāgatas e associado à prática passada de generosidade do Buda. Ali ensina o sūtra chamado A Radiância do Caminho da Essência dos Fenômenos. Durante o ensinamento, incontáveis nāgas chegam do grande oceano. Ao ouvi-lo, muitos se desencantam com a existência como nāgas e aspiram às qualidades de um tathāgata; deixam essa existência e renascem como devas ou humanos. Dez mil nāgas alcançam irreversibilidade na aspiração à iluminação completa, e seres de incontáveis reinos são guiados pelos três yānas."
    speaker_001 "Neste lugar sagrado, apresento o caminho do Dharma aos seres que vieram ouvi-lo."
    narrator "Entre os ouvintes vindos do grande oceano, muitos nāgas voltaram sua aspiração às qualidades dos tathāgatas."
    centered "Cena 5 — Sudhana encontra Mañjuśrī"
    narrator "Ao saberem da chegada de Mañjuśrī, habitantes de Dhanyākara vão ao bosque em grupos: upāsakas, upāsikās, filhos e filhas, cada grupo acompanhado por comitivas de quinhentas pessoas. Entre os jovens está Sudhana, filho de um grande mercador. Mañjuśrī explica que seu nome, “Excelente Riqueza”, foi dado porque, desde sua concepção e nascimento, apareceram brotos preciosos, tesouros e abundância de bens. Também reconhece nele raízes de mérito, vasta aspiração, ações irrepreensíveis e vontade de seguir bons amigos espirituais. Mañjuśrī ensina à assembleia sobre o Dharma e as qualidades dos budas, orientando os presentes segundo suas aspirações e encorajando-os à iluminação completa."
    speaker_001 "Sudhana, tua aspiração e tua disposição para seguir bons amigos espirituais são dignas de ser cultivadas."
    speaker_012 "Quero compreender o caminho dos budas e avançar na conduta do bodhisattva."
    centered "Cena 6 — O louvor e o pedido de orientação"
    narrator "Depois que Mañjuśrī parte, Sudhana, inspirado pelo que ouviu sobre a grandeza e as qualidades dos budas, aspira à iluminação completa e o segue, recitando louvores. Em imagens poéticas, apresenta o mundo condicionado como uma cidade obscurecida pela ignorância e consumida pelas aflições; pede que a sabedoria e a compaixão do mestre lhe mostrem a saída. Também solicita orientação sobre o caminho e o veículo da iluminação, evocando aspiração, paciência, fé, amor, discernimento e compaixão. Mañjuśrī acolhe a aspiração e ensina que servir, acompanhar e honrar um bom amigo espiritual é base e causa correspondente para alcançar a onisciência. Sudhana então formula suas perguntas sobre como treinar, praticar e aperfeiçoar a conduta do bodhisattva."
    speaker_012 "Mestre, desejo aprender como começar, praticar e aperfeiçoar a conduta do bodhisattva."
    speaker_001 "Não te canses de servir e honrar um bom amigo espiritual: isso sustenta a busca da onisciência."
    centered "Cena 7 — A conduta completamente boa e o próximo mestre"
    narrator "Mañjuśrī responde em versos sobre a aspiração de beneficiar e liberar todos os seres, a prática da conduta completamente boa por eras incontáveis e a visão dos budas nas dez direções. Acrescenta que são raros os que, tendo aspirado à iluminação completa, também procuram a conduta do bodhisattva. Por isso, devem obter compreensão segura com bons amigos espirituais, procurá-los sem cansaço, acolher seus ensinamentos e não se irritar com seus métodos hábeis. Mañjuśrī então dá a Sudhana uma orientação concreta: na região sul de Rāmāvarānta, no monte Sugrīva, vive o bhikṣu Meghaśrī. Sudhana deve perguntar-lhe como se treina e aperfeiçoa a conduta completamente boa; esse mestre lhe ensinará seu domínio."
    speaker_001 "Procura Meghaśrī no monte Sugrīva e pergunta-lhe sobre a conduta completamente boa."
    speaker_012 "Seguirei a orientação e buscarei compreender essa conduta com o próximo bom amigo espiritual."
    centered "Cena 8 — A despedida"
    narrator "Cheio de alegria pelo ensinamento e pela orientação recebida, Sudhana inclina a cabeça aos pés de Mañjuśrī e o circunda muitas centenas de milhares de vezes, mantendo-o à sua direita. Enquanto se afasta, volta repetidamente o olhar para o mestre. A narrativa destaca seu apego reverente ao bom amigo espiritual: Sudhana não suporta facilmente deixar de vê-lo, e parte com o rosto coberto de lágrimas. Assim termina o encontro com Mañjuśrī; a instrução para procurar Meghaśrī permanece como o próximo passo de sua busca, sem que o capítulo narre ainda esse encontro."
    speaker_012 "Parto levando comigo tua orientação e a determinação de buscar a conduta do bodhisattva."
    narrator "Com reverência e lágrimas, Sudhana se afasta de Mañjuśrī para seguir a instrução recebida."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual ensinamento deste capítulo você escolheria levar como reflexão para a jornada de Sudhana?"
        "A busca perseverante de bons amigos espirituais":
            narrator "Uma reflexão coerente com a orientação de Mañjuśrī: buscar e ouvir bons amigos sem se cansar."
        "A prática das perfeições em benefício dos seres":
            narrator "Uma reflexão coerente com as motivações e a conduta ensinadas aos monges e a Sudhana."
        "A contemplação das dez direções":
            narrator "Uma reflexão ligada à visão dos budas nas dez direções descrita no capítulo."
    call quiz_ch03
    menu:
        "Continuar — capítulo 4":
            jump chapter_04
        "Voltar ao índice":
            jump chapter_index

label quiz_ch03:
    centered "Próximo bom amigo"
    narrator "Escolha a resposta correta com base no capítulo."
    while True:
        menu:
            "A quem Mañjuśrī orienta Sudhana a procurar em seguida, e onde essa pessoa vive?"
            "Ao bhikṣu Meghaśrī, no monte Sugrīva, em Rāmāvarānta.":
                if 0 == 0:
                    narrator "Correto: Mañjuśrī envia Sudhana a Meghaśrī, no monte Sugrīva, em Rāmāvarānta."
                    return
                else:
                    narrator "Relembre a orientação final de Mañjuśrī: ela nomeia um bhikṣu e um monte na região sul."
            "Ao upāsaka Mahāprajña, em Dhanyākara.":
                if 1 == 0:
                    narrator "Correto: Mañjuśrī envia Sudhana a Meghaśrī, no monte Sugrīva, em Rāmāvarānta."
                    return
                else:
                    narrator "Relembre a orientação final de Mañjuśrī: ela nomeia um bhikṣu e um monte na região sul."
            "Ao bhikṣu Sāgarabuddhi, em Jetavana.":
                if 2 == 0:
                    narrator "Correto: Mañjuśrī envia Sudhana a Meghaśrī, no monte Sugrīva, em Rāmāvarānta."
                    return
                else:
                    narrator "Relembre a orientação final de Mañjuśrī: ela nomeia um bhikṣu e um monte na região sul."

label chapter_04:
    hide screen master_provisional_badge
    scene bg_ch04 with dissolve
    show master_ch04_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 4 — Meghaśrī"
    centered "Cena 1 — A busca no monte Sugrīva"
    narrator "Sudhana, filho do chefe dos mercadores, chega à região chamada Rāmāvarānta e viaja por ela. Guiado pelos frutos de mérito e pela força de amplo karma, alcança o monte Sugrīva e sobe à procura do bhikṣu Meghaśrī. Busca-o nos lados leste, sul, oeste, norte, nordeste, sudeste, sudoeste e noroeste, olhando também para cima e para baixo. A procura se estende por sete dias. Então Sudhana avista Meghaśrī caminhando num platô, no cume de outra montanha. O texto não fornece descrição adicional do relevo, do clima ou da aparência do local; o encontro começa depois que Sudhana se dirige até o monge."
    speaker_012 "Meghaśrī, procurei por você em todas as direções deste monte."
    narrator "Após sete dias, Sudhana o avistou no platô do cume de outra montanha."
    centered "Cena 2 — A pergunta sobre a conduta"
    narrator "Ao chegar diante de Meghaśrī, Sudhana inclina a cabeça aos pés do bhikṣu, circunda-o mantendo-o à sua direita e senta-se diante dele com as mãos unidas. Pergunta como os bodhisattvas treinam e praticam a conduta depois de despertar a aspiração à iluminação completa. Sua pergunta abrange o início, a entrada, o cultivo, a purificação, a realização, a manutenção e o aperfeiçoamento dessa conduta, bem como a perfeição da conduta completamente boa. Sudhana explica que ouviu dizer que Meghaśrī instrui bodhisattvas e pede ensinamento sobre como eles partem em direção à iluminação suprema e completa."
    speaker_012 "Como se inicia, cultiva e aperfeiçoa a conduta do bodhisattva?"
    speaker_013 "É uma aspiração excelente; perguntar pela conduta também é precioso."
    speaker_012 "Ensine-me como os bodhisattvas se põem a caminho da iluminação completa."
    centered "Cena 3 — Uma visão que alcança todas as direções"
    narrator "Meghaśrī diz que buscar a conduta, o campo de atividade, o caminho puro, a vasta prática e as cognições superiores dos bodhisattvas é difícil, extremamente difícil. Explica que, pela força de sua aspiração, pela visão pura da sabedoria e da fé, pela luz da sabedoria, pela observação atenta e pela capacidade de reter as nuvens do Dharma dos budas, contempla tathāgatas nos domínios de todas as direções. Sua visão abrange os âmbitos diante dele sem obstrução. Ele relata quantidades que crescem de um buda a números inconcebíveis e incontáveis, inclusive comparações com partículas de reinos e mundos."
    speaker_013 "Buscar esse caminho amplo é extremamente difícil."
    speaker_012 "Sua aspiração e sua visão lhe permitem contemplar os tathāgatas em todas as direções?"
    speaker_013 "Contemplo-os sem obstrução, em números que não se podem contar."
    centered "Cena 4 — A atenção plena dos budas e seus portais"
    narrator "Meghaśrī descreve tathāgatas de cores, formas, poderes e assembleias variados, resplandecendo com raios de muitas cores em diferentes reinos e palácios puros. Eles ensinam os seres conforme suas aspirações e manifestam diferentes milagres da realização do estado de buda. Meghaśrī chama sua realização de atenção plena dos budas, obtida ao contemplar a reunião de conhecimentos dos objetos percebidos por todos os lados. Contudo, não reivindica conhecer ou descrever as qualidades dos bodhisattvas que alcançam outros portais dessa atenção. Enumera portais ligados aos seres, aos dez poderes, ao Dharma, às direções, aos kalpas, ao tempo, aos reinos, à mente, ao karma, aos milagres e ao espaço, entre vários outros. A enumeração relaciona cada portal a uma modalidade de percepção ou visão dos tathāgatas."
    speaker_013 "Chamo minha realização de atenção plena dos budas, alcançada ao contemplá-los por todos os lados."
    speaker_012 "E as qualidades dos bodhisattvas que entram nos demais portais?"
    speaker_013 "Não posso conhecer nem descrever plenamente esse domínio de sabedoria."
    centered "Cena 5 — O próximo mestre e a despedida"
    narrator "Meghaśrī orienta Sudhana a seguir para o sul, ao distrito chamado Sāgaramukha, e procurar o bhikṣu Sāgaramegha. Diz que esse bom amigo espiritual explicará como o bodhisattva treina e pratica a conduta. Também lhe revelará causas e vastos níveis de acumulação de mérito, a força das raízes de mérito, a causa da aspiração à iluminação, a radiância do Mahāyāna e o poder da acumulação das perfeições. O ensinamento de Sāgaramegha ajudará Sudhana a purificar sua entrada no vasto oceano da conduta e a ampliar as aspirações e a grande compaixão. Então Sudhana reverencia Meghaśrī, circunda-o cem mil vezes mantendo-o à direita, olha para trás cem mil vezes e parte."
    speaker_013 "No distrito de Sāgaramukha, procure o bhikṣu Sāgaramegha."
    speaker_013 "Ele lhe explicará a conduta e a acumulação de mérito, entre outros ensinamentos vastos."
    speaker_012 "Recebo sua orientação e sigo para encontrar o próximo mestre."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Meghaśrī você gostaria de contemplar antes de seguir?"
        "A visão dos tathāgatas em todas as direções":
            narrator "A visão ampla de Meghaśrī permanece em foco."
        "Os portais da atenção plena dos budas":
            narrator "Os diversos portais do ensinamento permanecem em foco."
        "A orientação para Sāgaramegha":
            narrator "O próximo mestre indicado permanece em foco."
    call quiz_ch04
    menu:
        "Continuar — capítulo 5":
            jump chapter_05
        "Voltar ao índice":
            jump chapter_index

label quiz_ch04:
    centered "Reconheça o próximo mestre"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito do capítulo."
    while True:
        menu:
            "Para qual distrito e mestre Meghaśrī encaminha Sudhana?"
            "Ao distrito de Sāgaramukha, para encontrar o bhikṣu Sāgaramegha.":
                if 0 == 0:
                    narrator "Correto: Meghaśrī indica Sāgaramukha e o bhikṣu Sāgaramegha."
                    return
                else:
                    narrator "Releia a orientação final: o destino indicado é o distrito de Sāgaramukha."
            "Ao monte Sugrīva, para encontrar o bhikṣu Sāgaramegha.":
                if 1 == 0:
                    narrator "Correto: Meghaśrī indica Sāgaramukha e o bhikṣu Sāgaramegha."
                    return
                else:
                    narrator "Releia a orientação final: o destino indicado é o distrito de Sāgaramukha."
            "À região de Rāmāvarānta, para encontrar o bhikṣu Sāgaramegha.":
                if 2 == 0:
                    narrator "Correto: Meghaśrī indica Sāgaramukha e o bhikṣu Sāgaramegha."
                    return
                else:
                    narrator "Releia a orientação final: o destino indicado é o distrito de Sāgaramukha."

label chapter_05:
    hide screen master_provisional_badge
    scene bg_ch05 with dissolve
    show master_ch05_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 5 — Sāgaramegha"
    centered "Cena 1 — A aspiração e a chegada a Sāgaramukha"
    narrator "Sudhana mantém na memória o ensinamento de seu mestre espiritual. Contempla a radiância da sabedoria, a libertação e a meditação dos bodhisattvas; volta o pensamento ao oceano dos budas, à sucessão deles e ao domínio da iluminação. Com essa reflexão, segue até a região chamada Sāgaramukha, onde procura o bhikṣu Sāgaramegha. O texto não especifica o cenário de sua contemplação anterior, mas nomeia a região em que encontra o mestre. Ali, aproxima-se dele com reverência, circunda-o muitas vezes mantendo-o à sua direita e senta-se diante dele."
    speaker_012 "A lembrança do ensinamento me conduz a buscar a iluminação completa."
    speaker_012 "Bhikṣu Sāgaramegha, peço que me oriente sobre a via dos bodhisattvas."
    centered "Cena 2 — Perguntas sobre o caminho dos bodhisattvas"
    narrator "Com as mãos unidas, Sudhana declara que busca a mais alta iluminação e deseja penetrar o oceano da sabedoria. Pergunta como os bodhisattvas se afastam das existências mundanas, atravessam o oceano da existência, entram na onisciência, vencem os domínios dos māras e ampliam a grande compaixão. Sāgaramegha elogia sua aspiração e explica que ela não surge sem raízes de mérito. Descreve aqueles que a desenvolvem como seres sustentados por mérito, sabedoria, boas ações e confiança contínua nos mestres, com compaixão, bondade e disposição para beneficiar todos os que vivem nos estados da existência."
    speaker_012 "Como se passa da corrente da existência à conduta que busca a sabedoria e o bem de todos?"
    speaker_014 "A aspiração à iluminação se apoia em raízes de mérito e numa disposição voltada aos seres."
    speaker_014 "Compaixão, amor, benefício e ausência de apego dão amplitude a essa motivação."
    centered "Cena 3 — O lótus que surgiu do oceano"
    narrator "Sāgaramegha conta que viveu doze anos em Sāgaramukha contemplando o grande oceano. Enquanto refletia sobre sua vastidão e profundidade, viu surgir de suas águas um imenso lótus adornado com joias. Muitos grupos de seres o sustentavam, reverenciavam ou ofereciam música, fragrâncias, flores e outras oferendas. Sāgaramegha percebeu sobre a flor a imagem de um tathāgata sentado, com corpo, assento, séquito e sinais inconcebíveis. Ouviu a voz e o trovão do Dharma e viu o tathāgata estender a mão direita para tocar sua cabeça. Então recebeu o ensinamento chamado Olhos que Tudo Veem, que ilumina a conduta dos bodhisattvas e o campo dos budas."
    speaker_014 "Ao contemplar o oceano, vi surgir um lótus vasto, cercado por homenagens de muitos seres."
    speaker_014 "Sobre ele percebi um tathāgata e recebi o ensinamento chamado Olhos que Tudo Veem."
    centered "Cena 4 — Um ensinamento, muitos oceanos"
    narrator "Sāgaramegha afirma que possui o ensinamento Olhos que Tudo Veem há doze anos. Por meio de diferentes poderes de retenção, compreende, investiga, expõe e organiza incontáveis capítulos; ensina também aos seres que chegam de todas as direções. Ainda assim, diz conhecer apenas um ensinamento e não poder descrever todas as qualidades dos bodhisattvas. Explica que eles ingressam em muitos “oceanos” para purificar aspirações e reinos, comunicar sabedoria, servir aos budas e ensinar em todas as línguas dos seres. Depois orienta Sudhana a procurar o bhikṣu Supratiṣṭhita em Sāgaratīra, sessenta yojanas ao sul, na estrada para Laṅka. Sudhana presta homenagem, circunda Sāgaramegha e parte, olhando para trás repetidamente."
    speaker_014 "Este é o ensinamento que conheço; não posso abranger com palavras todas as qualidades dos bodhisattvas."
    speaker_014 "Segue ao sul até Sāgaratīra e pergunta a Supratiṣṭhita como se treina na conduta dos bodhisattvas."
    speaker_012 "Recebo sua orientação e sigo adiante, mantendo seu ensinamento em mente."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o ensinamento de Sāgaramegha, que aspecto você gostaria de considerar primeiro?"
        "A motivação de grande compaixão":
            narrator "A compaixão é apresentada como uma motivação para proteger todos os seres."
        "A imagem do oceano e do lótus":
            narrator "A contemplação do oceano antecede a visão do grande lótus."
        "Os muitos modos de retenção":
            narrator "Sāgaramegha descreve poderes de retenção ligados ao entendimento de incontáveis capítulos."
    call quiz_ch05
    menu:
        "Continuar — capítulo 6":
            jump chapter_06
        "Voltar ao índice":
            jump chapter_index

label quiz_ch05:
    centered "Recordação do ensinamento"
    narrator "Escolha a resposta que corresponde ao relato do capítulo."
    while True:
        menu:
            "Qual ensinamento Sāgaramegha diz ter recebido do tathāgata?"
            "Olhos que Tudo Veem":
                if 0 == 0:
                    narrator "Correto: o ensinamento recebido chama-se Olhos que Tudo Veem."
                    return
                else:
                    narrator "Relembre o nome do ensinamento que Sāgaramegha diz ter adquirido."
            "A Roda das Dez Direções":
                if 1 == 0:
                    narrator "Correto: o ensinamento recebido chama-se Olhos que Tudo Veem."
                    return
                else:
                    narrator "Relembre o nome do ensinamento que Sāgaramegha diz ter adquirido."
            "O Palácio da Onisciência":
                if 2 == 0:
                    narrator "Correto: o ensinamento recebido chama-se Olhos que Tudo Veem."
                    return
                else:
                    narrator "Relembre o nome do ensinamento que Sāgaramegha diz ter adquirido."

label chapter_06:
    hide screen master_provisional_badge
    scene bg_ch06 with dissolve
    show master_ch06_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 6 — Supratiṣṭhita"
    centered "Cena 1 — A busca em todas as direções"
    narrator "Recordando as instruções e o ensinamento do Dharma chamado Olhos que Tudo Veem, Sudhana chega a Sāgaratīra, na região de Laṅka. Desejando encontrar o monge Supratiṣṭhita, procura-o para leste e, em seguida, em todas as outras direções, acima e abaixo. Então o vê caminhando de um lado para outro no céu, acompanhado por incontáveis devas. Senhores devas oferecem pétalas de flores, música, estandartes e bandeiras; senhores nāgas formam nuvens de incenso e trovões. Kinnaras cantam, mahoragas oferecem roupas, asuras fazem surgir joias, e outros seres prestam homenagem, protegem ou circundam o monge."
    speaker_012 "Depois de procurar em todas as direções, finalmente vejo o monge Supratiṣṭhita."
    narrator "No céu, muitos seres se reúnem para homenageá-lo com música, oferendas e reverência."
    centered "Cena 2 — A aspiração e as perguntas de Sudhana"
    narrator "Ao ver Supratiṣṭhita, Sudhana sente grande alegria, une as mãos em homenagem e declara que desenvolveu a aspiração pela iluminação suprema e completa. Apresenta uma série de perguntas: como um bodhisattva deve buscar, obter, reunir, servir, proteger, seguir, acumular, difundir, purificar, praticar e compreender o Buddhadharma? Pede instrução para que a prática não se separe da visão do Buddha, da visão dos bodhisattvas, da aspiração e da conduta, nem da audição do Dharma e da luz da sabedoria. Supratiṣṭhita acolhe a aspiração e as perguntas como excelentes, e começa a explicar a libertação que realizou."
    speaker_012 "Aspiro à iluminação completa. Como um bodhisattva deve buscar e praticar o Buddhadharma sem se afastar da visão do Buddha e da luz da sabedoria?"
    speaker_015 "É excelente que tenhas desenvolvido essa aspiração e perguntes sobre o Dharma do Buddha."
    centered "Cena 3 — O gateway desimpedido"
    narrator "Supratiṣṭhita explica que alcançou a libertação do bodhisattva chamada gateway desimpedido e a luz de sabedoria chamada ápice desimpedido. Por isso, diz não encontrar impedimento para perceber mentes, condutas, nascimentos e mortes; recordar vidas passadas; compreender linguagens, dúvidas e faculdades; ou agir no tempo adequado para amadurecer e guiar seres. Também descreve atividades e manifestações: caminhar, sentar ou deitar no céu, tornar-se invisível ou visível, assumir formas diversas e atravessar obstáculos como se fossem espaço. Fala de emanações luminosas que alcançam direções e mundos em números incontáveis, e de sua presença sem substância e de poderes miraculosos não compostos."
    speaker_015 "Minha libertação é um gateway desimpedido; por ela, percebo seres e posso agir no tempo adequado para guiá-los."
    speaker_012 "Compreendo que o ensinamento abrange tanto o conhecimento dos seres quanto uma presença que alcança muitos mundos."
    centered "Cena 4 — O alcance da libertação e o próximo mestre"
    narrator "Supratiṣṭhita relata que alcança Buddhas em incontáveis mundos, faz oferendas, conhece e recorda o que eles ensinam e se lembra de seus mundos puros. Afirma que os seres que o veem ou se associam a ele alcançarão a iluminação completa, e que os estabelecerá na libertação que percorre todos os lugares e favorece o amadurecimento. Contudo, diz conhecer apenas essa libertação e não poder descrever as qualidades da vasta conduta dos bodhisattvas. Encaminha Sudhana a Megha, um draviḍa que vive em Vajrapura, na terra de Draviḍa, para perguntar como treinar e praticar a conduta do bodhisattva. Sudhana curva a cabeça aos pés do monge, circum-ambula-o à direita cem mil vezes, olha para trás cem mil vezes e parte."
    speaker_015 "Conheço esta libertação dedicada a fazer oferendas aos Tathāgatas e a favorecer o amadurecimento dos seres; a conduta dos grandes bodhisattvas excede o que posso descrever."
    speaker_015 "Segue para Vajrapura e pergunta a Megha como um bodhisattva treina e pratica a conduta do bodhisattva."
    speaker_012 "Prestarei homenagem e seguirei para fazer a pergunta indicada."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Como reflexão opcional, qual aspecto do ensinamento de Supratiṣṭhita você destacaria?"
        "A atenção às necessidades e disposições dos seres":
            narrator "A libertação descrita inclui conhecer e guiar os seres sem impedimento."
        "A vastidão da presença e das oferendas aos Buddhas":
            narrator "O relato percorre direções e mundos incontáveis."
        "A humildade ao reconhecer os limites do próprio conhecimento":
            narrator "Supratiṣṭhita distingue sua libertação da vasta conduta dos bodhisattvas."
    call quiz_ch06
    menu:
        "Continuar — capítulo 7":
            jump chapter_07
        "Voltar ao índice":
            jump chapter_index

label quiz_ch06:
    centered "O ensinamento de Supratiṣṭhita"
    narrator "Escolha a única resposta que corresponde ao ensinamento explícito do capítulo."
    while True:
        menu:
            "Como se chama a libertação do bodhisattva que Supratiṣṭhita diz conhecer?"
            "A libertação do gateway desimpedido que percorre todos os lugares.":
                if 0 == 0:
                    narrator "Correto: ele a identifica como a libertação que percorre todos os lugares e tem poder para amadurecer seres."
                    return
                else:
                    narrator "Releia a descrição de Supratiṣṭhita: sua libertação é desimpedida e favorece o amadurecimento dos seres."
            "A libertação de abandonar a aspiração à iluminação.":
                if 1 == 0:
                    narrator "Correto: ele a identifica como a libertação que percorre todos os lugares e tem poder para amadurecer seres."
                    return
                else:
                    narrator "Releia a descrição de Supratiṣṭhita: sua libertação é desimpedida e favorece o amadurecimento dos seres."
            "A libertação de permanecer separado dos seres.":
                if 2 == 0:
                    narrator "Correto: ele a identifica como a libertação que percorre todos os lugares e tem poder para amadurecer seres."
                    return
                else:
                    narrator "Releia a descrição de Supratiṣṭhita: sua libertação é desimpedida e favorece o amadurecimento dos seres."

label chapter_07:
    hide screen master_provisional_badge
    scene bg_ch07 with dissolve
    show master_ch07_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 7 — Megha"
    centered "Cena 1 — A roda de sílabas em Vajrapura"
    narrator "Com a mente firme na aspiração pela iluminação e na dedicação a todos os seres, Sudhana chega a Vajrapura e procura Megha, o draviḍa. Encontra-o em um dos pátios da cidade, sentado em um trono de leão, ensinando a Exposição da Roda Giratória das Sílabas a cerca de dez mil seres. Sudhana aproxima-se, curva a cabeça aos pés do mestre, circunda-o muitas centenas de milhares de vezes e senta-se diante dele. Com as mãos unidas, apresenta sua aspiração e pergunta como os bodhisattvas devem treinar e praticar, sem perder a motivação em meio às condições da existência."
    speaker_012 "Mestre, busco compreender como se cultiva a conduta do bodhisattva sem abandonar a aspiração à iluminação."
    speaker_016 "Tua pergunta se volta ao caminho que beneficia os seres; expõe também as capacidades que desejas compreender."
    centered "Cena 2 — A pergunta e a reverência"
    narrator "Sudhana amplia sua pergunta: quer saber como purificar a resolução e fortalecer a grande compaixão; como desenvolver retenção, luz da sabedoria, discernimento e memória; como purificar os renascimentos e fazer surgir a meditação com certeza e análise dos sentidos do Dharma. Megha então se levanta do trono, desce e se prostra diante de Sudhana. Espalha flores douradas, joias preciosas e pó de sândalo; oferece tecidos de várias cores e flores perfumadas, além de outras homenagens. Em seguida, elogia a aspiração de Sudhana e sua dedicação ao caminho dos budas, à orientação dos seres e à prática das condutas e orações dos bodhisattvas."
    speaker_012 "Como posso manter firme a compaixão e desenvolver a sabedoria sem desanimar?"
    speaker_016 "É excelente que tenhas despertado essa aspiração e te dediques a compreender o caminho com cuidado."
    speaker_012 "Recebo tua homenagem com respeito e atenção ao Dharma que compartilhas."
    centered "Cena 3 — O louvor e a luz que convoca"
    narrator "Megha descreve os bodhisattvas como conforto, proteção e refúgio dos seres. Compara-os à terra que faz crescer o mérito, ao oceano que guarda tesouros inexauríveis, ao sol da sabedoria e à chuva que nutre as faculdades; são também marinheiros, pontes e vaus para a travessia do oceano do Dharma e do saṃsāra. Enquanto proclama esse louvor, uma massa de raios de luz emana de sua boca e se espalha pelos mundos. Seres de numerosas classes, entre eles devas, nāgas, humanos e outros, vêm à presença de Megha. Ele lhes ensina extensamente a Roda Giratória das Sílabas; ao ouvi-la, todos alcançam progresso irreversível rumo à iluminação completa."
    speaker_016 "Que os bodhisattvas sejam lembrados como apoio aos seres e passagem para atravessar o oceano do saṃsāra."
    narrator "A luz que irradia da fala de Megha se espalha, e muitos seres se aproximam."
    speaker_016 "Ouçam a Roda Giratória das Sílabas e examinem o ensinamento com atenção."
    centered "Cena 4 — O alcance da retenção de Sarasvatī"
    narrator "Depois de ensinar à multidão, Megha senta-se novamente no trono do Dharma e explica a Sudhana o poder de retenção de Sarasvatī que alcançou. Por meio dele, conhece as línguas de devas e de muitas outras classes de seres, assim como sinais, palavras, nomes e expressões de seres em diferentes condições. Diz perceber os modos de fala e os oceanos de linguagem dos seres e dos tathāgatas nos três tempos, em incontáveis mundos e direções. Mas delimita o que sabe: embora conheça essa luz da retenção, não pode abarcar a conduta nem descrever todas as qualidades da entrada dos bodhisattvas nos vastos domínios de palavras, línguas e ensinamentos."
    speaker_016 "Alcancei o poder de retenção de Sarasvatī e conheço linguagens e modos de expressão de muitos seres."
    speaker_012 "Teu relato mostra uma amplitude que eu ainda não alcanço compreender por inteiro."
    speaker_016 "Conheço essa capacidade, mas não posso descrever toda a entrada dos bodhisattvas nesse oceano de expressão."
    centered "Cena 5 — A indicação de Muktaka e a partida"
    narrator "Megha orienta Sudhana a partir para a região sul, à terra de Vanavāsī, onde vive Muktaka, um chefe mercador. Recomenda que pergunte a ele como os bodhisattvas devem treinar na conduta, como devem prosseguir e como suas mentes devem repousar em meditação. Sudhana inclina a cabeça aos pés de Megha, honra seu Dharma e reconhece nele uma fonte para o surgimento de sua fé. Chorando, com o rosto coberto de lágrimas, circunda o mestre cem mil vezes, mantendo-o à sua direita; olha para trás repetidamente antes de partir. Assim se encerra o encontro com o mestre que ensinou a roda de sílabas e revelou os limites de seu próprio conhecimento."
    speaker_016 "Segue para Vanavāsī e procura Muktaka; pergunta-lhe sobre treino, prática e repouso meditativo."
    speaker_012 "Levarei comigo respeito por teu Dharma e seguirei a orientação recebida."
    narrator "Com lágrimas, Sudhana se despede após circundar Megha e olhar para trás muitas vezes."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o ensinamento de Megha, qual aspecto você gostaria de levar em consideração?"
        "A aspiração firme à iluminação":
            narrator "Uma reflexão sobre manter a aspiração sem desanimar."
        "As imagens dos bodhisattvas como apoio aos seres":
            narrator "Uma reflexão sobre proteção, benefício e travessia."
        "A diversidade das linguagens e expressões":
            narrator "Uma reflexão sobre a amplitude da comunicação dos seres."
    call quiz_ch07
    menu:
        "Continuar — capítulo 8":
            jump chapter_08
        "Voltar ao índice":
            jump chapter_index

label quiz_ch07:
    centered "O que Megha alcançou?"
    narrator "Escolha a resposta baseada no relato de Megha; esta atividade é não canônica."
    while True:
        menu:
            "Qual poder Megha diz ter alcançado?"
            "O poder de retenção de Sarasvatī":
                if 0 == 0:
                    narrator "Correto: Megha relata ter alcançado o poder de retenção de Sarasvatī."
                    return
                else:
                    narrator "Revise o relato de Megha sobre sua capacidade de retenção."
            "O poder de comandar os devas":
                if 1 == 0:
                    narrator "Correto: Megha relata ter alcançado o poder de retenção de Sarasvatī."
                    return
                else:
                    narrator "Revise o relato de Megha sobre sua capacidade de retenção."
            "O poder de interromper os renascimentos":
                if 2 == 0:
                    narrator "Correto: Megha relata ter alcançado o poder de retenção de Sarasvatī."
                    return
                else:
                    narrator "Revise o relato de Megha sobre sua capacidade de retenção."

label chapter_08:
    hide screen master_provisional_badge
    scene bg_ch08 with dissolve
    show master_ch08_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 8 — Muktaka"
    centered "Cena 1 — Doze anos de compromisso"
    narrator "Antes de encontrar o próximo mestre, Sudhana contempla os ensinamentos e as capacidades dos bodhisattvas: memória do Dharma, compreensão das línguas, purificação da mente, cultivo das raízes de mérito e firmeza da aspiração. O texto descreve nele compromisso perseverante, fé inabalável e sabedoria ampla, além de dedicação às instruções dos bons amigos espirituais. Após doze anos, ele chega a Vanavāsī, procura Muktaka, o mercador, e o encontra. Sudhana prostra o corpo inteiro no chão em homenagem e senta-se diante dele, pronto para expor sua busca."
    narrator "O relato acompanha uma longa continuidade de aspiração e prática antes do encontro em Vanavāsī."
    speaker_012 "Cheguei ao mestre que procurava; que eu saiba escutar com atenção."
    centered "Cena 2 — A aspiração de Sudhana"
    narrator "Com as palmas unidas, Sudhana expressa sua gratidão por ter encontrado um bom amigo espiritual, encontro que considera raro. Expõe a amplitude de sua aspiração à iluminação completa: servir e venerar os budas, ouvi-los e compreender seus votos, receber e conservar o Dharma, cultivar a conduta e as perfeições dos bodhisattvas e desenvolver sabedoria, samādhi e grande compaixão para orientar os seres. Diz que veio com essa intenção e pede instrução: quer saber como os bodhisattvas aprendem, treinam e se dedicam à própria conduta, e como purificam rapidamente esse domínio. Muktaka então entra em samādhi."
    speaker_012 "Reconheço como preciosa a oportunidade de estar diante de um bom amigo espiritual."
    speaker_012 "Peço orientação para aprender e cultivar a conduta dos bodhisattvas em benefício dos seres."
    centered "Cena 3 — O corpo como assembleia de campos de buda"
    narrator "Muktaka entra no samādhi chamado “assembleia de todos os campos de buda”, apoiado por raízes de mérito passadas, pela bênção dos tathāgatas e pela concentração que traz a luz de sabedoria de Mañjuśrī Kumārabhūta. Seu corpo torna-se puro, e nele aparecem budas em número comparável aos átomos dos campos de buda nas dez direções, com seus campos, discípulos, auréolas, práticas, milagres e ensinamentos. As aparições permanecem distintas, sem se encobrir. Sudhana contempla os diversos feitos dos budas: em diferentes mundos, eles nascem, renunciam, despertam, ensinam, orientam seres e passam ao nirvāṇa. Ele ouve, acolhe, conserva e contempla os Dharmas ensinados."
    narrator "A visão apresenta mundos e assembleias distintos, sem que um se sobreponha ao outro."
    speaker_012 "Vejo os feitos e os ensinamentos manifestados em campos incontáveis."
    centered "Cena 4 — A exibição desimpedida"
    narrator "Ao sair do samādhi, Muktaka explica que alcançou a libertação dos tathāgatas chamada “exibição desimpedida”. Relata ver budas nas dez direções, sem que eles tenham vindo até ele nem que ele tenha ido até eles. Entre os nomes apresentados estão Tāreśvararāja, Samantagandhavitāna, Merupradīparāja, Vajrapramardana, Anilambhacakṣurvairocana, Gandhapradīpa, Samantamukhajñānavirocanaghoṣa, Apramāṇaguṇasāgaraprabha, Dharmadhātuvidyotitaraśmi e Apratihataguṇakīrtivimokṣaprabharāja. Muktaka também diz poder ver, quando deseja, tathāgatas em outros campos, direções, tempos e lugares, inclusive enquanto realizam milagres ou orientam seres."
    speaker_017 "A libertação que conheço permite perceber os tathāgatas sem deslocamento entre aqui e lá."
    speaker_012 "A percepção alcança diferentes direções, tempos e campos de buda."
    centered "Cena 5 — A bênção da própria mente"
    narrator "Muktaka compara a percepção dos tathāgatas a sonho, reflexo e formas de ilusão; compara a fala deles a ecos, assim como a percepção da própria mente. Ensina que o Dharma dos bodhisattvas, os campos puros, a conduta, a orientação dos seres e a iluminação são bênçãos da própria mente. Para cultivá-la, recomenda sustentá-la com raízes de mérito, purificá-la, firmá-la com diligência, tranquilizá-la com paciência e desenvolvê-la com conhecimento e sabedoria. Muktaka reconhece que conhece essa libertação, mas não pode descrever as qualidades e realizações dos bodhisattvas que atuam sem impedimentos e sem concepções dualistas. Como exemplos de tathāgatas que vê, menciona Amitābha em Sukhāvatī e Akṣobhya em Abhiratī."
    speaker_017 "A mente deve ser apoiada pelo mérito e cultivada com diligência, paciência, conhecimento e sabedoria."
    speaker_012 "Compreendo que essa libertação não esgota todas as realizações dos bodhisattvas."
    centered "Cena 6 — A próxima orientação"
    narrator "Muktaka orienta Sudhana a seguir para o sul, até Milaspharaṇa, no extremo de Jambudvīpa. Ali vive o monge Sāgaradhvaja, a quem Sudhana deve perguntar como um bodhisattva treina e procede na conduta dos bodhisattvas. Sudhana inclina a cabeça aos pés de Muktaka e o circunda cem mil vezes, mantendo-o à direita. Ao partir, olha para trás repetidamente e chora, enquanto recorda as qualidades do mestre. O capítulo encerra destacando sua afeição, confiança e obediência aos bons amigos espirituais, bem como sua convicção de que a onisciência depende deles; Sudhana evita prejudicá-los e os considera como mãe e pai ao desenvolver raízes de mérito."
    speaker_017 "No caminho ao sul, procure o monge Sāgaradhvaja em Milaspharaṇa."
    speaker_012 "Parto com reverência e levarei comigo a orientação recebida."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre a orientação de Muktaka, em que aspecto você gostaria de deter a atenção de Sudhana?"
        "A mente cultivada":
            narrator "A reflexão destaca o conselho de sustentar e purificar a própria mente."
        "A visão dos tathāgatas":
            narrator "A reflexão destaca a percepção sem deslocamento entre mundos."
        "A dedicação aos bons amigos":
            narrator "A reflexão destaca a confiança e a obediência de Sudhana aos mestres."
    call quiz_ch08
    menu:
        "Continuar — capítulo 9":
            jump chapter_09
        "Voltar ao índice":
            jump chapter_index

label quiz_ch08:
    centered "O ensinamento de Muktaka"
    narrator "Escolha a resposta que corresponde a um ensinamento explícito do capítulo."
    while True:
        menu:
            "Segundo Muktaka, o que deve sustentar a própria mente?"
            "Apenas a percepção dos campos de buda":
                if 0 == 1:
                    narrator "Correto: Muktaka ensina que a mente deve ser apoiada por todas as raízes de mérito."
                    return
                else:
                    narrator "Tente novamente: recorde o que Muktaka diz que deve apoiar a própria mente."
            "Todas as raízes de mérito":
                if 1 == 1:
                    narrator "Correto: Muktaka ensina que a mente deve ser apoiada por todas as raízes de mérito."
                    return
                else:
                    narrator "Tente novamente: recorde o que Muktaka diz que deve apoiar a própria mente."
            "O afastamento de todos os bons amigos espirituais":
                if 2 == 1:
                    narrator "Correto: Muktaka ensina que a mente deve ser apoiada por todas as raízes de mérito."
                    return
                else:
                    narrator "Tente novamente: recorde o que Muktaka diz que deve apoiar a própria mente."

label chapter_09:
    hide screen master_provisional_badge
    scene bg_ch09 with dissolve
    show master_ch09_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 9 — Sāgaradhvaja"
    centered "Cena 1 — A busca em Milaspharaṇa"
    narrator "Após contemplar os ensinamentos de Muktaka e dedicar-se às suas instruções, Sudhana segue cultivando aspirações e práticas ligadas à sabedoria, ao Dharma, às atividades dos bodhisattvas e às preces. Por fim, chega a Milaspharaṇa, na ponta de Jambudvīpa, e procura repetidamente o bhikṣu Sāgaradhvaja. Quando o encontra, o monge está sentado no fim de um caminho de meditação: imóvel, com o corpo ereto e em samādhi profundo. Sudhana observa que Sāgaradhvaja não manifesta respiração perceptível e permanece em quietude. A cena se concentra na contemplação silenciosa do discípulo diante do mestre, sem acrescentar acontecimentos à busca descrita."
    speaker_012 "As instruções de Muktaka permanecem comigo; agora procuro Sāgaradhvaja."
    narrator "No fim do caminho de meditação, Sudhana encontra o bhikṣu imóvel em samādhi."
    centered "Cena 2 — O corpo que revela incontáveis atividades"
    narrator "Enquanto Sāgaradhvaja repousa em meditação profunda, Sudhana vê seu corpo manifestar-se vasto e multicolorido, além do alcance da vista. De seus poros surgem incontáveis manifestações de libertação dos bodhisattvas, que se espalham pelo reino dos fenômenos. Elas amadurecem os seres, fazem oferendas aos tathāgatas e purificam campos de buda; também aliviam sofrimentos, afastam obscuridades e conduzem à felicidade e à onisciência. Outras aparições mostram assembleias de mercadores, brâmanes e chefes de família oferecendo auxílio e bens, enquanto sábios de várias áreas ensinam, confortam e orientam os seres. Sudhana testemunha a meditação como atividade voltada ao benefício de todos."
    speaker_012 "De cada manifestação reconheço uma atividade dirigida ao benefício dos seres."
    narrator "A visão de Sudhana acompanha aparições que ensinam, oferecem auxílio e dissipam sofrimentos."
    centered "Cena 3 — Ensinamentos que se estendem pelas direções"
    narrator "A visão se amplia: de diferentes partes do corpo de Sāgaradhvaja emanam ṛṣis que proclamam o Dharma, nāgas que adornam o céu com oferendas, e muitos outros seres que ensinam conforme as necessidades daqueles a quem conduzem. Sudhana vê aparições que afastam violência e orgulho, fazem cessar condutas nocivas e estabelecem seres em práticas benéficas. Śrāvakas e pratyekabuddhas ensinam, entre outros temas, a ausência de um eu, a impermanência e a originação dependente. Músicos celestes celebram a aspiração à iluminação e a conduta dos bodhisattvas. As manifestações também incluem raios solares e luas, bodhisattvas que revelam as perfeições e tathāgatas que fazem chover o Dharma sobre diferentes seres e assembleias."
    speaker_012 "Os ensinamentos aparecem de modos diversos, dirigidos a seres diversos."
    narrator "Na visão, as manifestações conduzem os seres por ensinamentos e práticas apropriados."
    centered "Cena 4 — Seis meses e seis dias de contemplação"
    narrator "De cada poro de Sāgaradhvaja, Sudhana vê campos de raios luminosos que manifestam práticas de generosidade, disciplina, paciência, diligência, meditação, sabedoria, meios hábeis, preces, força e conhecimento. As aparições incluem exemplos de busca do Dharma, amadurecimento dos seres e purificação dos campos. Sudhana contempla e examina o samādhi, sua sabedoria e as maneiras de beneficiar os seres. Permanece diante do monge por um dia e uma noite, depois por períodos sucessivamente maiores, até completar seis meses e mais seis dias e noites. Só então Sāgaradhvaja se ergue da meditação. Sudhana lhe pergunta o nome daquele samādhi extraordinário."
    speaker_012 "Passei esse tempo contemplando as manifestações e a amplitude de suas atividades."
    speaker_012 "Mestre, como se chama o samādhi que acabo de testemunhar?"
    centered "Cena 5 — O nome do samādhi e a próxima mestra"
    narrator "Sāgaradhvaja responde que o samādhi é a perfeição da sabedoria chamada “visão completa da realização da equanimidade”, e chama sua radiância de “exibição pura de cada portal”. Explica que meditar nessa exibição permite realizar incontáveis samādhis semelhantes e descreve uma abrangência sem impedimentos: perceber e adentrar campos de mundo, conhecer budas, seus ensinamentos e qualidades, e compreender seres e suas faculdades. O monge ressalva que conhece apenas essa conduta da perfeição da sabedoria e não pode abarcar todas as qualidades dos bodhisattvas. Em seguida, envia Sudhana a Samudravetāḍī, ao parque Samantavyūha, a leste de Mahāprabhasa, para encontrar a upāsikā Āśā. Sudhana reverencia o mestre e parte, guardando sua lembrança."
    speaker_018 "Este samādhi é a perfeição da sabedoria chamada visão completa da realização da equanimidade."
    speaker_012 "Partirei para encontrar Āśā e perguntar como se treina e pratica a conduta do bodhisattva."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Sāgaradhvaja você prefere levar como reflexão? A escolha não altera os acontecimentos do capítulo."
        "A equanimidade e a sabedoria":
            narrator "A reflexão destaca o nome do samādhi e sua radiância."
        "A atividade em benefício dos seres":
            narrator "A reflexão destaca as manifestações que aliviam sofrimentos e ensinam."
        "A humildade diante do vasto caminho":
            narrator "A reflexão destaca que Sāgaradhvaja declara conhecer apenas esta conduta."
    call quiz_ch09
    menu:
        "Continuar — capítulo 10":
            jump chapter_10
        "Voltar ao índice":
            jump chapter_index

label quiz_ch09:
    centered "Nome da radiância"
    narrator "Escolha a resposta correta com base no ensinamento explícito do capítulo. Este minijogo é não canônico."
    while True:
        menu:
            "Como Sāgaradhvaja chama a radiância do samādhi?"
            "A exibição pura de cada portal":
                if 0 == 0:
                    narrator "Correto: a radiância é chamada de exibição pura de cada portal."
                    return
                else:
                    narrator "Releia a resposta de Sāgaradhvaja sobre o nome da radiância."
            "O oceano das preces dos bodhisattvas":
                if 1 == 0:
                    narrator "Correto: a radiância é chamada de exibição pura de cada portal."
                    return
                else:
                    narrator "Releia a resposta de Sāgaradhvaja sobre o nome da radiância."
            "A luz dos campos de mundo":
                if 2 == 0:
                    narrator "Correto: a radiância é chamada de exibição pura de cada portal."
                    return
                else:
                    narrator "Releia a resposta de Sāgaradhvaja sobre o nome da radiância."

label chapter_10:
    hide screen master_provisional_badge
    scene bg_ch10 with dissolve
    show master_ch10_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 10 — Āśā"
    centered "Cena 1 — O parque de Samantavyūha"
    narrator "Após recordar que os bons amigos espirituais são fonte e mestres do Dharma, Sudhana chega ao parque Samantavyūha. A narrativa descreve paredes e árvores preciosas, flores que espalham pólen, aromas, sons musicais movidos pela brisa, lagoas e um palácio aéreo central coberto de joias. Ali, Āśā está sentada em um trono; numerosos seres lhe prestam homenagem. Sudhana entra, observa o parque, aproxima-se, inclina a cabeça aos pés dela e a circunda muitas centenas de milhares de vezes. Então apresenta sua aspiração à iluminação completa e pergunta como os bodhisattvas devem treinar e praticar sua conduta."
    speaker_012 "Aspiro à iluminação completa, mas ainda busco compreender como se treina e se pratica a conduta do bodhisattva."
    speaker_019 "Pergunte com clareza, nobre viajante; compartilharei o que conheço sobre essa prática."
    centered "Cena 2 — A libertação e o benefício de encontrar Āśā"
    narrator "Āśā nomeia sua realização como a libertação chamada estandarte da bem-aventurança sem pesar. Segundo ela, vê-la, ouvi-la, honrá-la, estar com ela ou recordá-la traz benefício. Há uma ressalva: seres sem raízes de mérito, sem vínculo com um bom amigo espiritual e sem intenção de alcançar a budeidade completa não a veem. A visão de Āśā torna irreversível o avanço rumo à iluminação; o texto também relata que os seres que a veem são libertos de doenças, aflições mentais, visões errôneas e obscurecimentos, e desenvolvem capacidades e caminhos de prática. Āśā diz nunca estar sem a visão dos tathāgatas, seus ensinamentos e a companhia de bodhisattvas."
    speaker_019 "Chamo minha libertação de estandarte da bem-aventurança sem pesar; sua força torna benéfico encontrar-me."
    speaker_012 "Compreendo que esse encontro é apresentado como apoio ao avanço irreversível dos seres."
    centered "Cena 3 — Uma memória de muitos budas"
    narrator "Quando Sudhana pergunta há quanto tempo ela aspira à iluminação, Āśā responde por meio de suas lembranças de vidas passadas. Recorda Dīpaṅkara, diante de quem fez votos, oferendas e recebeu o Dharma; menciona também Vimala, Ketu, Meruśrī, Padmagarbha, Vairocana, Samantacakṣu, Brahmaśuddha, Vajranābhi e Varuṇadeva. Ela afirma lembrar-se de tathāgatas em número comparável aos grãos de areia de trinta e seis rios Ganges, a quem serviu, honrou e de quem ouviu o Dharma. Em seguida, descreve os bodhisattvas como imensuráveis: a aspiração inicial, a grande compaixão, o amor, os votos e as práticas abrangem mundos e seres."
    speaker_012 "Suas lembranças atravessam muitas vidas. Que alcance têm, então, as aspirações dos bodhisattvas?"
    speaker_019 "Elas são imensuráveis: compaixão, amor, votos e prática alcançam todos os seres e mundos."
    centered "Cena 4 — Sem exceção nem resto"
    narrator "À pergunta de Sudhana sobre quando Āśā alcançará a budeidade, ela responde que a aspiração do bodhisattva não é feita apenas por um ser, por quantidades enumeráveis ou mesmo por números inconcebíveis de mundos. Tampouco se limita a servir budas, purificar campos, preservar ensinamentos ou conhecer as faculdades e condutas de uma parcela dos seres. O propósito é conduzir e amadurecer os seres de todos os mundos sem exceção nem resto. Āśā amplia a mesma medida para honrar todos os budas, purificar todos os campos, acolher os ensinamentos, compreender as mentes e faculdades dos seres e extinguir o oceano de aflições e carma. A compaixão reúne as nuvens que põem fim ao sofrimento de todos."
    speaker_012 "Basta uma quantidade incontável, ou a aspiração precisa alcançar ainda mais?"
    speaker_019 "A medida é todos os seres em todos os mundos, sem exceção nem resto."
    centered "Cena 5 — A próxima orientação"
    narrator "Āśā sintetiza a conduta do bodhisattva como adquirir todos os Dharmas para realizar a sabedoria e adquirir todos os domínios para concretizar sua purificação. Suas preces só chegam ao fim quando os mundos forem purificados e cessar a conexão com as predisposições às aflições dos seres. Ela afirma conhecer apenas a libertação do estandarte da bem-aventurança sem pesar e não se considera capaz de descrever plenamente a conduta dos bodhisattvas de qualidades vastas. Então orienta Sudhana a procurar o ṛṣi Bhīṣmottaranirghoṣa, em Nālayu, no sul de Samudravetāḍī. Sudhana se inclina, circunda Āśā cem mil vezes e parte olhando para trás, com lágrimas, pensando na raridade da iluminação, do Dharma e de encontrar um bom amigo espiritual."
    speaker_019 "Meu conhecimento se limita a esta libertação; em Nālayu, procure o ṛṣi Bhīṣmottaranirghoṣa."
    speaker_012 "Partirei com gratidão pelo ensinamento e pelo encontro que me orienta adiante."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o ensinamento de Āśā, que pergunta você levaria consigo?"
        "O que significa aspirar por todos os seres, sem exceção?":
            narrator "Uma reflexão alinhada à amplitude que Āśā descreve."
        "Como a conduta reúne sabedoria e purificação?":
            narrator "Uma reflexão alinhada à síntese que Āśā oferece."
        "Qual é o nome da libertação de Āśā?":
            narrator "Uma lembrança pertinente: estandarte da bem-aventurança sem pesar."
    call quiz_ch10
    menu:
        "Continuar — capítulo 11":
            jump chapter_11
        "Voltar ao índice":
            jump chapter_index

label quiz_ch10:
    centered "Reconheça a libertação"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito de Āśā."
    while True:
        menu:
            "Como se chama a libertação que Āśā diz conhecer?"
            "A roda da luz sem limites":
                if 0 == 1:
                    narrator "Correto: Āśā dá esse nome à libertação que conhece."
                    return
                else:
                    narrator "Relembre o nome que Āśā declara no capítulo."
            "O estandarte da bem-aventurança sem pesar":
                if 1 == 1:
                    narrator "Correto: Āśā dá esse nome à libertação que conhece."
                    return
                else:
                    narrator "Relembre o nome que Āśā declara no capítulo."
            "A morada da compaixão universal":
                if 2 == 1:
                    narrator "Correto: Āśā dá esse nome à libertação que conhece."
                    return
                else:
                    narrator "Relembre o nome que Āśā declara no capítulo."

label chapter_11:
    hide screen master_provisional_badge
    scene bg_ch11 with dissolve
    show master_ch11_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 11 — Bhīṣmottaranirghoṣa"
    centered "Cena 1 — Chegada à floresta de Nālayu"
    narrator "Com a mente voltada à conduta pura dos bodhisattvas, ao fortalecimento do mérito, à visão dos budas, ao tesouro do Dharma e à realização de grandes aspirações, Sudhana chega à terra de Nālayu. Também contempla a dissipação das obstruções e uma motivação firme, comparada no texto ao vajra precioso de Nārāyaṇa. Depois de procurar, encontra Bhīṣmottaranirghoṣa no ashram da floresta. O ṛṣi está sentado sobre um assento de grama, com os cabelos presos em um coque de mechas emaranhadas e vestes de pele, grama e casca de árvore. Sudhana o circunda muitas vezes, mantendo-o à sua direita."
    speaker_012 "Que eu não perca de vista a conduta dos bodhisattvas enquanto sigo adiante."
    narrator "Na floresta de Nālayu, a busca de Sudhana enfim o conduz ao ṛṣi que procurava."
    centered "Cena 2 — A pergunta diante do bom amigo espiritual"
    narrator "Diante de Bhīṣmottaranirghoṣa, Sudhana reconhece a importância do kalyāṇamitra, o bom amigo espiritual: suas instruções conduzem ao caminho verdadeiro e à onisciência; sua amizade é comparada a uma estrada, uma ponte, uma lâmpada e um abrigo que dissipa o temor e ilumina a natureza dos fenômenos. Sudhana se prostra, torna a circundar o mestre centenas de milhares de vezes e se senta com as mãos juntas em homenagem. Diz ter desenvolvido a aspiração pela iluminação completa e pede orientação: quer saber como um bodhisattva deve treinar e praticar a conduta dos bodhisattvas."
    speaker_012 "Aspiro à iluminação completa. Como posso compreender o treinamento e a prática da conduta dos bodhisattvas?"
    speaker_020 "A orientação de um bom amigo espiritual é uma via para aprender o caminho verdadeiro."
    centered "Cena 3 — As flores dos dez mil jovens"
    narrator "O ṛṣi volta-se aos dez mil jovens brâmanes e apresenta Sudhana como alguém que desenvolveu a aspiração pela iluminação completa, convidou os seres a se libertarem do medo e deseja seu bem e felicidade. Descreve seu anseio por sabedoria, pelos ensinamentos dos tathāgatas e pelo crescimento das raízes de mérito de todos. Os jovens espalham flores coloridas e perfumadas sobre Sudhana, prestam-lhe homenagem e o circundam. Em suas palavras de louvor, anunciam que ele se tornará protetor dos seres e associam suas aspirações ao fim dos sofrimentos, à dissipação da ignorância e à revelação da sabedoria. Bhīṣmottaranirghoṣa acrescenta que a aspiração e a prática da conduta trazem felicidade aos seres e conduzem, por fim, à onisciência."
    speaker_020 "Jovens, Sudhana aspira à iluminação completa e deseja o benefício dos seres."
    speaker_021 "Que sua aspiração se torne proteção e sabedoria para todos os seres."
    narrator "O mestre afirma que a prática da conduta dos bodhisattvas leva à felicidade dos seres e à onisciência."
    centered "Cena 4 — O estandarte da invencibilidade"
    narrator "Bhīṣmottaranirghoṣa declara ter alcançado a libertação do bodhisattva chamada estandarte de ser invencível aos outros. Quando Sudhana pergunta sobre seu alcance, o ṛṣi estende a mão direita e toca sua cabeça. Sudhana percebe então campos de budas nas dez direções, incontáveis como átomos em milhões de campos; vê a si mesmo aos pés de incontáveis budas, suas assembleias, formas, sinais e raios de luz. Escuta os ensinamentos sem perder palavras, recebe rodas do Dharma distintas e a chuva do Dharma conforme as aspirações dos seres. A narrativa também descreve sua percepção de orações, corpos e poderes dos budas, além da iluminação de diversos samādhis e conhecimentos."
    speaker_012 "Que alcance tem a libertação chamada estandarte de ser invencível aos outros?"
    narrator "Ao toque do mestre, Sudhana percebe campos de budas e ensinamentos em vastíssima multiplicidade."
    speaker_012 "As rodas do Dharma se distinguem, e cada ensinamento chega sem que eu perca uma palavra."
    centered "Cena 5 — A bênção lembrada e o próximo mestre"
    narrator "A experiência de Sudhana abrange períodos junto a diferentes tathāgatas que vão de um dia e uma noite a durações expressas em kalpas incontáveis. Bhīṣmottaranirghoṣa finalmente solta sua cabeça; Sudhana percebe que está outra vez sentado diante do ṛṣi e confirma que se lembra da bênção do bom amigo espiritual. O mestre esclarece que conhece somente aquela libertação e não pode descrever a amplitude das qualidades e realizações dos bodhisattvas avançados. Então orienta Sudhana a seguir para a região sul, à terra chamada Īṣāṇa, onde vive o brâmane Jayoṣmāyatana, e a perguntar-lhe como os bodhisattvas treinam e praticam sua conduta. Alegre, Sudhana reverencia e circunda o ṛṣi, olha para trás repetidas vezes e parte."
    speaker_020 "Você se recorda do que percebeu?"
    speaker_012 "Recordo a bênção do bom amigo espiritual."
    speaker_020 "Procure Jayoṣmāyatana em Īṣāṇa e pergunte-lhe sobre o treinamento e a prática da conduta dos bodhisattvas."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o encontro, que aspecto da orientação de Bhīṣmottaranirghoṣa você gostaria de considerar antes de prosseguir?"
        "O papel do bom amigo espiritual":
            narrator "As instruções do bom amigo espiritual são apresentadas como via para a onisciência."
        "A aspiração pelo benefício dos seres":
            narrator "O mestre relaciona aspiração e prática à felicidade dos seres."
        "A lembrança da bênção":
            narrator "Sudhana diz recordar a bênção do bom amigo espiritual."
    call quiz_ch11
    menu:
        "Continuar — capítulo 12":
            jump chapter_12
        "Voltar ao índice":
            jump chapter_index

label quiz_ch11:
    centered "Reconheça a libertação"
    narrator "Escolha a resposta que corresponde ao nome da libertação que Bhīṣmottaranirghoṣa diz ter alcançado."
    while True:
        menu:
            "Como o texto chama a libertação do bodhisattva alcançada pelo ṛṣi?"
            "Estandarte de ser invencível aos outros":
                if 0 == 0:
                    narrator "Correto: esse é o nome da libertação declarado pelo ṛṣi."
                    return
                else:
                    narrator "Releia o nome da libertação anunciado por Bhīṣmottaranirghoṣa."
            "Roda da essência do sol":
                if 1 == 0:
                    narrator "Correto: esse é o nome da libertação declarado pelo ṛṣi."
                    return
                else:
                    narrator "Releia o nome da libertação anunciado por Bhīṣmottaranirghoṣa."
            "Rede voltada para todas as direções":
                if 2 == 0:
                    narrator "Correto: esse é o nome da libertação declarado pelo ṛṣi."
                    return
                else:
                    narrator "Releia o nome da libertação anunciado por Bhīṣmottaranirghoṣa."

label chapter_12:
    hide screen master_provisional_badge
    scene bg_ch12 with dissolve
    show master_ch12_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 12 — Jayoṣmāyatana"
    centered "Cena 1 — A chegada a Īṣāṇa"
    narrator "A sabedoria de Sudhana é apresentada como vasta: ele contempla a amplitude das práticas dos bodhisattvas, os diferentes mundos e seres, e mantém a aspiração de guiá-los. Concentrado no bom amigo espiritual, chega à terra de Īṣāṇa e procura o brâmane Jayoṣmāyatana. O mestre pratica austeridade extrema: há fogueiras do tamanho de montanhas nos quatro lados, enquanto acima se ergue um precipício, com um caminho de lâminas que sobe pela encosta. Sudhana se inclina aos pés do brâmane, senta-se diante dele e pergunta como os bodhisattvas treinam e praticam sua conduta."
    speaker_012 "Desenvolvi a aspiração à iluminação completa. Peço orientação sobre como treinar e praticar a conduta do bodhisattva."
    speaker_022 "A resposta que ofereço está diante de ti: sobe pelo caminho da encosta e salta na fogueira."
    centered "Cena 2 — A dúvida e a voz dos Brahmās"
    narrator "Sudhana pondera que é raro nascer humano, encontrar um buddha, ouvir o Buddhadharma, ter os sentidos íntegros e encontrar um bom amigo espiritual. Por isso, teme que a ordem seja uma armadilha que destrua seus méritos ou o afaste da onisciência. Então, dez mil Brahmās no céu pedem que não permaneça preso à suspeita. Eles descrevem Jayoṣmāyatana como alguém de diligência inabalável, empenhado em cortar visões errôneas, dissipar aflições e afastar os seres do medo da velhice e da morte. Recordam que sua austeridade levou Brahmās orgulhosos a abandonar concepções equivocadas e receber ensinamentos de amor, compaixão e aspiração à iluminação."
    speaker_012 "Como posso saber se esta instrução conduz ao Dharma ou cria um obstáculo à minha aspiração?"
    speaker_023 "Considera o que sua disciplina produziu: muitos vieram a ele e receberam ensinamentos que os afastaram de visões errôneas."
    centered "Cena 3 — Os devas relatam os frutos da austeridade"
    narrator "Os relatos celestes se sucedem. Māras dizem que a luz da austeridade superou suas moradas e que os ensinamentos curaram suas mentes e os firmaram na aspiração à iluminação. Vaśavartin descrevem domínio da própria mente, das aflições e das meditações; Sunirmita relata purificação da mente, desenvolvimento das qualidades búdicas e purificação do corpo e da fala. Saṃtuṣita ouvem ensinamentos para não depender dos objetos dos sentidos, cultivar mérito e cumprir o Buddhadharma; Suyāma abandonam o deleite nos desejos. Śakras deixam de se apegar às diversões de seus palácios e ouvem que tais coisas são impermanentes, instáveis e sujeitas à decadência. Os relatos associam a disciplina do brâmane a diferentes mudanças e aspirações, não a um único resultado uniforme."
    speaker_024 "A luz nos alcançou, e o ensinamento nos conduziu à aspiração pela iluminação."
    speaker_025 "Ouvimos que aquilo que apreciávamos é instável; agora voltamos nossa aspiração à iluminação mais elevada."
    centered "Cena 4 — Seres de muitos domínios se aproximam"
    narrator "Nāgas contam que a luz do fogo iluminou suas moradas, afastou chuvas de areia e o temor dos garuḍas, pacificou a ira e favoreceu serenidade; depois, receberam ensinamentos para abandonar condutas nocivas, confessar transgressões e aspirar à iluminação. Yakṣas relatam que eles e outros seres desenvolveram uma mente amorosa, foram tocados por luz e bem-estar e ouviram ensinamentos para aspirar à iluminação. Gandharvas dizem que a luz lhes trouxe bem-aventurança e que progrediram irreversivelmente. Asuras relatam que a disciplina abalou seu orgulho e os conduziu à paciência diante do Dharma profundo. Garuḍas ouviram ensinamentos de grande amor e compaixão, sabedoria e meios hábeis para guiar seres conforme o que os amadurece."
    speaker_026 "A serenidade que surgiu abriu espaço para abandonar ações nocivas e aspirar à iluminação."
    speaker_027 "O ensinamento nos orientou a cultivar compaixão e a guiar os seres de acordo com seu amadurecimento."
    centered "Cena 5 — Sons do Dharma e a luz que alcança os infernos"
    narrator "Kinnaras contam que, durante a austeridade, sons de “Buddha”, “Dharma”, “Saṅgha” e de aspirações de bodhisattvas ressoaram em palmeiras, instrumentos, ornamentos, casas e brisas de seu domínio. Ouvir nomes de tathāgatas, preces e diferentes condutas de bodhisattvas lhes trouxe alegria; Jayoṣmāyatana ensinou-os a avançar sem retroceder rumo à iluminação. Incontáveis devas do reino do desejo relatam que outra luz, vinda das fogueiras, alcançou seres até o inferno Avīci e extinguiu sofrimentos dos seres nos infernos. Eles viram a imagem do brâmane, foram à sua presença e receberam ensinamentos para aspirar à iluminação de seres sem limite."
    speaker_028 "Em nosso domínio, ouvimos palavras ligadas ao Buddha, ao Dharma, à Saṅgha e às aspirações dos bodhisattvas."
    speaker_029 "Ouvimos ensinamentos que nos levaram a desejar a iluminação de incontáveis seres."
    centered "Cena 6 — A travessia e a próxima indicação"
    narrator "Ao ouvir os relatos, Sudhana se alegra e reconhece Jayoṣmāyatana como verdadeiro bom amigo espiritual. Ele admite sua transgressão por ter desobedecido à instrução. O brâmane recita uma estrofe sobre seguir as instruções do guru para alcançar os objetivos e a sabedoria búdica. Sudhana então sobe pelo caminho de lâminas e salta na grande fogueira. Ao saltar, alcança o samādhi chamado completamente estável; ao pousar no fogo, alcança o samādhi chamado percepção da bem-aventurança da paz. Diz que o toque do fogo e o caminho da montanha foram bem-aventurados. Jayoṣmāyatana declara conhecer somente a libertação do domínio incessante e o encaminha a Maitrayaṇī, na cidade de Siṃhavijṛmbhita. Sudhana reverencia o brâmane e parte."
    speaker_012 "Agora reconheço o sentido da instrução. O caminho e o fogo foram, para mim, contatos de bem-aventurança."
    speaker_022 "Conheço apenas esta libertação. Procura Maitrayaṇī em Siṃhavijṛmbhita e pergunta sobre a prática dos bodhisattvas."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Diante da ordem de Jayoṣmāyatana, que reflexão opcional você escolheria para acompanhar a pausa de Sudhana?"
        "Recordar o valor raro de ouvir o Dharma":
            narrator "A reflexão retoma a preocupação de Sudhana antes de ouvir os Brahmās."
        "Considerar os relatos sobre os efeitos da disciplina":
            narrator "A atenção se volta ao que os seres contam; a sequência do capítulo continua igual."
        "Observar como Sudhana reconhece seu bom amigo espiritual":
            narrator "A reflexão acompanha a mudança de entendimento de Sudhana; os acontecimentos não se alteram."
    call quiz_ch12
    menu:
        "Continuar — capítulo 13":
            jump chapter_13
        "Voltar ao índice":
            jump chapter_index

label quiz_ch12:
    centered "Qual ensinamento foi relatado?"
    narrator "Escolha a resposta que corresponde a um ensinamento explícito deste capítulo. Minijogo não canônico."
    while True:
        menu:
            "Que mudança os Śakras dizem ter sido ensinada por Jayoṣmāyatana?"
            "Abandonar o deleite nos desejos, reconhecendo-os como impermanentes, instáveis e decadentes.":
                if 0 == 0:
                    narrator "Correto: os Śakras relatam o ensinamento sobre a impermanência e o abandono do apego aos desejos."
                    return
                else:
                    narrator "Tente novamente: recorde o que os Śakras dizem ter ouvido sobre as coisas de que gostavam."
            "Buscar maior prazer nos palácios e nas músicas divinas.":
                if 1 == 0:
                    narrator "Correto: os Śakras relatam o ensinamento sobre a impermanência e o abandono do apego aos desejos."
                    return
                else:
                    narrator "Tente novamente: recorde o que os Śakras dizem ter ouvido sobre as coisas de que gostavam."
            "Deixar de ouvir qualquer ensinamento para preservar a serenidade.":
                if 2 == 0:
                    narrator "Correto: os Śakras relatam o ensinamento sobre a impermanência e o abandono do apego aos desejos."
                    return
                else:
                    narrator "Tente novamente: recorde o que os Śakras dizem ter ouvido sobre as coisas de que gostavam."

label chapter_13:
    hide screen master_provisional_badge
    scene bg_ch13 with dissolve
    show master_ch13_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 13 — Maitrayaṇī"
    centered "Cena 1 — À procura da mestra"
    narrator "Com aspiração vasta e dedicado a buscar bons amigos espirituais, Sudhana chega a Siṃhavijṛmbhita para encontrar Maitrayaṇī. Ouve que ela é filha do rei Siṃhaketu e ensina o Dharma no palácio Vairocanagarbha, acompanhada por quinhentas jovens. O ensinamento atrai centenas e milhares de pessoas. Sudhana vai à residência real e aguarda no portão exterior. Ao perguntar às pessoas de onde vêm, descobre que vieram para ouvir Maitrayaṇī. Percebendo que a entrada está aberta aos visitantes, atravessa o portão e entra no palácio."
    speaker_012 "Procuro Maitrayaṇī. Este é o caminho para ouvir seu ensinamento?"
    speaker_030 "Viemos de diversos lugares para escutar o Dharma que ela ensina."
    centered "Cena 2 — O palácio que reflete os budas"
    narrator "Dentro do Vairocanagarbha, Sudhana contempla o brilho de pisos de cristal, pilares de berilo e paredes de diamante, junto a espelhos feitos de materiais preciosos, joias e sinos dourados. Maitrayaṇī está sentada num trono com pernas de sândalo uragasāra, rede de fios de ouro e almofada de material divino. Ela o convida a observar. Em cada parede, pilar, espelho, forma, joia, sino, árvore preciosa e fio de joias, Sudhana vê imagens dos tathāgatas: suas aspirações, práticas, orações, iluminação, ensinamento do Dharma e passagem ao nirvāṇa. O que aparece num objeto também aparece em todos os outros, como reflexos num lago límpido."
    speaker_031 "Volte sua atenção para o que se manifesta neste palácio."
    speaker_012 "Em cada detalhe, vejo as imagens dos tathāgatas e os caminhos que percorreram."
    centered "Cena 3 — A exibição completa"
    narrator "Depois de guardar na memória a visão, Sudhana volta o olhar para Maitrayaṇī e pede orientação sobre o treinamento e a prática da conduta de bodhisattva. Ela explica que realizou a porta da perfeição da sabedoria chamada exibição completa, após buscá-la junto a incontáveis tathāgatas, cada qual apresentando uma porta distinta. Ao contemplar, praticar, compreender e analisar esse ensinamento, desenvolveu a retenção chamada portas completas, na qual se reúnem incontáveis portas do Dharma. Entre elas estão as relativas aos budas, seres, passado, futuro e presente, mérito, sabedoria, conduta, karma, samādhi, mente, mundos, compaixão e diferentes ensinamentos."
    speaker_012 "Como posso compreender melhor a prática dos bodhisattvas?"
    speaker_031 "Minha realização é a porta da sabedoria chamada exibição completa, que abrange incontáveis portas do Dharma."
    centered "Cena 4 — O próximo mestre"
    narrator "Maitrayaṇī declara conhecer apenas a exibição completa e não pretende descrever as qualidades dos bodhisattvas cuja compreensão e sabedoria são ilimitadas. Em vez disso, orienta Sudhana a seguir para a região meridional de Trinayana, onde vive o bhikṣu Sudarśana. Ele deverá perguntar-lhe como um bodhisattva se treina na conduta e como a pratica. Sudhana então inclina a cabeça aos pés de Maitrayaṇī e a circunda muitas centenas de milhares de vezes, mantendo-a à sua direita. Ao partir, olha para trás repetidamente. O capítulo encerra com sua saída da presença da mestra e com a indicação do próximo encontro em sua busca."
    speaker_031 "Em Trinayana, procure o bhikṣu Sudarśana e pergunte-lhe sobre treinamento e prática."
    speaker_012 "Seguirei sua indicação e levarei essa pergunta ao próximo mestre."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Maitrayaṇī você gostaria de levar consigo nesta jornada?"
        "A multiplicidade das portas do Dharma":
            narrator "A reflexão pode acompanhar sua leitura; a narrativa segue como no capítulo."
        "As imagens dos tathāgatas em cada objeto":
            narrator "Você retém essa imagem como reflexão; a narrativa segue sem mudança."
        "A busca contínua por orientação":
            narrator "Você escolhe essa reflexão; Sudhana continua conforme o texto."
    call quiz_ch13
    menu:
        "Continuar — capítulo 14":
            jump chapter_14
        "Voltar ao índice":
            jump chapter_index

label quiz_ch13:
    centered "O palácio-reflexo"
    narrator "Escolha a opção que corresponde ao que Sudhana vê no palácio."
    while True:
        menu:
            "Onde aparecem as imagens dos tathāgatas contempladas por Sudhana?"
            "Em cada objeto de percepção do palácio.":
                if 0 == 0:
                    narrator "Correto: as imagens aparecem em cada objeto de percepção do palácio."
                    return
                else:
                    narrator "Relembre a visão descrita: ela se manifesta em todos os objetos de percepção do palácio."
            "Somente no trono de Maitrayaṇī.":
                if 1 == 0:
                    narrator "Correto: as imagens aparecem em cada objeto de percepção do palácio."
                    return
                else:
                    narrator "Relembre a visão descrita: ela se manifesta em todos os objetos de percepção do palácio."
            "Apenas nos espelhos redondos.":
                if 2 == 0:
                    narrator "Correto: as imagens aparecem em cada objeto de percepção do palácio."
                    return
                else:
                    narrator "Relembre a visão descrita: ela se manifesta em todos os objetos de percepção do palácio."

label chapter_14:
    hide screen master_provisional_badge
    scene bg_ch14 with dissolve
    show master_ch14_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 14 — Sudarśana"
    centered "Cena 1 — A busca na terra de Trinayana"
    narrator "Enquanto reflete sobre a conduta profunda dos bodhisattvas, Sudhana contempla a base do reino dos fenômenos, a origem dependente, a natureza, a linguagem dos seres, os processos do corpo e suas transformações, entre outros temas. Em seguida, chega à terra de Trinayana e procura o bhikṣu Sudarśana por toda parte: nas povoações e mercados, nos eremitérios dos ṛṣis, nas margens dos rios, nas cavernas montanhosas e nas grandes florestas. Por fim, avista o mestre dentro de uma floresta espessa."
    speaker_012 "Que eu não me detenha apenas nas palavras: quero compreender como essa conduta é praticada."
    narrator "A busca de Sudhana atravessa muitos lugares de Trinayana; o encontro ocorre numa floresta espessa."
    centered "Cena 2 — O bhikṣu na passarela de meditação"
    narrator "Sudarśana é descrito com os sinais de um ser superior, um halo de uma braça e corpo dourado. Mantém-se atento, sereno e sem vacilação, caminhando nem depressa nem devagar pela passarela de meditação. Devas, nāgas, yakṣas, gandharvas, asuras, garuḍas, kinnaras, mahoragas, Śakra, Brahmā, guardiões do mundo, humanos e não humanos o rodeiam. Quando muda a direção do percurso, devas transformam o campo das direções; outros recebem seus passos sobre lótus preciosos, dissipam a escuridão, fazem chover flores e espalham perfumes, incenso e joias, enquanto seres prestam homenagem."
    narrator "O relato apresenta Sudarśana caminhando com atenção e serenidade, cercado por seres de muitas classes."
    speaker_012 "Mestre, vejo aqui uma presença diante da qual devo primeiro prestar reverência."
    centered "Cena 3 — O pedido e a longa formação"
    narrator "Sudhana inclina a cabeça aos pés de Sudarśana, presta-lhes reverência e depois se senta diante dele com as mãos unidas. Declara sua aspiração à iluminação completa e pede que o bhikṣu explique como os bodhisattvas devem treinar e praticar sua conduta. Sudarśana responde que entrou recentemente na vida sem lar, já na idade adulta, mas que nesta vida praticou celibato diante de tathāgatas tão numerosos quanto grãos de areia em trinta e oito rios Ganges. Os períodos variaram de um dia e uma noite a kalpas; de todos ouviu o Dharma e recebeu instruções."
    speaker_012 "Aspiro à iluminação completa. Como devo treinar e praticar a conduta de bodhisattva?"
    speaker_032 "Minha entrada na vida sem lar foi recente; minha escuta do Dharma, porém, abrangeu incontáveis mestres e durações distintas."
    centered "Cena 4 — A lâmpada de sabedoria nunca extinta"
    narrator "Sudarśana relata ter purificado votos e campos de conduta, completado um oceano de perfeições, percebido manifestações da budeidade e preservado ensinamentos. Explica que, por aspirações, samādhis e conduta excelente, percebe inumeráveis campos, práticas dos seres, terras de budas, samādhis, poderes e rodas do tempo; essas percepções se vinculam a purificar a conduta, fazer oferendas, servir tathāgatas, sustentar o Dharma e girar suas rodas. Ele identifica sua libertação como a lâmpada de sabedoria nunca extinta. Contudo, afirma conhecer apenas essa libertação e não poder descrever as qualidades dos bodhisattvas de aspiração vajra e realizações vastas."
    speaker_032 "Minha compreensão é a libertação da lâmpada de sabedoria que nunca se extingue."
    speaker_012 "E para onde devo seguir para continuar aprendendo a conduta dos bodhisattvas?"
    speaker_032 "Na cidade de Sumukha, na terra de Śramaṇamaṇḍala, vive o jovem Indriyeśvara. Pergunte a ele sobre treino e prática."
    centered "Cena 5 — Reverência e partida"
    narrator "Depois da orientação, Sudhana permanece dedicado à prática e à potência dos bodhisattvas. O texto o caracteriza como incansável, resoluto, desejoso de receber os ensinamentos como chuva do Dharma, de realizar as qualidades dos bodhisattvas e de conduzir os seres para além da grande floresta do saṃsāra. Ele reverencia os bons amigos espirituais e desenvolve veneração imensurável pelo Dharma. Então inclina novamente a cabeça aos pés de Sudarśana, circunda-o centenas de milhares de vezes mantendo-o à direita e, olhando para trás repetidamente, parte. A narrativa encerra a visita com a indicação do próximo mestre, sem descrever o encontro com Indriyeśvara."
    narrator "Sudarśana indicou o próximo mestre; a visita termina com a partida de Sudhana."
    speaker_012 "Levarei comigo esta orientação e seguirei até Sumukha para continuar a busca."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao ouvir Sudarśana dizer que conhece somente a libertação da lâmpada de sabedoria nunca extinta, em que aspecto você refletiria antes de seguir a indicação dele?"
        "A importância de reconhecer os limites do próprio conhecimento":
            narrator "Essa reflexão acompanha a humildade expressa pelo mestre."
        "A relação entre aspiração, prática e sabedoria":
            narrator "Essa reflexão retoma os temas ensinados por Sudarśana."
        "A continuidade da busca por bons mestres":
            narrator "Essa reflexão ecoa a direção dada a Sudhana."
    call quiz_ch14
    menu:
        "Continuar — capítulo 15":
            jump chapter_15
        "Voltar ao índice":
            jump chapter_index

label quiz_ch14:
    centered "Identifique a libertação"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito de Sudarśana."
    while True:
        menu:
            "Como se chama a libertação que Sudarśana diz conhecer?"
            "A lâmpada de sabedoria nunca extinta":
                if 0 == 0:
                    narrator "Correto: Sudarśana nomeia a libertação como a lâmpada de sabedoria nunca extinta."
                    return
                else:
                    narrator "Releia o ensinamento: esse é o nome que Sudarśana dá à libertação que conhece."
            "O oceano de todos os samādhis":
                if 1 == 0:
                    narrator "Correto: Sudarśana nomeia a libertação como a lâmpada de sabedoria nunca extinta."
                    return
                else:
                    narrator "Releia o ensinamento: esse é o nome que Sudarśana dá à libertação que conhece."
            "A roda das direções celestes":
                if 2 == 0:
                    narrator "Correto: Sudarśana nomeia a libertação como a lâmpada de sabedoria nunca extinta."
                    return
                else:
                    narrator "Releia o ensinamento: esse é o nome que Sudarśana dá à libertação que conhece."

label chapter_15:
    hide screen master_provisional_badge
    scene bg_ch15 with dissolve
    show master_ch15_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 15 — Indriyeśvara"
    centered "Cena 1 — À procura do menino na confluência"
    narrator "Após recitar, examinar e contemplar repetidamente o ensinamento do bhikṣu Sudarśana, Sudhana segue viagem acompanhado por devas, nāgas, yakṣas e gandharvas. Ele chega a Sumukha, na região de Śramaṇamaṇḍala, e procura o menino Indriyeśvara. Do céu, os seres celestiais indicam a confluência dos rios: ali, dizem, o menino está brincando na areia com outras dez mil crianças. Sudhana vai até lá e encontra o grupo. Aproxima-se de Indriyeśvara, curva a cabeça aos pés dele, dá muitas voltas ao seu redor mantendo-o à direita e senta-se diante do menino, com as mãos unidas."
    speaker_033 "Nobre viajante, Indriyeśvara está na confluência dos rios, brincando na areia com muitas crianças."
    speaker_012 "Indriyeśvara, busco compreender como se aprende e se pratica a conduta de um bodhisattva."
    speaker_034 "Pergunte, Sudhana. Vou lhe mostrar o que aprendi e o alcance do que posso ensinar."
    centered "Cena 2 — Sabedoria que atravessa as artes"
    narrator "Indriyeśvara relata que Mañjuśrī Kumārabhūta lhe ensinou escrita, números, símbolos e contagem; por essa via, entrou na sabedoria que possui clarividência em todas as artes. Enumera conhecimentos de linguagem e cálculo, ofícios, fisiologia e métodos contra venenos; também menciona práticas de agricultura e comércio, construção de povoações e edifícios, máquinas, sinais auspiciosos ou perigosos e formas de compreender caminhos de karma e acumulações ligados a diferentes destinos e veículos. Seu papel não é apenas saber: afirma conduzir os seres a esses conhecimentos, fazê-los estudar, praticar, aperfeiçoar e completar sua compreensão. Assim, a instrução associa uma ampla variedade de saberes ao cultivo e à transmissão deliberada deles."
    speaker_034 "Mañjuśrī Kumārabhūta me ensinou letras, números, símbolos e contagem."
    speaker_012 "Então esse aprendizado alcança saberes muito diferentes entre si."
    speaker_034 "E procuro ajudar os seres a entrar neles, praticá-los e torná-los completos."
    centered "Cena 3 — Contar a vastidão"
    narrator "Indriyeśvara apresenta uma longa escala de nomes numéricos, em que cada termo sucessivo resulta da multiplicação do anterior por si mesmo. Para demonstrar o método, conta os grãos de um monte de areia que se ergue muitos yojanas diante dele, levando a contagem até uma denominação extrema, anabhilāpyānabhilāpyaparivarta. Explica que o cálculo dos bodhisattvas pode ser aplicado à extensão dos mundos nas direções leste, sul, oeste, norte, nas quatro diagonais, acima e abaixo. O mesmo método abrange sucessões de nomes de mundos, kalpas, budas, Dharmas, seres e ações. Sudhana recebe uma mostra de uma escala que, segundo o menino, permite abarcar conjuntos vastíssimos."
    speaker_034 "A escala de cálculo avança por uma sequência de grandezas cada vez mais vastas."
    speaker_012 "E o monte de areia serve de exemplo para aplicar essa contagem."
    speaker_034 "Com esse método, podem-se contar sucessões de mundos nas dez direções e de muitos outros nomes."
    centered "Cena 4 — O limite declarado e a próxima mestra"
    narrator "Apesar da amplitude dessa sabedoria, Indriyeśvara distingue o que conhece do que não pode explicar: chama sua realização de apenas uma luz da sabedoria dos bodhisattvas, ligada à clarividência das artes e ao conhecimento dos fenômenos. Ele não reivindica descrever plenamente a conduta, as qualidades, as atividades ou a sabedoria dos bodhisattvas. Então encaminha Sudhana à upāsikā Prabhūtā, que vive em Samudrapratiṣṭhāna, na região sul, para perguntar sobre o treinamento e a prática da conduta de bodhisattva. Ao ouvir as palavras do mestre, Sudhana sente grande alegria e reconhece ter recebido uma motivação rara. Reverencia Indriyeśvara, dá muitas voltas ao seu redor e parte, olhando para trás repetidamente."
    speaker_034 "Conheço esta parcela luminosa da sabedoria; não posso abarcar nem descrever toda a vastidão da conduta dos bodhisattvas."
    speaker_034 "Siga para Samudrapratiṣṭhāna e pergunte à upāsikā Prabhūtā sobre treinamento e prática."
    speaker_012 "Recebo este encaminhamento com alegria e seguirei em busca de sua orientação."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Indriyeśvara você escolheria levar consigo nesta pausa de reflexão?"
        "A variedade de conhecimentos que ele transmite":
            narrator "A resposta destaca que ele conduz outros seres ao estudo e à prática de muitos saberes."
        "A escala usada para contar mundos e sucessões de nomes":
            narrator "A resposta retoma o método de cálculo apresentado pelo menino."
        "A honestidade sobre os limites do próprio conhecimento":
            narrator "A resposta lembra que Indriyeśvara reconhece conhecer apenas uma parcela da sabedoria dos bodhisattvas."
    call quiz_ch15
    menu:
        "Continuar — capítulo 16":
            jump chapter_16
        "Voltar ao índice":
            jump chapter_index

label quiz_ch15:
    centered "A quem Sudhana deve procurar?"
    narrator "Escolha a resposta conforme o encaminhamento explícito de Indriyeśvara."
    while True:
        menu:
            "Qual mestra Indriyeśvara indica a Sudhana como próxima interlocutora?"
            "A upāsikā Prabhūtā, em Samudrapratiṣṭhāna.":
                if 0 == 0:
                    narrator "Correto: Indriyeśvara o encaminha à upāsikā Prabhūtā, em Samudrapratiṣṭhāna."
                    return
                else:
                    narrator "Releia o encaminhamento: a próxima mestra indicada é Prabhūtā, em Samudrapratiṣṭhāna."
            "O bhikṣu Sudarśana, na cidade de Sumukha.":
                if 1 == 0:
                    narrator "Correto: Indriyeśvara o encaminha à upāsikā Prabhūtā, em Samudrapratiṣṭhāna."
                    return
                else:
                    narrator "Releia o encaminhamento: a próxima mestra indicada é Prabhūtā, em Samudrapratiṣṭhāna."
            "Mañjuśrī Kumārabhūta, na confluência dos rios.":
                if 2 == 0:
                    narrator "Correto: Indriyeśvara o encaminha à upāsikā Prabhūtā, em Samudrapratiṣṭhāna."
                    return
                else:
                    narrator "Releia o encaminhamento: a próxima mestra indicada é Prabhūtā, em Samudrapratiṣṭhāna."

label chapter_16:
    hide screen master_provisional_badge
    scene bg_ch16 with dissolve
    show master_ch16_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 16 — Prabhūtā"
    centered "Cena 1 — A cidade e a busca"
    narrator "Sudhana recorda como as instruções dos mestres espirituais fizeram crescer suas capacidades e trouxeram clareza e serenidade à mente. Como quem busca água fresca sob o calor, ele anseia por continuar aprendendo; as imagens de chuva, lua e flores expressam o valor que atribui a esses ensinamentos. Por fim, chega a Samudrapratiṣṭhāna e procura a upāsikā Prabhūtā. Uma grande multidão lhe informa que ela está em sua casa, no meio da cidade. Sudhana segue até lá, junta as mãos em homenagem e espera à porta."
    speaker_012 "As instruções recebidas fizeram florescer em mim o desejo de continuar aprendendo."
    narrator "Em Samudrapratiṣṭhāna, a multidão aponta a casa de Prabhūtā, situada no centro da cidade."
    centered "Cena 2 — A anfitriã e o pequeno pote"
    narrator "Ao entrar, Sudhana vê a casa cercada por uma ampla parede preciosa, com uma entrada em cada direção. Prabhūtā está sentada num trono; o texto a descreve com veste branca e sem joias. Todos os seres que a veem a consideram sua mestra, e, salvo buddhas e bodhisattvas, os visitantes são dominados por sua presença. Há incontáveis assentos preciosos e dez mil donzelas diante dela, mas nenhum estoque visível de provisões: apenas um pequeno pote. O perfume das donzelas alcança a cidade e, segundo o relato, favorece mentes amorosas e sem hostilidade; suas vozes também alegram quem as ouve."
    speaker_012 "A casa está cheia de assentos, mas diante de você vejo apenas um pequeno pote."
    speaker_035 "Permaneça atento, Sudhana; este pote faz parte da libertação que alcancei."
    centered "Cena 3 — A libertação do tesouro de mérito"
    narrator "Sudhana homenageia Prabhūtā, senta-se diante dela e pergunta como os bodhisattvas devem treinar e praticar sua conduta. Ela responde que alcançou a libertação chamada manifestação incessante do tesouro de mérito. Do pote, explica, saem alimentos adequados aos desejos de seres incontáveis, em variedades de sabores, cores e aromas, sem que o recipiente se reduza ou se esvazie. Ela inclui bebidas, assentos, camas, vestes, flores, joias e muitos outros bens. Prabhūtā ainda ensina que, para śrāvakas e pratyekabuddhas em sua última vida, o alimento pode acompanhar a obtenção de seus respectivos frutos; para bodhisattvas em sua última vida, pode acompanhar a iluminação completa."
    speaker_012 "Como devo compreender a prática dos bodhisattvas e a libertação que você alcançou?"
    speaker_035 "Chamo-a manifestação incessante do tesouro de mérito: o pequeno pote satisfaz seres sem se esgotar."
    speaker_012 "E você afirma que os efeitos descritos se estendem pelas dez direções?"
    centered "Cena 4 — Uma demonstração e o próximo mestre"
    narrator "Prabhūtā pergunta se Sudhana vê as dez mil donzelas e descreve a conduta, as aspirações e as qualidades que compartilham com ela. Num único instante, elas percorrem as dez direções para levar alimento a bodhisattvas em sua última vida, a śrāvakas e pratyekabuddhas em sua última vida e a pretas. Então, seres convidados por antigas preces de Prabhūtā entram pelas portas leste, sul, oeste e norte. Ela os satisfaz com alimentos e numerosos outros bens, adequados a diferentes classes de seres; o pote não diminui. Prabhūtā diz conhecer apenas essa libertação e indica Vidvān, em Mahāsaṃbhava. Sudhana a homenageia e parte, olhando para trás repetidamente."
    speaker_035 "Aguarde um momento; você verá como os seres são satisfeitos."
    speaker_012 "Vejo as donzelas e a demonstração do que você explicou."
    speaker_035 "Procure Vidvān, na cidade de Mahāsaṃbhava, e pergunte-lhe sobre o treino dos bodhisattvas."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Que aspecto do ensinamento de Prabhūtā você gostaria de levar consigo?"
        "A generosidade que não se esgota":
            narrator "Você reflete sobre o pote que satisfaz seres sem jamais se esvaziar."
        "A atenção às necessidades diversas":
            narrator "Você recorda que os bens oferecidos variam conforme os seres e seus desejos."
        "A busca contínua por orientação":
            narrator "Você pensa na pergunta de Sudhana e no mestre a quem Prabhūtā o encaminha."
    call quiz_ch16
    menu:
        "Continuar — capítulo 17":
            jump chapter_17
        "Voltar ao índice":
            jump chapter_index

label quiz_ch16:
    centered "O nome da libertação"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito de Prabhūtā."
    while True:
        menu:
            "Como se chama a libertação do bodhisattva que Prabhūtā afirma ter alcançado?"
            "Manifestação incessante do tesouro de mérito":
                if 0 == 0:
                    narrator "Correto: esse é o nome que Prabhūtā dá à libertação que alcançou."
                    return
                else:
                    narrator "Releia a explicação de Prabhūtā: o nome inclui a manifestação incessante do tesouro de mérito."
            "A visão das quatro portas preciosas":
                if 1 == 0:
                    narrator "Correto: esse é o nome que Prabhūtā dá à libertação que alcançou."
                    return
                else:
                    narrator "Releia a explicação de Prabhūtā: o nome inclui a manifestação incessante do tesouro de mérito."
            "A voz pura das dez mil donzelas":
                if 2 == 0:
                    narrator "Correto: esse é o nome que Prabhūtā dá à libertação que alcançou."
                    return
                else:
                    narrator "Releia a explicação de Prabhūtā: o nome inclui a manifestação incessante do tesouro de mérito."

label chapter_17:
    hide screen master_provisional_badge
    scene bg_ch17 with dissolve
    show master_ch17_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 17 — Vidvān"
    centered "Cena 1 — A procura em Mahāsaṃbhava"
    narrator "Depois de obter a libertação chamada manifestação incessante do tesouro de mérito, Sudhana contempla e acumula mérito enquanto prossegue sua busca. Ao chegar a Mahāsaṃbhava, procura Vidvān, chefe de família, com anseio por mestres espirituais benéficos e dedicação a servi-los. Encontra-o no cruzamento central, sentado num trono sobre uma plataforma de sete materiais preciosos. O assento, os tecidos, as joias, as bandeiras e o dossel compõem uma exibição resplandecente; incensos perfumam o ar. Músicos estão à direita e à esquerda, e seres fazem cair flores celestiais. Sudhana aproxima-se, inclina a cabeça aos pés de Vidvān, circunda-o repetidas vezes e senta-se diante dele."
    speaker_012 "Mestre, venho buscar orientação para aprender a conduta dos bodhisattvas."
    narrator "Em Mahāsaṃbhava, a busca de Sudhana conduz ao encontro com Vidvān."
    centered "Cena 2 — A aspiração e o séquito"
    narrator "Com as mãos unidas, Sudhana explica que partiu em busca da iluminação completa para pôr fim ao sofrimento dos seres, conduzi-los à felicidade e levá-los à sabedoria. Reconhece que não sabe como os bodhisattvas devem treinar e praticar sua conduta, nem como podem tornar-se apoio para todos; pede que Vidvān o instrua. Vidvān acolhe a aspiração e ressalta como é rara a perseverança em buscar e servir mestres benéficos. Então pergunta se Sudhana vê os integrantes de seu séquito. Ao ouvir que sim, explica que os conduziu à aspiração pela iluminação, ao acúmulo das perfeições e às qualidades do caminho, até a compreensão da natureza verdadeira dos fenômenos. Assim, diz, bodhisattvas tornam-se refúgio para os seres."
    speaker_012 "Aspiro à iluminação para benefício de todos, mas ainda não sei como praticar essa conduta."
    speaker_036 "Sua aspiração é preciosa. Observe também aqueles que estão comigo e o caminho que cultivaram."
    speaker_012 "Vejo-os, mestre, e escuto sua explicação sobre como podem servir de refúgio."
    centered "Cena 3 — O tesouro da mente se manifesta"
    narrator "Vidvān explica que alcançou a libertação do bodhisattva chamada mérito surgido do tesouro da mente. Por seu poder, oferece aos seres aquilo que desejam: alimentos de diversos tipos, bebidas, vestes, flores, perfumes, remédios, assentos, utensílios e muitos outros bens. Convida Sudhana a aguardar uma demonstração. Como havia feito votos no passado, seres de diferentes lugares, famílias e modos de vida chegam com necessidades e preferências variadas. Vidvān percebe que os solicitantes se reuniram, olha para o céu e recebe nas mãos grande variedade de comida e bebida, com sabores, cores e aromas distintos. Distribui também utensílios conforme os pedidos; os presentes ficam saciados, contentes e alegres."
    speaker_036 "A libertação que alcancei permite atender aos desejos diversos dos que vêm até mim."
    speaker_036 "Aguarde um momento, Sudhana; você verá como essa generosidade se manifesta."
    speaker_012 "Vejo os pedidos serem atendidos de acordo com as necessidades de cada pessoa."
    centered "Cena 4 — Da satisfação ao ensinamento"
    narrator "Atendidos os pedidos, Vidvān ensina o Dharma. Expõe causas ligadas à reunião de sabedoria e mérito, à prosperidade, à felicidade, à força e à obtenção de qualidades próprias de um grande ser. Aos que desejam comida, ensina visando longevidade, aparência, força, felicidade e eloquência. Aos que querem bebida, ensina a abandonar a sede e o deleite no saṃsāra e a cultivar desejo pelo Buddhadharma. Depois de diferentes sabores, aponta o sabor supremo das marcas de um grande ser; a quem recebeu carruagens, ensina a seguir o Mahāyāna. Quando solicitantes de roupas chegam, faz surgir vestes puras de várias cores e as distribui, ensinando sobre o senso de vergonha e consciência puros e insuperáveis de um tathāgata. Assim demonstra o alcance inconcebível de sua libertação."
    speaker_036 "O atendimento aos desejos também abre espaço para ensinar o Dharma de modo pertinente."
    speaker_012 "Assim, aquilo que cada grupo recebe acompanha um ensinamento específico."
    centered "Cena 5 — O próximo mestre"
    narrator "Vidvān esclarece que conhece apenas a libertação do mérito surgido do tesouro da mente; não afirma conhecer toda a conduta, as qualidades ou os poderes de bodhisattvas que dominam outros meios de provisão e oferenda. Em seguida, orienta Sudhana a ir à cidade de Siṃhapota, na região sul, procurar Ratnacūḍa, patrono do Dharma, e perguntar como um bodhisattva deve treinar e praticar. Sudhana recebe a orientação com alegria e demonstra respeito por Vidvān como mestre benéfico, mantendo o compromisso de ouvir e seguir suas instruções. Inclina a cabeça aos pés dele, circunda-o muitas vezes, olha para trás repetidamente e parte. A fonte não narra o trajeto até a cidade seguinte."
    speaker_036 "Em Siṃhapota, procure Ratnacūḍa e pergunte-lhe sobre o treinamento e a prática dos bodhisattvas."
    speaker_012 "Partirei conforme sua orientação e seguirei buscando instruções para o caminho."
    narrator "Depois da homenagem e das despedidas, Sudhana deixa Vidvān olhando para trás repetidas vezes."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre a demonstração de Vidvān, que aspecto você escolheria destacar? A escolha não altera os acontecimentos do capítulo."
        "A generosidade que atende necessidades concretas":
            narrator "Uma reflexão coerente com os presentes distribuídos conforme os desejos dos solicitantes."
        "O ensinamento oferecido depois da satisfação":
            narrator "Uma reflexão coerente com a sequência descrita por este capítulo."
        "A orientação para buscar outro mestre":
            narrator "Uma reflexão coerente com a indicação de Ratnacūḍa em Siṃhapota."
    call quiz_ch17
    menu:
        "Continuar — capítulo 18":
            jump chapter_18
        "Voltar ao índice":
            jump chapter_index

label quiz_ch17:
    centered "Ligue o presente ao ensinamento"
    narrator "Escolha a resposta baseada no que Vidvān ensina explicitamente no capítulo. Minijogo não canônico."
    while True:
        menu:
            "Depois de receberem carruagens, a que Vidvān ensina os solicitantes a se dirigirem?"
            "A seguir o Mahāyāna.":
                if 0 == 0:
                    narrator "Correto: o capítulo diz que Vidvān ensina os beneficiados pelas carruagens a seguir o Mahāyāna."
                    return
                else:
                    narrator "Revise o trecho sobre as carruagens: Vidvān relaciona esse presente ao Mahāyāna."
            "A deixar de buscar qualquer ensinamento.":
                if 1 == 0:
                    narrator "Correto: o capítulo diz que Vidvān ensina os beneficiados pelas carruagens a seguir o Mahāyāna."
                    return
                else:
                    narrator "Revise o trecho sobre as carruagens: Vidvān relaciona esse presente ao Mahāyāna."
            "A permanecer na cidade de Mahāsaṃbhava.":
                if 2 == 0:
                    narrator "Correto: o capítulo diz que Vidvān ensina os beneficiados pelas carruagens a seguir o Mahāyāna."
                    return
                else:
                    narrator "Revise o trecho sobre as carruagens: Vidvān relaciona esse presente ao Mahāyāna."

label chapter_18:
    hide screen master_provisional_badge
    scene bg_ch18 with dissolve
    show master_ch18_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 18 — Ratnacūḍa"
    centered "Cena 1 — Encontro no mercado de Siṃhapota"
    narrator "Sudhana chega a Siṃhapota à procura de Ratnacūḍa, mercador-chefe e patrono do Dharma, e o encontra no meio do mercado. Presta-lhe homenagem, circunda-o e se senta diante dele. Sudhana explica que despertou a aspiração pela iluminação completa e suprema, mas ainda não sabe como os bodhisattvas devem treinar e praticar sua conduta. Pede instrução sobre o caminho que conduz à onisciência. Ratnacūḍa toma suas mãos e o leva para casa, convidando-o a observar a residência. Feita de ouro puro e brilhante do rio Jambu, ela é ampla e alta, cercada por prata e adornada com cristais, berilos, coral branco, pérolas vermelhas e outras joias; há também lagoas de esmeralda com água fresca e árvores preciosas."
    speaker_012 "Despertei a aspiração à iluminação suprema, mas ainda busco compreender como se treina e pratica a conduta do bodhisattva."
    speaker_012 "Ensina-me o caminho que conduz à onisciência."
    speaker_037 "Vem comigo. Quero que vejas minha casa e o que nela se manifesta."
    centered "Cena 2 — Dez andares de dádivas e assembleias"
    narrator "Ao entrar e percorrer os andares, Sudhana vê primeiro a distribuição de comida e bebida; no segundo, roupas; no terceiro, joias e adornos; no quarto, mulheres jovens descritas no texto como prazeres de haréns. O quinto reúne bodhisattvas do quinto bhūmi dedicados ao Dharma e ao bem-estar do mundo. No sexto, assembleias discutem muitas vias da perfeição da sabedoria. No sétimo, bodhisattvas alcançaram a paciência de perceber tudo como ecos; no oitavo, contemplam-se os de clarividência que não diminui e presença em todos os domínios do mundo. No nono, estão bodhisattvas em sua última vida. No décimo, Sudhana vê a aspiração, a conduta, as preces, os milagres, os domínios e as assembleias dos tathāgatas, além de seu ensino do Dharma e poder de guiar seres."
    speaker_012 "Cada andar revela uma forma diferente de generosidade ou uma assembleia dedicada ao Dharma."
    speaker_037 "Observa com atenção: a casa apresenta dádivas e visões que ultrapassam o que se vê em seus primeiros pisos."
    centered "Cena 3 — A oferenda e a próxima indicação"
    narrator "Depois de contemplar os andares, Sudhana pergunta como Ratnacūḍa obteve aquela boa fortuna. Ele recorda um passado remoto, no mundo Cakravicitra, quando o tathāgata Anantaraśmidharmadhātusamalaṃkṛtadharmarāja, acompanhado por uma grande comunidade, foi convidado pelo rei Dharmeśvararāja ao parque Maṇidhvajavyūharāja. Quando o tathāgata atravessou o mercado, Ratnacūḍa ofereceu música e queimou um pellet de incenso. Nuvens perfumadas multicoloridas cobriram Jambudvīpa por sete dias; delas vieram palavras sobre a sabedoria imaculada dos tathāgatas e o resultado incomensurável da oferenda. Ratnacūḍa diz que dedicou o mérito à visão completa de amigos espirituais, budas e bodhisattvas. Ele conhece apenas a libertação chamada exibição desimpedida do campo de aspiração e indica Samantanetra, mercador de perfumes em Samantamukha, Vetramūlaka. Sudhana se despede com reverência e parte, olhando para trás repetidas vezes."
    speaker_012 "Como surgiram essa boa fortuna e os méritos que amadureceram nesta casa?"
    speaker_037 "Atribuo meu mérito à oferenda de música e incenso e à dedicação para contemplar amigos espirituais, budas e bodhisattvas."
    speaker_037 "Conheço esta libertação, mas não posso descrever toda a conduta dos bodhisattvas. Procura Samantanetra, em Samantamukha."
    speaker_012 "Recebo tua indicação e sigo adiante, guardando este ensinamento em mente."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Na despedida, em qual aspecto da fala de Ratnacūḍa você prefere refletir? A escolha não altera o percurso de Sudhana."
        "A dedicação do mérito":
            narrator "A reflexão destaca que Ratnacūḍa dedicou o mérito à visão completa de amigos espirituais, budas e bodhisattvas."
        "A continuidade da busca":
            narrator "A reflexão destaca que Ratnacūḍa indica Samantanetra como próximo mestre a consultar."
        "A reverência na despedida":
            narrator "A reflexão destaca que Sudhana presta homenagem, circunda Ratnacūḍa e parte olhando para trás."
    call quiz_ch18
    menu:
        "Continuar — capítulo 19":
            jump chapter_19
        "Voltar ao índice":
            jump chapter_index

label quiz_ch18:
    centered "O que Sudhana viu no sexto andar?"
    narrator "Escolha a resposta que corresponde ao relato do capítulo."
    while True:
        menu:
            "Qual tema ocupava as assembleias de bodhisattvas no sexto andar?"
            "As muitas vias da perfeição da sabedoria.":
                if 0 == 0:
                    narrator "Correto: no sexto andar, bodhisattvas discutiam numerosas vias da perfeição da sabedoria."
                    return
                else:
                    narrator "Tente novamente: o capítulo associa o sexto andar à perfeição da sabedoria."
            "A distribuição de roupas.":
                if 1 == 0:
                    narrator "Correto: no sexto andar, bodhisattvas discutiam numerosas vias da perfeição da sabedoria."
                    return
                else:
                    narrator "Tente novamente: o capítulo associa o sexto andar à perfeição da sabedoria."
            "A visão dos tathāgatas em sua última vida.":
                if 2 == 0:
                    narrator "Correto: no sexto andar, bodhisattvas discutiam numerosas vias da perfeição da sabedoria."
                    return
                else:
                    narrator "Tente novamente: o capítulo associa o sexto andar à perfeição da sabedoria."

label chapter_19:
    hide screen master_provisional_badge
    scene bg_ch19 with dissolve
    show master_ch19_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 19 — Samantanetra"
    centered "Cena 1 — A busca em Vetramūlaka"
    narrator "Antes de chegar à terra de Vetramūlaka, Sudhana já havia percebido visões de incontáveis budas e alcançado a companhia de incontáveis bodisatvas. Sua mente fora iluminada pelos caminhos e pelo Dharma dos bodisatvas, e ele mantinha suas aspirações e condutas como referência. Em Vetramūlaka, procura por toda parte a cidade de Samantamukha, sem cansaço nem descuido, atravessando direções, distritos e subdistritos, lugares altos e baixos. Conserva no coração as instruções dos bons amigos espirituais e permanece atento com olhos e ouvidos. Por fim, encontra a cidade no centro da região: bem construída, com dez mil mercados, muralha alta e forte e oito encruzilhadas."
    speaker_012 "Não deixarei que a busca me distraia das instruções dos bons amigos espirituais."
    narrator "Sudhana procura em todas as direções, atento e determinado."
    centered "Cena 2 — A pergunta ao vendedor de perfumes"
    narrator "No centro da cidade, Sudhana vê Samantanetra, o vendedor de perfumes, em sua loja. Aproxima-se, inclina a cabeça aos pés do mestre e senta-se diante dele com as mãos juntas em homenagem. Sudhana apresenta sua aspiração à iluminação suprema e completa, mas admite que ainda não sabe como os bodisatvas devem se treinar na conduta dos bodisatvas nem como devem praticá-la. Samantanetra acolhe a aspiração como algo excelente. Em seguida, explica que conhece as enfermidades dos seres, provenientes de diferentes desequilíbrios, danos e perigos, e sabe como tratá-las por vários meios. O capítulo enumera tratamentos e cuidados, entre eles unguentos, repouso, antídotos e alimentação."
    speaker_012 "Aspiro à iluminação suprema e completa; como devo compreender o treino e a prática da conduta dos bodisatvas?"
    speaker_038 "É excelente que tenhas desenvolvido essa aspiração, nobre jovem."
    speaker_038 "Conheço as enfermidades dos seres e os meios de tratá-las."
    centered "Cena 3 — Cura e ensinamento do Dharma"
    narrator "Samantanetra diz que cura os seres que vêm a ele das dez direções. Depois da cura, providencia banho, unguentos, adornos, roupas, alimentos saborosos e riqueza. Então ensina o Dharma de acordo com o que pretende cultivar neles: ensinar a impureza serve para eliminar o desejo; louvar o amor, para eliminar a raiva; e expor categorias particulares dos fenômenos, para eliminar a ignorância. Outros ensinamentos apresentam as qualidades dos budas como causa para despertar a aspiração à iluminação, revelam os sofrimentos do saṃsāra para suscitar grande compaixão e louvam o acúmulo de mérito e sabedoria como causa de qualidades imensuráveis. Samantanetra também relaciona as perfeições à manifestação de diferentes aspectos do corpo do Tathāgata."
    speaker_038 "Aos seres curados, ofereço cuidados e depois ensino o Dharma."
    speaker_038 "A contemplação da impureza pode conduzir ao abandono do desejo; o ensinamento do amor, ao abandono da raiva."
    speaker_012 "Assim, o ensinamento é apresentado conforme aquilo que precisa ser cultivado ou abandonado."
    centered "Cena 4 — Perfumes que adornam as terras búdicas"
    narrator "Samantanetra afirma conhecer muitos perfumes, incensos, aromas, infusões, unguentos e combinações. Entre eles, conhece uma forma de perfume que satisfaz os seres e por meio da qual se veem, honram e presenteiam budas em qualquer lugar. Com ela, suas aspirações são cumpridas, e ele manifesta nuvens de adornos protetores, palácios e estruturas perfumadas para oferendas. As nuvens adornam terras búdicas com palácios, paredes, telhados, janelas, sacadas, estandartes, bandeiras, luzes e chuva de perfumes. Ainda assim, Samantanetra declara conhecer somente essa porta do Dharma. Indica então que Sudhana procure o rei Anala na cidade de Tāladhvaja, ao sul. Sudhana presta homenagem, circunda o mestre muitas centenas de milhares de vezes e parte, olhando para trás repetidamente."
    speaker_038 "Conheço a forma de perfume que satisfaz os seres e permite honrar e presentear os budas."
    speaker_038 "Minha compreensão se limita a esta porta do Dharma; segue para Tāladhvaja e pergunta ao rei Anala."
    speaker_012 "Recebo tua orientação e partirei para encontrar Anala."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o ensinamento de Samantanetra, qual relação entre prática e efeito você gostaria de considerar?"
        "A impureza como meio de eliminar o desejo":
            narrator "Essa relação foi explicitamente ensinada por Samantanetra."
        "O louvor ao amor como meio de eliminar a raiva":
            narrator "Essa relação também faz parte do ensinamento apresentado."
        "As categorias dos fenômenos como meio de eliminar a ignorância":
            narrator "Essa é outra relação que Samantanetra explicou."
    call quiz_ch19
    menu:
        "Continuar — capítulo 20":
            jump chapter_20
        "Voltar ao índice":
            jump chapter_index

label quiz_ch19:
    centered "Associe a perfeição"
    narrator "Escolha a associação explicitamente apresentada por Samantanetra."
    while True:
        menu:
            "Qual perfeição é descrita como causa para ensinar o corpo puro e insuperável do Tathāgata?"
            "A perfeição da meditação":
                if 0 == 0:
                    narrator "Correto: Samantanetra relaciona a perfeição da meditação a esse corpo puro."
                    return
                else:
                    narrator "Revise a relação entre as perfeições e os aspectos do corpo do Tathāgata ensinada por Samantanetra."
            "A perfeição da generosidade":
                if 1 == 0:
                    narrator "Correto: Samantanetra relaciona a perfeição da meditação a esse corpo puro."
                    return
                else:
                    narrator "Revise a relação entre as perfeições e os aspectos do corpo do Tathāgata ensinada por Samantanetra."
            "A perfeição da paciência":
                if 2 == 0:
                    narrator "Correto: Samantanetra relaciona a perfeição da meditação a esse corpo puro."
                    return
                else:
                    narrator "Revise a relação entre as perfeições e os aspectos do corpo do Tathāgata ensinada por Samantanetra."

label chapter_20:
    hide screen master_provisional_badge
    scene bg_ch20 with dissolve
    show master_ch20_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 20 — Anala"
    centered "Cena 1 — A chegada a Tāladhvaja"
    narrator "Recordando a sucessão de mestres espirituais e as instruções recebidas, Sudhana sente alegria e serenidade. Considera-se aceito como discípulo e protegido por esses mestres, e confia que não regredirá em seu avanço rumo à iluminação completa. Com essa disposição, segue de terra em terra, de cidade em cidade e de distrito em distrito, até chegar a Tāladhvaja. Ali pergunta onde está o rei Anala. Os moradores explicam que o soberano está sentado em seu trono, cumprindo deveres reais: governa, decide disputas, aplica punições e favorece quem merece favor. Também procuram afastar o povo de matar, roubar, mentir, caluniar, falar com aspereza ou inutilmente, cobiçar, agir com malícia e sustentar visões falsas."
    speaker_012 "Procuro o rei Anala. Podem me indicar onde ele está?"
    speaker_039 "Ele está no trono, cuidando dos deveres do reino e orientando a conduta de seus habitantes."
    centered "Cena 2 — A visão que causa dúvida"
    narrator "Anala aparece num grande trono adornado de joias, sob um guarda-sol precioso, com ministros ao redor. À sua frente, Sudhana vê servidores de aparência aterradora, armados e encarregados das punições. Também vê numerosas pessoas acusadas de diferentes crimes, presas e levadas diante do rei. A visão inclui execuções, sofrimento e sinais de morte; não é uma cena que Sudhana consiga conciliar de imediato com sua busca. Ele pensa que Anala parece cometer atos graves e se pergunta que ensinamento sobre a conduta de bodhisattva poderia receber de alguém associado a tamanha violência. Seu pensamento nasce enquanto se sente comprometido a proteger os seres e a buscar o bem deles."
    speaker_012 "Como posso conciliar esta visão com a busca de uma conduta dedicada ao bem dos seres?"
    narrator "A dúvida de Sudhana surge diante do sofrimento que ele presencia."
    centered "Cena 3 — O lembrete dos devas"
    narrator "Enquanto Sudhana contempla a cena, devas no céu o chamam à lembrança das instruções do sábio Jayoṣmāyatana. Sudhana olha para cima e confirma que se recorda. Os devas o advertem a não duvidar da orientação de um bom mestre: a sabedoria dos bodhisattvas em empregar meios hábeis, reunir discípulos, beneficiar, conduzir, proteger e amadurecer seres é inconcebível. Eles o incentivam a perguntar a Anala sobre a prática da conduta de bodhisattva. Sudhana então se aproxima do rei, presta reverência e circum-ambula-o, mantendo-o à sua direita. Com as mãos unidas, expõe sua aspiração à iluminação completa e pede instruções sobre como os bodhisattvas devem treinar e praticar."
    speaker_040 "Lembre-se do que Jayoṣmāyatana lhe ensinou; não julgue a instrução antes de perguntar."
    speaker_012 "Recordo-me. Quero compreender como se treina e se pratica a conduta de bodhisattva."
    speaker_040 "A sabedoria dos meios hábeis é inconcebível. Vá e pergunte ao rei."
    centered "Cena 4 — A explicação no palácio"
    narrator "Depois de concluir seus deveres reais, Anala se levanta e conduz Sudhana ao palácio, até o harém. O interior é vasto e ricamente adornado, com construções e objetos preciosos, um trono de coral branco, piscinas de água fresca e árvores feitas de materiais preciosos. Anala pede que Sudhana observe sua casa e seus bens e pergunta se tais perfeições poderiam ser o amadurecimento de ações más. Sudhana responde que não. Então o rei explica que alcançou a libertação de bodhisattva chamada “realização das ilusões”. Como muitos habitantes praticam as dez ações não virtuosas e não há outro meio de fazê-los desistir, ele manifesta imagens ilusórias de executores e condenados. Ao vê-las, os habitantes sentem medo e passam a evitar ações más."
    speaker_041 "Observe minha casa e meus bens; poderiam ser fruto de ações más?"
    speaker_012 "Não, senhor. Não reconheço nisso o amadurecimento de ações não virtuosas."
    speaker_041 "Minha libertação é a realização das ilusões; uso esse meio para afastar os seres do mal."
    centered "Cena 5 — Das dez ações virtuosas ao próximo mestre"
    narrator "Anala prossegue: quando os seres se alarmam com as imagens, ele os conduz para longe das dez ações não virtuosas e os estabelece nas dez virtuosas e no caminho da onisciência, apresentado como felicidade última e cessação do sofrimento. Afirma que não prejudica ser algum por corpo, fala ou mente, nem deseja causar dano mesmo ao menor inseto; diz também que não cultiva ações más nem em sonhos. Apesar disso, declara conhecer somente essa libertação e não poder descrever a realização de bodhisattvas que compreendem a natureza ilusória dos fenômenos e dos mundos e alcançam sabedoria e samādhi sem obstruções. Então envia Sudhana à cidade de Suprabha para perguntar ao rei Mahāprabha como treinar e praticar a conduta. Sudhana presta reverência, circum-ambula Anala e parte, olhando para trás repetidamente."
    speaker_041 "Quando o medo os faz abandonar o mal, conduzo-os às dez ações virtuosas e ao caminho da onisciência."
    speaker_012 "Compreendo que este ensinamento descreve o método que o senhor conhece; ainda buscarei aprender mais."
    speaker_041 "Siga para Suprabha e pergunte ao rei Mahāprabha sobre a conduta de bodhisattva."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Refletindo sobre a explicação de Anala, qual pergunta você levaria consigo? A escolha é opcional e não altera os acontecimentos do capítulo."
        "Como um meio hábil pode conduzir seres às ações virtuosas?":
            narrator "A reflexão acompanha o ensinamento de Anala; a jornada de Sudhana continua como na fonte."
        "Como reconhecer os limites do próprio conhecimento?":
            narrator "A reflexão ecoa a ressalva de Anala sobre o que sabe; a jornada de Sudhana continua como na fonte."
        "Como manter a aspiração de beneficiar todos os seres diante da dúvida?":
            narrator "A reflexão retoma a preocupação de Sudhana; a jornada continua sem mudança."
    call quiz_ch20
    menu:
        "Continuar — capítulo 21":
            jump chapter_21
        "Voltar ao índice":
            jump chapter_index

label quiz_ch20:
    centered "O método de Anala"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito do capítulo."
    while True:
        menu:
            "Segundo Anala, o que acontece depois que os habitantes veem as imagens ilusórias de punição e ficam alarmados?"
            "São conduzidos a abandonar as dez ações não virtuosas, adotar as dez virtuosas e seguir o caminho da onisciência.":
                if 0 == 0:
                    narrator "Correto: Anala descreve esse método como meio de afastar os seres do mal e orientá-los à via virtuosa."
                    return
                else:
                    narrator "Releia a explicação de Anala: o resultado é abandonar as dez ações não virtuosas, cultivar as dez virtuosas e seguir rumo à onisciência."
            "Recebem a ordem de deixar Tāladhvaja e ir para Suprabha.":
                if 1 == 0:
                    narrator "Correto: Anala descreve esse método como meio de afastar os seres do mal e orientá-los à via virtuosa."
                    return
                else:
                    narrator "Releia a explicação de Anala: o resultado é abandonar as dez ações não virtuosas, cultivar as dez virtuosas e seguir rumo à onisciência."
            "Anala abandona o reino e deixa de exercer seus deveres reais.":
                if 2 == 0:
                    narrator "Correto: Anala descreve esse método como meio de afastar os seres do mal e orientá-los à via virtuosa."
                    return
                else:
                    narrator "Releia a explicação de Anala: o resultado é abandonar as dez ações não virtuosas, cultivar as dez virtuosas e seguir rumo à onisciência."

label chapter_21:
    hide screen master_provisional_badge
    scene bg_ch21 with dissolve
    show master_ch21_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 21 — Mahāprabha"
    centered "Cena 1 — A busca por Suprabha"
    narrator "Sudhana recorda a contemplação da sabedoria como ilusão e reflete sobre a natureza ilusória dos fenômenos, das ações e das aparências dos três tempos. Sem se cansar, atravessa diferentes terras e direções, perguntando e procurando o rei Mahāprabha. Ao chegar perto de Suprabha, moradores identificam a cidade e confirmam que o rei vive ali. Sudhana se alegra: espera encontrar seu mestre benéfico e ouvir sobre a conduta, as qualidades e as práticas inconcebíveis dos bodhisattvas. Com esse propósito em mente, aproxima-se da cidade."
    speaker_012 "Que minha busca permaneça voltada à compreensão da conduta dos bodhisattvas."
    speaker_042 "Esta é Suprabha; o rei Mahāprabha vive aqui."
    narrator "A notícia da proximidade do mestre renova a alegria de Sudhana."
    centered "Cena 2 — A cidade e o trono do Dharma"
    narrator "Suprabha se apresenta vasta, dividida em distritos, com portões, muros, casas e palácios adornados. No palácio central de Mahāprabha, piscinas, árvores e cantos de aves compõem o cenário. Sudhana, porém, não se apega ao esplendor, aos sons ou às formas atraentes; mantém a atenção na contemplação do Dharma. Perguntando pelo mestre, chega a um cruzamento de três estradas e vê, perto do caitya, um grande trono ornamentado. Mahāprabha está sentado nele. Diante do rei há provisões, roupas, objetos úteis e outros bens destinados aos seres, inclusive aos pobres."
    speaker_012 "A beleza desta cidade não é o propósito da minha visita; procuro aprender o Dharma."
    narrator "No cruzamento, a busca encontra o rei sentado no trono do Dharma."
    speaker_012 "Reverenciado, aspirei à iluminação completa. Como devo aprender e praticar a conduta dos bodhisattvas?"
    centered "Cena 3 — O estandarte do grande amor"
    narrator "Mahāprabha responde que aperfeiçoou a conduta do bodhisattva chamada estandarte do grande amor, recebida e examinada junto a incontáveis budas. Permanecendo nela, governa segundo o Dharma e estabelece os seres em amor, altruísmo, cuidado e proteção, com aspiração contínua a eliminar o sofrimento. Busca afastá-los das aflições, da ignorância e do ciclo de existências, e orientá-los ao Dharma e à onisciência. O rei diz que não causa medo aos habitantes. Aos necessitados oferece acesso às provisões reunidas nas ruas, pátios e cruzamentos, para que possam obter o que precisam sem recorrer a ações prejudiciais."
    speaker_043 "Minha prática é o estandarte do grande amor: cuidar dos seres e orientá-los segundo o Dharma."
    speaker_012 "O cuidado que descreves busca também afastar os seres do sofrimento?"
    speaker_043 "Sim; ofereço condições para que se voltem ao Dharma, à compaixão e a uma conduta benéfica."
    centered "Cena 4 — O samādhi que pacifica"
    narrator "Mahāprabha explica que Suprabha não aparece igual a todos: conforme a disposição dos seres, pode parecer pequena ou vasta, de terra ou de joias, áspera ou plana e preciosa. Diz a Sudhana que aguarde para ver uma demonstração e entra no samādhi de exercer poder sobre o mundo motivado pelo grande amor. A cidade e seus arredores tremem; os seres da cidade, dos povoados e do reino voltam-se ao rei. Animais tornam-se gentis entre si. Seres de várias classes abandonam intenções violentas. O texto descreve também oferendas e sons celestiais. Medos, infortúnios, hostilidades, disputas e perturbações cessam, e o efeito se estende por inúmeros mundos."
    speaker_043 "Permanece aqui por um momento; observaremos o efeito deste samādhi."
    narrator "A demonstração acompanha o samādhi motivado pelo grande amor, e a narrativa amplia seus efeitos até incontáveis mundos."
    speaker_012 "Vejo que a prática descrita pelo rei se dirige à pacificação dos seres."
    centered "Cena 5 — A próxima mestra"
    narrator "Ao sair do samādhi, Mahāprabha diz conhecer apenas a sabedoria da conduta chamada estandarte do grande amor. Evoca, sem pretender descrevê-los por completo, bodhisattvas cuja proteção alcança igualmente todos os seres e cuja motivação se compara à terra, à lua, ao sol e a uma lâmpada. Reconhece não poder medir o mérito, as preces, a compaixão e as realizações deles. Então orienta Sudhana a seguir para Sthirā, na região sul, e perguntar à upāsikā Acalā como um bodhisattva deve treinar e praticar. Sudhana reverencia e circum-ambula o rei, olha para trás repetidas vezes e parte."
    speaker_043 "Conheço esta prática do grande amor; para a próxima instrução, procura Acalā em Sthirā."
    speaker_012 "Levarei comigo a pergunta sobre como aprender e praticar a conduta dos bodhisattvas."
    narrator "Após prestar homenagem ao rei, Sudhana parte rumo à cidade indicada."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao ouvir sobre o estandarte do grande amor, que aspecto você escolheria refletir antes de seguir viagem?"
        "Como o cuidado e a proteção podem alcançar os seres sem distinção?":
            narrator "A reflexão acompanha o ensinamento de Mahāprabha sobre amor e proteção."
        "Como oferecer provisões pode afastar os necessitados de ações nocivas?":
            narrator "A reflexão retoma a distribuição de recursos descrita pelo rei."
        "Como a percepção dos seres pode alterar a aparência de Suprabha?":
            narrator "A reflexão considera a explicação do rei sobre diferentes percepções da cidade."
    call quiz_ch21
    menu:
        "Continuar — capítulo 22":
            jump chapter_22
        "Voltar ao índice":
            jump chapter_index

label quiz_ch21:
    centered "Reconhecendo o samādhi"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito do capítulo."
    while True:
        menu:
            "Qual samādhi Mahāprabha demonstra a Sudhana?"
            "O samādhi de exercer poder sobre o mundo motivado pelo grande amor.":
                if 0 == 0:
                    narrator "Correto: o rei entra no samādhi associado ao grande amor e à pacificação dos seres."
                    return
                else:
                    narrator "Releia a demonstração do rei: o nome do samādhi está ligado ao grande amor."
            "O samādhi de tornar Suprabha invisível a todos os seres.":
                if 1 == 0:
                    narrator "Correto: o rei entra no samādhi associado ao grande amor e à pacificação dos seres."
                    return
                else:
                    narrator "Releia a demonstração do rei: o nome do samādhi está ligado ao grande amor."
            "O samādhi de transformar toda a cidade em um único palácio.":
                if 2 == 0:
                    narrator "Correto: o rei entra no samādhi associado ao grande amor e à pacificação dos seres."
                    return
                else:
                    narrator "Releia a demonstração do rei: o nome do samādhi está ligado ao grande amor."

label chapter_22:
    hide screen master_provisional_badge
    scene bg_ch22 with dissolve
    show master_ch22_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 22 — Acalā"
    centered "Cena 1 — A lembrança que conduz à próxima mestra"
    narrator "Partindo de Suprabha, Sudhana mantém na mente as instruções do rei Mahāprabha: recorda ensinamentos sobre amor, samādhi, sabedoria e amadurecimento dos seres. A lembrança do mestre o enche de alegria, clareza e estabilidade, mas também o leva às lágrimas ao refletir sobre o valor dos kalyāṇamitras. Devas bodhisattvas no céu, emissários dos budas que o acompanham e inspiram, dirigem-lhe palavras de encorajamento: seguir e guardar as instruções dos mestres aproxima o bodhisattva da onisciência. Eles o instruem a procurar Acalā, em Sthirā, para ouvir dela a conduta dos bodhisattvas."
    speaker_012 "O encontro com um mestre faz florescer qualidades e purifica o caminho; não quero esquecer o que me foi ensinado."
    speaker_044 "Segue para Sthirā. A upāsikā Acalā lhe ensinará a conduta dos bodhisattvas."
    centered "Cena 2 — A luz na casa de Acalā"
    narrator "Em Sthirā, pessoas informam Sudhana de que Acalā é jovem, vive com os pais e ensina o Dharma em casa. Ao chegar, ele vê a residência inteira resplandecer com uma luz dourada que traz bem-estar ao corpo e à mente. Assim que a luz o toca, surgem nele quinhentos acessos sutis e recém-desenvolvidos a samādhis. Sudhana percebe o esplendor de Acalā, a fragrância que emana dela, seus atendentes e a morada descrita como um palácio aéreo. Depois de louvá-la, apresenta sua aspiração à iluminação completa e pede que ela explique como os bodhisattvas devem treinar e praticar sua conduta."
    speaker_012 "Aspiro à iluminação completa; peço que me ensine como treinar e praticar a conduta do bodhisattva."
    speaker_045 "É excelente que tenha desenvolvido essa aspiração. Vou lhe expor o que realizei e aprendi."
    centered "Cena 3 — A motivação firmada diante de Pralambabāhu"
    narrator "Acalā explica que realizou uma libertação chamada essência da sabedoria difícil de alcançar e outros acessos de prática. A pedido de Sudhana, narra uma vida antiga: era filha única do rei Vidyuddatta e, certa noite, viu no céu o tathāgata Pralambabāhu, cuja luz e fragrância a encheram de alegria. Perguntou-se como alcançar tais qualidades. O tathāgata ensinou-lhe a cultivar motivações invencíveis contra as aflições e o apego, incansáveis na compreensão do Dharma, na busca dos budas e na aquisição de seus ensinamentos, e voltadas a distribuir o Dharma segundo as aspirações dos seres. Acalā diz ter mantido desde então uma aspiração firme à sabedoria e à conduta de buda."
    speaker_012 "Como se estende a libertação que chamou de essência da sabedoria difícil de alcançar?"
    speaker_045 "É difícil de acreditar, mas ensinarei: em outra vida, ouvi Pralambabāhu instruir-me a cultivar uma motivação firme e a compartilhar o Dharma conforme os seres aspiram."
    speaker_012 "Com a ajuda dos budas e dos bons mestres, ouvirei e examinarei essa instrução sem rejeitá-la."
    centered "Cena 4 — A visão dos mundos e a indicação de Sarvagamin"
    narrator "Acalā descreve a continuidade de sua busca: ouvir e reter o Dharma, praticar as condutas e orações dos bodhisattvas e não se afastar dos budas, dos bodhisattvas e dos bons mestres. Então repousa em samādhis. Sudhana vê incontáveis mundos de berilo puro estremecerem; em cada um há numerosos budas, assembleias e ensinamentos que alcançam os seres. Ao sair do samādhi, Acalā pergunta se ele viu, ouviu e discerniu, e Sudhana confirma. Ela explica que ensina seres por meio dos acessos que realizou, mas não pretende abarcar as qualidades inconcebíveis de todos os bodhisattvas. Indica Sarvagamin, em Tosala, como próximo mestre. Sudhana a reverencia, circum-ambula-a cem mil vezes e parte, olhando para trás repetidamente."
    speaker_045 "Você viu, ouviu e discerniu o que se manifestou nesses samādhis?"
    speaker_012 "Vi, ouvi e discerni. Guardarei o que me ensinou enquanto sigo adiante."
    speaker_045 "Em Tosala, procure o parivrājaka Sarvagamin e pergunte como se treina e pratica a conduta dos bodhisattvas."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o encontro com Acalā, que aspecto de sua instrução você escolheria levar em primeiro plano?"
        "Manter uma motivação firme para compreender o Dharma.":
            narrator "Uma reflexão coerente com a instrução narrada por Acalā."
        "Ensinar o Dharma conforme as aspirações dos seres.":
            narrator "Acalā recorda essa orientação recebida de Pralambabāhu."
        "Continuar ouvindo e praticando sem se afastar dos bons mestres.":
            narrator "A reflexão retoma a busca contínua que Acalā descreve."
    call quiz_ch22
    menu:
        "Continuar — capítulo 23":
            jump chapter_23
        "Voltar ao índice":
            jump chapter_index

label quiz_ch22:
    centered "O conselho de Pralambabāhu"
    narrator "Escolha a resposta que corresponde a um ensinamento explícito lembrado por Acalā."
    while True:
        menu:
            "Segundo a instrução recebida por Acalā, como se deve distribuir o Dharma?"
            "De acordo com as aspirações dos seres.":
                if 0 == 0:
                    narrator "Correto: a instrução menciona distribuir o Dharma conforme as aspirações dos seres."
                    return
                else:
                    narrator "Releia a lembrança de Acalā: a orientação relaciona o ensino às aspirações dos seres."
            "Somente aos que vivem no palácio real.":
                if 1 == 0:
                    narrator "Correto: a instrução menciona distribuir o Dharma conforme as aspirações dos seres."
                    return
                else:
                    narrator "Releia a lembrança de Acalā: a orientação relaciona o ensino às aspirações dos seres."
            "Apenas depois de alcançar a morada de Acalā.":
                if 2 == 0:
                    narrator "Correto: a instrução menciona distribuir o Dharma conforme as aspirações dos seres."
                    return
                else:
                    narrator "Releia a lembrança de Acalā: a orientação relaciona o ensino às aspirações dos seres."

label chapter_23:
    hide screen master_provisional_badge
    scene bg_ch23 with dissolve
    show master_ch23_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 23 — Sarvagamin"
    centered "Cena 1 — A instrução lembrada"
    narrator "Sudhana mantém na mente a upāsikā Acalā e a instrução recebida dela. Com convicção, sem dúvida, ele a contempla, compreende e medita sobre seus ensinamentos, até se firmar neles. O texto não especifica onde ocorre essa reflexão. Depois, ele segue de distrito em distrito e de terra em terra, até chegar a Amitatosala. Procura a cidade de Tosala e alcança o lugar ao pôr do sol. Sua busca pelo próximo mestre continua: percorre ruas, cruzamentos e vielas, perguntando e procurando, sem que a narrativa indique um resultado imediato durante aquela primeira ronda."
    speaker_012 "Que a instrução de Acalā permaneça clara em minha mente enquanto prossigo a busca."
    narrator "A viagem o conduz a Tosala, onde a procura ainda não terminou."
    centered "Cena 2 — A luz no monte Sulabha"
    narrator "Quando a noite chega e as pessoas dormem, Sudhana avista ao norte de Tosala o monte Sulabha. Seu cume, adornado por uma variedade agradável de gramíneas, arbustos e ervas, brilha como o sol. A visão desperta nele grande alegria e a certeza de que ali encontrará um amigo espiritual. Ele sai da cidade, sobe o monte e alcança o cume luminoso. À distância, vê o andarilho Sarvagamin, resplandecente e de aparência descrita como superior até à de Mahābrahmā. Dez mil brâmanes caminham em circum-ambulação ao redor dele."
    speaker_012 "A luz no cume me dá confiança de que encontrarei ali um mestre espiritual."
    narrator "No alto de Sulabha, Sarvagamin está rodeado por dez mil brâmanes."
    centered "Cena 3 — A pergunta de Sudhana"
    narrator "Sudhana aproxima-se de Sarvagamin, inclina a cabeça aos pés dele, circunda-o muitas centenas de milhares de vezes e senta-se à sua frente com as mãos unidas em homenagem. Ele expõe sua aspiração pela iluminação suprema e completa, mas reconhece que ainda não sabe como os bodhisattvas devem treinar na conduta bodhisattva nem como devem praticá-la. Sudhana acrescenta que ouviu dizer que Sarvagamin oferece instrução e ensinamentos aos bodhisattvas, e pede que lhe explique esse treinamento. Sarvagamin acolhe a aspiração de Sudhana como excelente e passa a apresentar sua própria prática e os meios pelos quais beneficia os seres."
    speaker_012 "Aspiro à iluminação suprema e completa; peço orientação sobre como treinar e praticar a conduta bodhisattva."
    speaker_046 "É excelente que tenhas iniciado essa aspiração; vou expor o alcance da minha prática."
    centered "Cena 4 — Meios diversos para beneficiar os seres"
    narrator "Sarvagamin afirma permanecer na conduta bodhisattva que tudo permeia. Menciona um samādhi ligado à luz da prática de todos os portais, o estabelecimento na ausência de existência, poderes milagrosos não compostos e conhecimento da perfeição da sabedoria. Explica que beneficia seres de condições e aspirações variadas por meios diferentes. A alguns, oferece a luz da retenção mental que abrange conhecimentos de ofícios; a outros, os quatro métodos de reunir discípulos. Também descreve perfeições e a aspiração à iluminação, apresenta aspectos da conduta bodhisattva e fala tanto dos sofrimentos dos infernos quanto das qualidades dos tathāgatas, conforme o modo de beneficiar cada grupo."
    speaker_046 "Os seres diferem em suas condições e aspirações; por isso, o benefício pode recorrer a métodos diversos."
    speaker_012 "Compreendo que a instrução descrita alcança capacidades e propósitos diferentes."
    centered "Cena 5 — O alcance de Sarvagamin e o próximo mestre"
    narrator "Sarvagamin diz que manifesta em Tosala corpos de tamanho e forma adequados às aspirações, atividades, poderes e condutas dos habitantes, ensinando-lhes o Dharma; eles não reconhecem quem lhes ensinou, mas praticam corretamente. Ele estende essa atividade a aldeias, mercados, cidades, terras, reinos e capitais de Jambudvīpa, e depois a mundos nas dez direções, empregando formas, métodos e idiomas diversos. Em seguida, declara que não saberia explicar a conduta de bodhisattvas cujas realizações abrangem, entre outras, corpos equivalentes aos dos seres e compaixão ilimitada. Encaminha Sudhana a Utpalabhūti, mercador-chefe vendedor de perfumes em Pṛthurāṣṭra. Sudhana o homenageia, circunda-o cem mil vezes e parte, voltando o olhar repetidamente."
    speaker_046 "Para continuar tua busca, vai à terra de Pṛthurāṣṭra e pergunta a Utpalabhūti sobre a prática bodhisattva."
    speaker_012 "Recebo a orientação e seguirei ao encontro do próximo mestre indicado."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Sarvagamin você gostaria de refletir antes de seguir?"
        "A adaptação dos meios às diferentes aspirações":
            narrator "Essa diversidade acompanha a maneira como Sarvagamin diz beneficiar os seres."
        "A aspiração à iluminação e o treinamento bodhisattva":
            narrator "Essa foi a questão que Sudhana trouxe ao mestre."
        "A amplitude dos mundos alcançados pelo benefício":
            narrator "Sarvagamin descreve sua atividade estendendo-se pelas dez direções."
    call quiz_ch23
    menu:
        "Continuar — capítulo 24":
            jump chapter_24
        "Voltar ao índice":
            jump chapter_index

label quiz_ch23:
    centered "Reconheça o ensinamento"
    narrator "Escolha a resposta que corresponde ao que Sarvagamin afirma sobre os meios de beneficiar os seres."
    while True:
        menu:
            "Como Sarvagamin diz que beneficia seres com diferentes condições e aspirações?"
            "Por diversos métodos, inclusive formas, ensinamentos e idiomas variados.":
                if 0 == 0:
                    narrator "Correto: Sarvagamin descreve meios diversos, de acordo com as aspirações dos seres."
                    return
                else:
                    narrator "Releia a exposição: ela menciona métodos, formas e idiomas diversos."
            "Por um único método idêntico para todos os seres.":
                if 1 == 0:
                    narrator "Correto: Sarvagamin descreve meios diversos, de acordo com as aspirações dos seres."
                    return
                else:
                    narrator "Releia a exposição: ela menciona métodos, formas e idiomas diversos."
            "Somente ensinando ofícios em Tosala.":
                if 2 == 0:
                    narrator "Correto: Sarvagamin descreve meios diversos, de acordo com as aspirações dos seres."
                    return
                else:
                    narrator "Releia a exposição: ela menciona métodos, formas e idiomas diversos."

label chapter_24:
    hide screen master_provisional_badge
    scene bg_ch24 with dissolve
    show master_ch24_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 24 — Utpalabhūti"
    centered "Cena 1 — A aspiração e o encontro em Pṛthurāṣṭra"
    narrator "Antes do encontro, Sudhana é apresentado como alguém cuja atenção não se volta à própria vida, aos prazeres sensoriais, à riqueza ou ao poder. Sua aspiração concentra-se na iluminação, no benefício dos seres, no aprendizado junto aos budas e na continuidade da prática bodhisattva. Em Pṛthurāṣṭra, ele procura Utpalabhūti, chefe mercador de perfumes. Ao encontrá-lo, curva-se aos pés dele, circum-ambula-o muitas centenas de milhares de vezes e senta-se diante do mestre. Com as mãos unidas em homenagem, expõe seu desejo de aprender como os bodhisattvas treinam e praticam para se tornarem oniscientes."
    speaker_012 "Busco a sabedoria dos budas e quero compreender como se treina e pratica a conduta bodhisattva."
    speaker_047 "É excelente que tenhas despertado a aspiração pela iluminação completa."
    centered "Cena 2 — O saber do mercador de perfumes"
    narrator "Utpalabhūti explica que conhece perfumes, incensos, unguentos e pós, tanto simples quanto combinados, e que conhece aromas associados a devas, nāgas, yakṣas, gandharvas, asuras, garuḍas, kinnaras, mahoragas, humanos e não humanos. Seu conhecimento inclui perfumes ligados à cura, à alegria ou à tristeza, ao surgimento ou à cessação das aflições, à dispersão da intoxicação e do descuido, à atenção contínua aos budas e à compreensão do caminho do Dharma. Ele também conhece os aromas relacionados à conduta nobre e aos níveis bodhisattva. Diz conhecer, além disso, aspectos como origem, preparo, aperfeiçoamento, purificação, uso, objeto, poder, ação e causa desses perfumes."
    speaker_047 "Conheço muitas classes de perfumes e também suas combinações, origens, usos e efeitos."
    speaker_012 "Escuto com atenção; desejo aprender sem confundir esse saber com a totalidade da prática."
    centered "Cena 3 — Aroma, bem-estar e Dharma"
    narrator "Como exemplos, Utpalabhūti descreve o perfume chamado elefante-essência: uma porção do tamanho de uma semente de gergelim pode cobrir Pṛthurāṣṭra com uma nuvem aromática e, por sete dias, fazer cair uma chuva fina de água perfumada. Segundo ele, aqueles atingidos ou que sentem o aroma podem experimentar alegria, ausência de certos sofrimentos e maior benevolência uns com os outros; então ele lhes ensina o Dharma para orientá-los à iluminação completa. Também menciona o sândalo gośīrṣa, associado a não ser queimado ao saltar em fogo, e outros perfumes com efeitos específicos: um pode fazer cessar más ações e favorecer a mente controlada; outro, libertar do desejo e ser seguido pelo ensinamento sobre o samādhi chamado campo imaculado."
    speaker_047 "O perfume elefante-essência é descrito como trazendo alegria e benevolência por sete dias; nesse contexto, ensino o Dharma."
    speaker_012 "Assim, o aroma também pode ser uma ocasião para conduzir os seres ao ensinamento."
    centered "Cena 4 — O limite do ensinamento e a próxima indicação"
    narrator "Utpalabhūti continua com exemplos de perfumes associados à aparição do exército de um rei cakravartin, à lembrança do aroma agradável dos budas entre devas, ao ensinamento de Dharma por Suyāma e a chuvas de nuvens de Dharma em Tuṣita e no paraíso de Sunirmita. Em seguida, delimita o alcance de seu próprio conhecimento: sabe combinar perfumes, mas não pode explicar a conduta nem as qualidades dos bodhisattvas sem mácula, livres das aflições e sem apego a qualquer base ou lugar. Por isso, orienta Sudhana a seguir para o sul, à cidade de Kūṭāgāra, e perguntar ao marinheiro Vaira como um bodhisattva deve treinar e praticar. Sudhana homenageia Utpalabhūti, circum-ambula-o cem mil vezes e parte, olhando para trás repetidamente."
    speaker_047 "Posso falar sobre combinar perfumes, mas não elucidar plenamente a prática desses bodhisattvas sem mácula."
    speaker_047 "No sul, em Kūṭāgāra, vive o marinheiro Vaira. Pergunta a ele sobre o treinamento e a prática bodhisattva."
    speaker_012 "Recebo tua orientação e seguirei para encontrar Vaira."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao ouvir Utpalabhūti distinguir seu saber sobre perfumes da conduta que não pode explicar, que pergunta de reflexão você escolheria antes da partida de Sudhana?"
        "Como os perfumes se relacionam com o bem-estar e o ensino do Dharma?":
            narrator "A conversa apresenta efeitos específicos e o ensino como orientação dos seres; Sudhana segue a indicação recebida."
        "Que limite Utpalabhūti reconhece em seu próprio ensinamento?":
            narrator "Ele conhece perfumes, mas não afirma poder elucidar a conduta dos bodhisattvas sem mácula; Sudhana segue a indicação recebida."
        "Qual é o próximo mestre indicado a Sudhana?":
            narrator "Utpalabhūti indica Vaira, em Kūṭāgāra, ao sul; Sudhana segue a indicação recebida."
    call quiz_ch24
    menu:
        "Continuar — capítulo 25":
            jump chapter_25
        "Voltar ao índice":
            jump chapter_index

label quiz_ch24:
    centered "Identifique o exemplo do perfume"
    narrator "Escolha a resposta baseada no ensinamento explícito deste capítulo. Este menu é não canônico."
    while True:
        menu:
            "Segundo Utpalabhūti, o que acontece quando o aroma do perfume luminescente é sentido?"
            "A mente se liberta do desejo; Utpalabhūti ensina o samādhi chamado campo imaculado.":
                if 0 == 0:
                    narrator "Correto: o capítulo associa o perfume luminescente à libertação do desejo e ao ensinamento sobre o campo imaculado."
                    return
                else:
                    narrator "Revise o exemplo do perfume luminescente: o texto o associa à libertação do desejo."
            "Aparece no céu o exército quádruplo de um rei cakravartin.":
                if 1 == 0:
                    narrator "Correto: o capítulo associa o perfume luminescente à libertação do desejo e ao ensinamento sobre o campo imaculado."
                    return
                else:
                    narrator "Revise o exemplo do perfume luminescente: o texto o associa à libertação do desejo."
            "Os devas recordam o aroma agradável dos budas.":
                if 2 == 0:
                    narrator "Correto: o capítulo associa o perfume luminescente à libertação do desejo e ao ensinamento sobre o campo imaculado."
                    return
                else:
                    narrator "Revise o exemplo do perfume luminescente: o texto o associa à libertação do desejo."

label chapter_25:
    hide screen master_provisional_badge
    scene bg_ch25 with dissolve
    show master_ch25_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 25 — Vaira"
    centered "Cena 1 — A estrada e o encontro à beira-mar"
    narrator "Enquanto segue para Kūṭāgāra, Sudhana observa a estrada: ela pode subir ou descer, ser plana ou irregular, poeirenta ou limpa, segura ou perigosa, difícil ou desimpedida, tortuosa ou reta. Ele reflete que buscar um bom amigo espiritual sustenta a prática do caminho do bodhisattva e o benefício dos seres, afastando-os de extremos e visões equivocadas. A viagem é difícil, mas ele chega à cidade. À beira do oceano, encontra o marinheiro Vaira cercado por numerosos comerciantes e outras pessoas que querem ouvi-lo. Vaira conta histórias do mar e, por meio delas, ensina sobre o oceano de qualidades dos budas."
    speaker_012 "Mesmo uma estrada irregular pode me lembrar que a prática busca beneficiar os seres."
    narrator "Na margem, as histórias do mar de Vaira reúnem os ouvintes em torno de um ensinamento sobre os budas."
    speaker_012 "Vaira, vim pedir orientação sobre a conduta dos bodhisattvas."
    centered "Cena 2 — A bandeira da grande compaixão"
    narrator "Sudhana presta homenagem a Vaira e pergunta como os bodhisattvas devem treinar e praticar sua conduta. Vaira acolhe sua aspiração à iluminação completa e diz que vive em Kūṭāgāra purificando a conduta chamada estandarte da grande compaixão. Quando encontra seres necessitados em Jambudvīpa, declara que suporta dificuldades por eles: busca atender seus desejos, reunir bens mundanos e proporcionar o desfrute do Dharma. Também ensina o caminho da acumulação de mérito, ajuda a ampliar a sabedoria e as raízes de mérito, e favorece o surgimento e a purificação da aspiração à iluminação. Sua atividade visa fortalecer a grande compaixão, cessar o sofrimento do saṃsāra e conduzir seres aos portais da prática e à sabedoria."
    speaker_012 "Como devo treinar e praticar a conduta do bodhisattva?"
    speaker_048 "Minha prática neste lugar se chama estandarte da grande compaixão."
    speaker_048 "Para os seres necessitados, o auxílio inclui tanto o necessário quanto o ensinamento do Dharma."
    centered "Cena 3 — Conhecer o oceano, guiar os mercadores"
    narrator "Vaira relata conhecer ilhas e fontes de joias, moradas e perigos associados a nāgas, yakṣas, rākṣasas e bhūtas, além de redemoinhos e grandes ondas. Diz conhecer os movimentos dos astros, os tempos de partida e chegada, riscos, embarcações apropriadas, ventos, manobras, ancoragem e lançamento ao mar. Com esse conhecimento, conduz grupos de mercadores, conforme desejam, em navios confiáveis até ilhas de joias e de volta a Jambudvīpa, com segurança e sem medo; durante a viagem, fala do Dharma de modo que os alegra. Vaira afirma que nenhum navio seu jamais esteve em perigo. Diz ainda que vê-lo ou ouvi-lo ensinar orienta os seres para a sabedoria que entra no oceano da onisciência e para o empenho em benefício de todos."
    speaker_048 "Conhecer as condições da viagem permite conduzir os mercadores com segurança."
    speaker_012 "E durante a travessia, o senhor também lhes ensina o Dharma."
    speaker_048 "Sim; minha atividade reúne a travessia e o benefício dos seres."
    centered "Cena 4 — A próxima pergunta"
    narrator "Vaira declara ter alcançado a libertação do bodhisattva chamada recordar-se de permanecer com a frutífera audição e visão do estandarte da grande compaixão. No entanto, diz não poder conhecer nem descrever plenamente a conduta de bodhisattvas que atuam em todos os oceanos do saṃsāra, sem se manchar por eles, e que guiam os seres sem perder o momento oportuno. Então indica a Sudhana o chefe mercador Jayottama, residente na cidade de Nandihāra, na região sul, e recomenda que lhe pergunte como um bodhisattva deve treinar e praticar a conduta. Alegre e satisfeito, Sudhana reverencia Vaira, dá voltas ao seu redor mantendo-o à direita e parte, olhando para trás repetidamente."
    speaker_048 "Minha realização não me permite descrever toda a conduta dos bodhisattvas em todos os oceanos do saṃsāra."
    speaker_048 "Em Nandihāra, procure Jayottama e pergunte como praticar essa conduta."
    speaker_012 "Partirei com gratidão e levarei comigo sua orientação."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto dos ensinamentos de Vaira você gostaria de levar como reflexão antes de seguir?"
        "A busca por um bom amigo espiritual":
            narrator "A jornada de Sudhana começa contemplando como essa busca sustenta o caminho."
        "O cuidado compassivo com os seres":
            narrator "Vaira descreve atender necessidades e ensinar o Dharma como parte de sua prática."
        "O conhecimento necessário para navegar":
            narrator "Vaira enumera condições do oceano e da navegação usadas para guiar mercadores."
    call quiz_ch25
    menu:
        "Continuar — capítulo 26":
            jump chapter_26
        "Voltar ao índice":
            jump chapter_index

label quiz_ch25:
    centered "Rota de conhecimento"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito do capítulo."
    while True:
        menu:
            "Que conduta Vaira diz purificar em Kūṭāgāra?"
            "O estandarte da grande compaixão":
                if 0 == 0:
                    narrator "Correto: Vaira nomeia sua conduta como estandarte da grande compaixão."
                    return
                else:
                    narrator "Releia o ensinamento de Vaira sobre a conduta que ele cultiva em Kūṭāgāra."
            "A disciplina dos mercadores de Jambudvīpa":
                if 1 == 0:
                    narrator "Correto: Vaira nomeia sua conduta como estandarte da grande compaixão."
                    return
                else:
                    narrator "Releia o ensinamento de Vaira sobre a conduta que ele cultiva em Kūṭāgāra."
            "A contemplação dos movimentos dos astros":
                if 2 == 0:
                    narrator "Correto: Vaira nomeia sua conduta como estandarte da grande compaixão."
                    return
                else:
                    narrator "Releia o ensinamento de Vaira sobre a conduta que ele cultiva em Kūṭāgāra."

label chapter_26:
    hide screen master_provisional_badge
    scene bg_ch26 with dissolve
    show master_ch26_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 26 — Jayottama"
    centered "Cena 1 — O ensinamento no bosque Vicitradhvaja"
    narrator "Sudhana chega à cidade de Nandihāra à procura do mercador-chefe Jayottama. Encontra-o no lado oriental, no bosque de árvores ashoka chamado Vicitradhvaja, cercado por milhares de chefes de família que deliberam sobre diferentes deveres cívicos. Jayottama lhes ensina o Dharma para dissipar egotismo, possessividade, apego, fixações, dúvida, ilusão, inveja e avareza. Também apresenta aspirações ligadas a ver os budas, receber seu Dharma e cultivar a conduta, a concentração, a sabedoria e a memória dos bodhisattvas. O texto esclarece que esse ensinamento visa inspirar a aspiração à iluminação."
    speaker_049 "Que a reflexão sobre os deveres não se prenda ao apego nem à ilusão; cultivem uma mente clara e a aspiração à iluminação."
    speaker_050 "Ouvimos o ensinamento e voltamos a atenção para a conduta virtuosa e para o caminho dos bodhisattvas."
    centered "Cena 2 — O pedido de Sudhana"
    narrator "Quando o ensinamento termina, Sudhana aproxima-se de Jayottama e inclina a cabeça aos pés dele, permanecendo prostrado por longo tempo. Apresenta-se e declara que busca a conduta dos bodhisattvas. Pede instrução sobre como treiná-la e, durante esse treinamento, como orientar e amadurecer todos os seres. Seu pedido abrange não abandonar a visão dos budas, ouvir o Dharma de todos eles e receber seus ensinamentos; praticar a via dos budas e a conduta dos bodhisattvas em todos os mundos, sem se cansar ao longo das eras; compreender as manifestações dos tathāgatas e receber a bênção e o esplendor de seu poder. Jayottama acolhe a aspiração de Sudhana à iluminação completa."
    speaker_012 "Busco aprender a conduta dos bodhisattvas. Como posso treiná-la e, nesse caminho, ajudar os seres a amadurecer?"
    speaker_049 "É excelente que tenhas despertado a aspiração pela iluminação completa. Escuta o alcance do meu ensinamento."
    centered "Cena 3 — Uma conduta que alcança muitos mundos"
    narrator "Jayottama diz que purifica a porta da conduta onipresente dos bodhisattvas por meio da realização de milagres não compostos, permanecendo na ausência de existência. Explica que ensina nos universos de um bilhão de mundos e em numerosos mundos das dez direções, dirigindo o Dharma a diferentes classes de seres e também expondo ensinamentos de budas, bodhisattvas, śrāvakas e pratyekabuddhas. Seu ensino pacifica disputas, conflitos, hostilidade e guerras, rompe vínculos e afasta ações não virtuosas, incluindo matar, tomar o que não foi dado e condutas nocivas na fala e na mente. Também conduz os seres a atividades virtuosas e apresenta os tratados que, segundo ele, beneficiam o mundo."
    speaker_049 "Ensino para pacificar conflitos e afastar ações nocivas, conduzindo os seres a atividades virtuosas."
    speaker_012 "Teu relato mostra um ensinamento dirigido a muitos seres e a condições diversas."
    centered "Cena 4 — A próxima mestra"
    narrator "Jayottama acrescenta que ensina sobre o mundo, sua criação e destruição, suas transgressões e a renúncia. Explica que seus ensinamentos elucidam o caminho dos bodhisattvas, os defeitos do saṃsāra, as qualidades da onisciência e as experiências de felicidade e sofrimento. Contudo, afirma conhecer essa porta da conduta onipresente, não a totalidade da conduta e das qualidades dos bodhisattvas plenamente sábios, cuja esfera é vasta e imensurável. Por isso, orienta Sudhana a seguir para Kaliṅgavana, em Śroṇāparānta, e procurar a bhikṣuṇī Siṃhavijṛmbhitā. Sudhana reverencia Jayottama, dá centenas de milhares de voltas mantendo-o à direita e parte, olhando para trás repetidas vezes."
    speaker_049 "Minha compreensão alcança esta porta da conduta. Para aprender mais, procura a bhikṣuṇī Siṃhavijṛmbhitā em Kaliṅgavana."
    speaker_012 "Recebo tua orientação e sigo adiante, levando comigo este ensinamento."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o ensinamento de Jayottama, que aspecto você destacaria para Sudhana?"
        "A pacificação de conflitos e o afastamento de ações não virtuosas":
            narrator "Uma reflexão coerente com o ensinamento; Sudhana continua sua jornada como na fonte."
        "O estudo de criação, destruição e renúncia do mundo":
            narrator "Uma reflexão coerente com os temas ensinados; a jornada prossegue sem mudança."
        "A humildade de reconhecer os limites do próprio conhecimento":
            narrator "Uma reflexão coerente com a resposta de Jayottama; nada altera os acontecimentos."
    call quiz_ch26
    menu:
        "Continuar — capítulo 27":
            jump chapter_27
        "Voltar ao índice":
            jump chapter_index

label quiz_ch26:
    centered "Reconheça o ensinamento"
    narrator "Escolha a única resposta explicitamente sustentada pelo capítulo."
    while True:
        menu:
            "Para que Jayottama diz ensinar o Dharma?"
            "Para pacificar disputas e afastar ações não virtuosas.":
                if 0 == 0:
                    narrator "Correto: Jayottama descreve o ensinamento como meio de pacificar conflitos e afastar ações não virtuosas."
                    return
                else:
                    narrator "Revise o relato: Jayottama enumera a pacificação de disputas e o abandono de ações não virtuosas."
            "Para ser nomeado governante de Nandihāra.":
                if 1 == 0:
                    narrator "Correto: Jayottama descreve o ensinamento como meio de pacificar conflitos e afastar ações não virtuosas."
                    return
                else:
                    narrator "Revise o relato: Jayottama enumera a pacificação de disputas e o abandono de ações não virtuosas."
            "Para encerrar a busca de Sudhana.":
                if 2 == 0:
                    narrator "Correto: Jayottama descreve o ensinamento como meio de pacificar conflitos e afastar ações não virtuosas."
                    return
                else:
                    narrator "Revise o relato: Jayottama enumera a pacificação de disputas e o abandono de ações não virtuosas."

label chapter_27:
    hide screen master_provisional_badge
    scene bg_ch27 with dissolve
    show master_ch27_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 27 — Siṃhavijṛmbhitā"
    centered "Cena 1 — O caminho até Sūryaprabha"
    narrator "Sudhana, filho de um chefe mercador, chega a Kaliṅgavana em busca da bhikṣuṇī Siṃhavijṛmbhitā. Nas ruas e cruzamentos, muitas pessoas se reúnem; elas lhe indicam que a mestra está no grande parque Sūryaprabha, ensinando o Dharma a incontáveis seres. Ao entrar, Sudhana encontra uma paisagem de árvores preciosas, fontes, lagoas, flores, aves, assentos adornados, sons musicais e fragrâncias. O parque se estende, por meio das capacidades inconcebíveis de Siṃhavijṛmbhitā, como a vastidão do céu sobre incontáveis mundos. O texto relaciona essa exibição ao amadurecimento do mérito e à natureza ilusória dos fenômenos."
    speaker_012 "Procuro Siṃhavijṛmbhitā; disseram-me que ela ensina neste parque."
    narrator "Cada aspecto de Sūryaprabha anuncia uma manifestação de mérito e realização."
    centered "Cena 2 — Uma assembleia, muitas portas do Dharma"
    narrator "Siṃhavijṛmbhitā está sentada entre uma grande assembleia e dirige ensinamentos distintos a ouvintes diversos. Devas de diferentes paraísos, nāgas, yakṣas, gandharvas, asuras, garuḍas, kinnaras, mahoragas, rākṣasas, pessoas e seres com aspirações a diferentes veículos recebem portas do Dharma apropriadas. O texto também enumera ensinamentos de samādhi para bodhisattvas desde a primeira aspiração à iluminação até o décimo bhūmi, além de uma instrução à comitiva de vajrapāṇis. A todos os seres preparados que chegam ao parque, ela ensina de modo a firmá-los na aspiração à iluminação completa. O capítulo associa essa capacidade à prática de incontáveis portas da perfeição da sabedoria e ao mérito cultivado anteriormente pelos visitantes."
    speaker_051 "Que cada ensinamento conduza os ouvintes a firmar sua aspiração à iluminação completa."
    speaker_012 "A mesma mestra oferece caminhos de ensinamento a uma assembleia tão diversa."
    centered "Cena 3 — A pergunta de Sudhana"
    narrator "Depois de contemplar o parque, a assembleia e a eloquência da mestra, Sudhana sente-se profundamente imerso no Dharma. Siṃhavijṛmbhitā preenche o parque e a assembleia com luz; ele a circumambula muitas centenas de milhares de vezes e percebe que ela permanece diante dele. Com as mãos unidas em reverência, pergunta como os bodhisattvas devem treinar e praticar sua conduta. A mestra responde que alcançou a libertação do bodhisattva chamada erradicação de toda presunção. Ao ser perguntada sobre seu alcance, explica que ela é luz de sabedoria, capaz de perceber, num instante mental, manifestações ocorridas nos três tempos."
    speaker_012 "Como se treinam os bodhisattvas na conduta e como a praticam?"
    speaker_051 "Conheço a libertação chamada erradicação de toda presunção; seu alcance é a luz da sabedoria."
    centered "Cena 4 — Sabedoria sem presunção"
    narrator "Siṃhavijṛmbhitā prossegue explicando que, ao cultivar e realizar essa luz de sabedoria, surgiu nela o samādhi chamado conformidade com todos os Dharmas. Por meio dele, vai em corpos feitos de mente até bodhisattvas com uma vida restante nos palácios de Tuṣita, oferecendo-lhes incontáveis dádivas; também faz oferendas aos tathāgatas nas diferentes etapas de suas trajetórias. Os seres que conhecem esse serviço aos budas alcançarão a iluminação completa, e ela ensina a perfeição da sabedoria aos que vêm até ela. Embora contemple os seres, escute suas línguas e veja os tathāgatas e seus Dharmas, não se torna presunçosa: compreende a natureza dos fenômenos como ilusória."
    speaker_051 "Ensino a perfeição da sabedoria aos seres que vêm até mim."
    speaker_012 "Ver, ouvir e ensinar não precisam se converter em motivo de presunção."
    centered "Cena 5 — A próxima mestra"
    narrator "Siṃhavijṛmbhitā reconhece o alcance da libertação que realizou, mas não afirma poder descrever a conduta dos bodhisattvas que compreenderam o domínio dos fenômenos sem começo nem centro e suas qualidades inconcebíveis. Ela envia Sudhana ao sul, à região chamada Durga e à cidade de Ratnavyūha, onde vive a cortesã Vasumitrā. O pedido transmitido é que ele pergunte como um bodhisattva deve treinar e praticar sua conduta. Sudhana inclina a cabeça aos pés da bhikṣuṇī, circumambula-a muitas centenas de milhares de vezes mantendo-a à sua direita e parte. Enquanto se afasta, olha para trás repetidamente."
    speaker_051 "Em Ratnavyūha, procure Vasumitrā e pergunte sobre a prática da conduta de bodhisattva."
    speaker_012 "Recebo sua orientação e sigo para encontrar a próxima mestra indicada."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Siṃhavijṛmbhitā você gostaria de levar como reflexão nesta visita?"
        "A sabedoria sem presunção":
            narrator "A contemplação dos seres e dos fenômenos não precisa alimentar orgulho."
        "O ensino adequado a diferentes ouvintes":
            narrator "A mestra oferece portas do Dharma a assembleias e aspirações diversas."
        "O mérito cultivado em conjunto":
            narrator "O capítulo relaciona os visitantes ao mérito que a mestra os ajudou a desenvolver."
    call quiz_ch27
    menu:
        "Continuar — capítulo 28":
            jump chapter_28
        "Voltar ao índice":
            jump chapter_index

label quiz_ch27:
    centered "Reconheça a libertação"
    narrator "Escolha a descrição que corresponde ao ensinamento explícito de Siṃhavijṛmbhitā."
    while True:
        menu:
            "O que caracteriza a libertação chamada erradicação de toda presunção?"
            "A luz de sabedoria que percebe, num instante mental, manifestações dos três tempos.":
                if 0 == 0:
                    narrator "Correto: a mestra a descreve como luz de sabedoria ligada à percepção das manifestações dos três tempos."
                    return
                else:
                    narrator "Revise a resposta de Siṃhavijṛmbhitā sobre a libertação e tente novamente."
            "A capacidade de permanecer em silêncio diante de qualquer assembleia.":
                if 1 == 0:
                    narrator "Correto: a mestra a descreve como luz de sabedoria ligada à percepção das manifestações dos três tempos."
                    return
                else:
                    narrator "Revise a resposta de Siṃhavijṛmbhitā sobre a libertação e tente novamente."
            "A obtenção de um parque que supera todos os mundos por sua beleza.":
                if 2 == 0:
                    narrator "Correto: a mestra a descreve como luz de sabedoria ligada à percepção das manifestações dos três tempos."
                    return
                else:
                    narrator "Revise a resposta de Siṃhavijṛmbhitā sobre a libertação e tente novamente."

label chapter_28:
    hide screen master_provisional_badge
    scene bg_ch28 with dissolve
    show master_ch28_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 28 — Vasumitrā"
    centered "Cena 1 — A busca que causa estranhamento"
    narrator "Com a mente iluminada pela sabedoria e sustentado por aspirações ligadas à compaixão e à prática dos bodhisattvas, Sudhana chega a Ratnavyūha procurando Vasumitrā. Entre os moradores que não conhecem suas qualidades, a busca parece contraditória: eles consideram sua compostura, atenção e domínio dos sentidos incompatíveis com desejo ou conduta impura. Outros moradores, que conhecem a sabedoria de Vasumitrā, acolhem sua intenção como sinal de aspiração à budeidade e de desejo de afastar os seres do sofrimento do desejo e das concepções de beleza e pureza. São eles que lhe dizem onde encontrá-la."
    speaker_052 "Ele parece tão recolhido e atento. Por que procuraria Vasumitrā?"
    speaker_053 "Não julgues a visita apenas pela aparência: ele busca instrução para o caminho dos bodhisattvas."
    speaker_012 "Agradeço a indicação. Irei à casa dela e perguntarei como praticar essa conduta."
    centered "Cena 2 — A casa luminosa e a mestra"
    narrator "Sudhana encontra uma morada vasta, cercada por sucessivas muralhas e fileiras de palmeiras preciosas, além de fossos com flores de lótus, água perfumada e cercas ornamentadas. Palácios, pavilhões e outras construções brilham com joias; sinos dourados movidos pela brisa emitem sons agradáveis, e há árvores preciosas e dez parques. Ali está Vasumitrā, dotada de beleza extraordinária, voz e domínio de idiomas admiráveis, habilidade nas artes e sabedoria do Dharma. Sua assembleia de seguidores compartilha aspiração e prática de raízes de mérito. A luz de seu corpo ilumina os edifícios e desperta alegria. Sudhana reverencia seus pés e pede orientação sobre como os bodhisattvas devem treinar e praticar."
    speaker_012 "Aspiro à iluminação completa, mas ainda preciso aprender como se treina e pratica a conduta dos bodhisattvas."
    speaker_054 "Posso ensinar-te a partir da libertação que realizei; escuta como ela beneficia os seres."
    centered "Cena 3 — Libertar do desejo"
    narrator "Vasumitrā identifica sua realização como a libertação dos bodhisattvas chamada completa realização da liberdade do desejo. Ela diz aparecer a devas, nāgas, yakṣas, gandharvas, asuras, garuḍas, kinnaras, mahoragas, humanos e não humanos conforme suas disposições. Aos seres cercados pelo desejo, ensina o Dharma; os resultados variam: ouvir o ensinamento, vê-la, segurar sua mão, estar a sós com ela, contemplá-la, bocejar, fechar os olhos, abraçá-la ou beijá-la são associados no relato a diferentes samādhis dos bodhisattvas. Entre os nomes mencionados estão o reino do não apego, a alegria, a luz do desapego e a manifestação da forma de paz. Assim, ela estabelece os que a procuram nessa libertação e na manifestação do nível de onisciência livre de apego."
    speaker_012 "A mesma libertação pode conduzir seres por condições tão diferentes?"
    speaker_054 "O ensinamento os estabelece na liberdade do desejo e em samādhis ligados ao não apego."
    speaker_012 "Que raízes de mérito te levaram a essa realização?"
    centered "Cena 4 — Sumati e o sino precioso"
    narrator "Em resposta à pergunta de Sudhana, Vasumitrā recorda o Tathāgata Atyuccagāmin. Por amor aos seres, ele foi à capital Sumukhā; quando pôs o pé no limiar do portal da cidade, esta tremeu e se tornou vasta e adornada com muitas joias. No céu surgiram luz, flores preciosas, música divina e nuvens de devas. Vasumitrā conta que, naquela vida, era Sumati, esposa de um grande mercador. Inspirados pelos sinais do Buda, ela e o marido correram até ele numa rua central. Com fé intensa, Sumati ofereceu-lhe um sino precioso. Mañjuśrī Kumārabhūta era então assistente do Bhagavat; por meio dele, Sumati desenvolveu a aspiração à iluminação completa."
    speaker_054 "Em outra vida, eu era Sumati e ofereci um sino precioso ao Tathāgata Atyuccagāmin."
    speaker_012 "E foi por intermédio de Mañjuśrī que surgiu tua aspiração à iluminação?"
    speaker_054 "Sim. Essa é a origem que recordo para a realização que te expliquei."
    centered "Cena 5 — A próxima orientação"
    narrator "Vasumitrā delimita com cuidado o que sabe: conhece essa libertação, mas não pode descrever a conduta nem as qualidades dos bodhisattvas cuja sabedoria e meios são vastos e invencíveis. Então orienta Sudhana a procurar Veṣṭhila, um chefe de família na cidade de Śubhapāraṃgama, na região sul. Veṣṭhila faz oferendas a um assento de sândalo que é um santuário do tathāgata; Sudhana deve perguntar-lhe como um bodhisattva treina e pratica sua conduta. Sudhana inclina a cabeça aos pés de Vasumitrā, circum-ambula-a centenas de milhares de vezes mantendo-a à direita e, olhando para trás repetidamente, parte. A visita termina com a continuidade de sua busca, sem que a orientação recebida altere os acontecimentos narrados."
    speaker_054 "Conheço esta libertação, mas não posso descrever as realizações daqueles bodhisattvas de alcance ilimitado."
    speaker_054 "Procura Veṣṭhila em Śubhapāraṃgama e pergunta-lhe sobre o treino e a prática dos bodhisattvas."
    speaker_012 "Recebo tua orientação com gratidão e seguirei para encontrá-lo."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Como refletir sobre o ensinamento de Vasumitrā antes de seguir viagem?"
        "Considerar como diferentes encontros podem ser ocasião para ensinar liberdade do desejo.":
            narrator "Uma reflexão coerente com os meios descritos por Vasumitrā."
        "Concluir que todos os seres alcançam exatamente o mesmo samādhi pelo mesmo meio.":
            narrator "O capítulo associa meios distintos a samādhis diferentes; a viagem de Sudhana prossegue."
        "Supor que Vasumitrā descreveu todas as práticas dos bodhisattvas.":
            narrator "Ela declara conhecer apenas essa libertação e encaminha Sudhana a Veṣṭhila."
    call quiz_ch28
    menu:
        "Continuar — capítulo 29":
            jump chapter_29
        "Voltar ao índice":
            jump chapter_index

label quiz_ch28:
    centered "A libertação ensinada por Vasumitrā"
    narrator "Escolha a afirmação que corresponde ao ensinamento explícito do capítulo."
    while True:
        menu:
            "Qual libertação Vasumitrā diz ter alcançado?"
            "A completa realização da liberdade do desejo.":
                if 0 == 0:
                    narrator "Correto: Vasumitrā nomeia a completa realização da liberdade do desejo."
                    return
                else:
                    narrator "Relembre o nome da libertação que Vasumitrā declara ter alcançado."
            "A libertação de abandonar a aspiração à iluminação.":
                if 1 == 0:
                    narrator "Correto: Vasumitrā nomeia a completa realização da liberdade do desejo."
                    return
                else:
                    narrator "Relembre o nome da libertação que Vasumitrā declara ter alcançado."
            "A libertação de permanecer em Sumukhā.":
                if 2 == 0:
                    narrator "Correto: Vasumitrā nomeia a completa realização da liberdade do desejo."
                    return
                else:
                    narrator "Relembre o nome da libertação que Vasumitrā declara ter alcançado."

label chapter_29:
    hide screen master_provisional_badge
    scene bg_ch29 with dissolve
    show master_ch29_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 29 — Veṣṭhila"
    centered "Cena 1 — A pergunta de Sudhana e a libertação de Veṣṭhila"
    narrator "Sudhana chega a Śubhapāraṃgama e procura o chefe de família Veṣṭhila. Depois de reverenciá-lo, pergunta como os bodhisattvas devem treinar e praticar sua conduta. Veṣṭhila responde que alcançou a libertação do bodhisattva chamada realização do ápice da inexauribilidade. Explica que, em sua compreensão, os tathāgatas não entram verdadeiramente em nirvāṇa completo: a manifestação dessa passagem serve para conduzir seres. Relata também que, ao abrir a porta do santuário do trono de sândalo do Tathāgata, alcançou um samādhi chamado exibição da linhagem ininterrupta dos budas, no qual repousa a cada instante mental."
    speaker_012 "Veṣṭhila, desejo compreender como se treina e se pratica a conduta do bodhisattva."
    speaker_055 "Minha realização é chamada ápice da inexauribilidade; dela conheço uma dimensão da via."
    speaker_012 "E qual é o alcance do samādhi que você alcançou?"
    centered "Cena 2 — Uma sucessão sem fim de budas"
    narrator "Veṣṭhila descreve uma sucessão de tathāgatas do passado, do futuro e do presente. Em instantes mentais sucessivos, percebe cem budas, mil, quantidades cada vez maiores e, por fim, números inexprimíveis, incluindo os budas das dez direções e de incontáveis sistemas de mundos. Não vê apenas sua aparição: reconhece suas aspirações iniciais, orações, conduta, perfeições, estágios de bodhisattva, paciência, purificação de mundos, amadurecimento dos seres e ensinamentos. Diz que conserva claramente o Dharma ouvido, compreende-o com inteligência e o ilumina com sabedoria. A amplitude dessa percepção é apresentada como uma sucessão contínua, não como uma única visão isolada."
    speaker_055 "A cada instante, percebo a sucessão dos budas e os caminhos pelos quais desenvolveram sua aspiração e sua prática."
    speaker_012 "E o Dharma que eles ensinaram também permanece claro para você?"
    speaker_055 "Eu o retenho, distingo e compreendo com memória, inteligência e sabedoria."
    centered "Cena 3 — O próximo guia: Avalokiteśvara"
    narrator "Veṣṭhila declara conhecer essa libertação, mas não poder descrever a conduta dos bodhisattvas cujo saber alcança os três tempos num instante e cuja sabedoria abrange o reino dos fenômenos e os ensinamentos de todos os tathāgatas. Em seguida, orienta Sudhana a ir ao monte Potalaka, no sul, onde reside Avalokiteśvara, e a perguntar como se treina e se pratica a conduta do bodhisattva. Seus versos descrevem Potalaka como montanha adornada por árvores preciosas, flores, parques, lagos de lótus e riachos. Então Sudhana inclina a cabeça aos pés de Veṣṭhila, circunda-o muitas centenas de milhares de vezes, mantendo-o à direita, olha para trás repetidamente e parte."
    speaker_055 "Minha compreensão não alcança a medida da conduta dos bodhisattvas de sabedoria tão vasta."
    speaker_055 "No sul fica Potalaka; procure Avalokiteśvara e pergunte-lhe sobre a prática da conduta do bodhisattva."
    speaker_012 "Recebo sua orientação e sigo adiante, mantendo sua instrução em mente."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao ouvir a explicação de Veṣṭhila sobre a sucessão dos budas, em que aspecto você gostaria de refletir?"
        "A aspiração inicial":
            narrator "A aspiração aparece entre as etapas que Veṣṭhila percebe na sucessão dos budas."
        "A preservação do Dharma":
            narrator "Veṣṭhila relata que retém e compreende os ensinamentos ouvidos."
        "A vastidão da sucessão":
            narrator "Veṣṭhila descreve budas em números que se ampliam até o inexprimível."
    call quiz_ch29
    menu:
        "Continuar — capítulo 30":
            jump chapter_30
        "Voltar ao índice":
            jump chapter_index

label quiz_ch29:
    centered "Nome do samādhi"
    narrator "Escolha a resposta com base no relato de Veṣṭhila."
    while True:
        menu:
            "Como se chama o samādhi que Veṣṭhila alcançou ao abrir a porta do santuário do trono de sândalo?"
            "A exibição da linhagem ininterrupta dos budas":
                if 0 == 0:
                    narrator "Correto: esse é o nome dado no capítulo ao samādhi de Veṣṭhila."
                    return
                else:
                    narrator "Essa não é a resposta indicada no relato. Releia o nome da realização de Veṣṭhila."
            "A entrada no caminho de vasta bondade":
                if 1 == 0:
                    narrator "Correto: esse é o nome dado no capítulo ao samādhi de Veṣṭhila."
                    return
                else:
                    narrator "Essa não é a resposta indicada no relato. Releia o nome da realização de Veṣṭhila."
            "A realização de todas as perfeições":
                if 2 == 0:
                    narrator "Correto: esse é o nome dado no capítulo ao samādhi de Veṣṭhila."
                    return
                else:
                    narrator "Essa não é a resposta indicada no relato. Releia o nome da realização de Veṣṭhila."

label chapter_30:
    hide screen master_provisional_badge
    scene bg_ch30 with dissolve
    show master_ch30_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 30 — Avalokiteśvara"
    centered "Cena 1 — A busca no monte Potalaka"
    narrator "Tendo em mente a instrução de Veṣṭhila, a linhagem dos budas e os nomes que ouvira, Sudhana segue até o monte Potalaka. Ele sobe e procura Avalokiteśvara. Na encosta superior do lado oeste, encontra uma clareira verde, cercada por uma grande floresta e embelezada por fontes, cascatas e riachos. Avalokiteśvara está sentado sobre uma rocha de diamante, rodeado por incontáveis bodhisattvas em assentos de várias joias. Ensina a exposição chamada A Clara Instrução da Porta do Amor e da Compaixão, cujo propósito é reunir todos os seres ao Dharma. Ao avistá-lo, Sudhana sente grande alegria, junta as mãos em homenagem e se aproxima."
    speaker_012 "Depois de tantas instruções guardadas na memória, cheguei ao lugar onde posso perguntar sobre a prática."
    narrator "Na clareira, Avalokiteśvara ensina rodeado por uma assembleia de bodhisattvas."
    centered "Cena 2 — A pergunta e a porta da compaixão"
    narrator "Sudhana se aproxima, inclina a cabeça aos pés de Avalokiteśvara e o circunda muitas centenas de milhares de vezes, mantendo-o à sua direita. Então pergunta como os bodhisattvas devem treinar e praticar sua conduta. Avalokiteśvara estende a mão direita, de brilho dourado e rodeada por luzes multicoloridas, e a pousa sobre a cabeça de Sudhana. Ele elogia a aspiração de Sudhana à iluminação completa e apresenta a porta desimpedida da grande compaixão. Por essa via, explica, amadurece e guia os seres sem distinção. Reúne-os por generosidade, palavras agradáveis, ações benéficas e pela prática daquilo que ensina, sem abandonar a atenção ao que é necessário para os seres."
    speaker_012 "Desenvolvi a aspiração à iluminação completa; peço orientação para treinar e praticar a conduta do bodhisattva."
    speaker_056 "A grande compaixão é uma porta de atividade: nela, o cuidado não separa os seres em grupos merecedores ou não."
    speaker_012 "Então a prática precisa alcançar cada ser por meios que ele possa receber."
    centered "Cena 3 — Formas de apoio e destemor"
    narrator "Avalokiteśvara explica que amadurece os seres manifestando corpos, cores, formas e raios de luz, falando segundo suas aspirações e ensinando o Dharma conforme seus desejos. Também manifesta condutas e emanações adequadas, convive com seres em diferentes condições e, por vezes, mostra milagres para inspirar quem ainda não se empenha em acumular virtudes. Diz ter cultivado essa porta para servir de apoio e dissipar medos: de perigo, confusão, cativeiro, perda, falta de sustento, má reputação, saṃsāra, morte e destinos inferiores, entre outros. Segundo sua exposição, tornar seu nome conhecido e abrir uma porta de atenção plena nos mundos ajuda a libertar os seres do medo e a firmar neles uma aspiração irreversível à iluminação."
    speaker_056 "Ensino de acordo com as aspirações e me manifesto de modos que os seres possam reconhecer."
    speaker_012 "E essa adaptação serve para conduzi-los, não para afastar a compaixão de alguém."
    speaker_056 "Meu voto é ser apoio diante dos medos e conduzir os seres à aspiração que não retrocede."
    centered "Cena 4 — O ensinamento sobre recordar o nome"
    narrator "Em versos, Avalokiteśvara amplia os exemplos de sua libertação. Ensina que, segundo essa porta, aqueles que recordam seu nome podem ser libertados de prisões, correntes, punições injustas, ameaças e agressões; menciona perigos em florestas, entre animais, diante de armas, fogo, água e inimigos, bem como venenos e seres nocivos. A exposição também atribui à recordação proteção contra separação de familiares, pobreza e renascimento em destinos desfavoráveis, e fala de renascimento entre devas ou humanos e de ouvir o Dharma dos budas. Avalokiteśvara ressalva que esses e outros meios são inumeráveis, mas que conhece essa libertação, não todas as qualidades dos bodhisattvas dotados de qualidades."
    speaker_056 "Os versos apresentam muitos modos pelos quais, segundo esta libertação, a recordação do meu nome afasta o medo."
    speaker_012 "E ainda assim você distingue o que conhece da vastidão das qualidades dos outros bodhisattvas."
    speaker_056 "Conheço esta porta; não afirmo conhecer todas as qualidades dos que possuem qualidades."
    centered "Cena 5 — Ananyagāmin chega, e Sudhana segue adiante"
    narrator "Então Ananyagāmin vem do leste pelo céu e pousa num pico da cordilheira Cakravāla, no mundo Sahā. A chegada faz esse mundo estremecer de seis maneiras e transformá-lo numa composição de muitas joias. A luz de Ananyagāmin supera a do sol, da lua e de muitas outras fontes; ilumina até os grandes infernos e as existências sombrias, enquanto os sofrimentos dos destinos inferiores cessam e caem chuvas de joias e oferendas. Ele vai até o Bhagavat, e sua imagem aparece nas moradas dos seres conforme seus desejos; também surge diante de Avalokiteśvara. Este pergunta a Sudhana se viu a chegada e o envia a Ananyagāmin para perguntar como um bodhisattva deve treinar e praticar. Sudhana presta homenagem, circunda Avalokiteśvara e parte, olhando para trás repetidas vezes."
    speaker_056 "Você viu Ananyagāmin chegar à assembleia? Vá até ele e pergunte sobre o treinamento e a prática dos bodhisattvas."
    speaker_012 "Vou prosseguir com a pergunta que trouxe até você e buscar a instrução indicada."
    narrator "Depois de homenagear Avalokiteśvara, Sudhana parte, voltando o olhar para trás várias vezes."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto da instrução de Avalokiteśvara você gostaria de ponderar antes de seguir?"
        "Adaptar a forma de ajudar às aspirações dos seres":
            narrator "Você destaca a atenção de Avalokiteśvara às diferentes aspirações."
        "Reunir os seres por generosidade e benefício":
            narrator "Você destaca os meios de acolhimento enumerados por Avalokiteśvara."
        "Ser apoio diante do medo":
            narrator "Você destaca o voto de amparar os seres contra os temores."
    call quiz_ch30
    menu:
        "Continuar — capítulo 31":
            jump chapter_31
        "Voltar ao índice":
            jump chapter_index

label quiz_ch30:
    centered "A porta ensinada em Potalaka"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito do capítulo."
    while True:
        menu:
            "Como Avalokiteśvara descreve reunir os seres pela porta da grande compaixão?"
            "Por generosidade, palavras agradáveis, benefício e pela prática do que ensina.":
                if 0 == 0:
                    narrator "Correto: esses são os meios enumerados por Avalokiteśvara."
                    return
                else:
                    narrator "Releia a explicação da porta desimpedida da grande compaixão."
            "Somente por debates em assembleias e disputas com adversários.":
                if 1 == 0:
                    narrator "Correto: esses são os meios enumerados por Avalokiteśvara."
                    return
                else:
                    narrator "Releia a explicação da porta desimpedida da grande compaixão."
            "Apenas por afastar-se dos seres e permanecer em silêncio.":
                if 2 == 0:
                    narrator "Correto: esses são os meios enumerados por Avalokiteśvara."
                    return
                else:
                    narrator "Releia a explicação da porta desimpedida da grande compaixão."

label chapter_31:
    hide screen master_provisional_badge
    scene bg_ch31 with dissolve
    show master_ch31_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 31 — Ananyagāmin"
    centered "Cena 1 — Da contemplação à busca"
    narrator "Após receber os versos de sabedoria de Avalokiteśvara, Sudhana ainda não se cansara de contemplar o bodhisattva. Mesmo assim, para não contrariar sua instrução, dirigiu-se a Ananyagāmin. Ao chegar, inclinou a cabeça aos pés do bodhisattva e permaneceu diante dele com as mãos unidas em homenagem. Sudhana explicou que havia despertado a aspiração pela iluminação completa e suprema, mas não sabia como os bodhisattvas deveriam se treinar na conduta de bodhisattva nem como deveriam praticá-la. Pediu que Ananyagāmin lhe ensinasse sobre esses pontos."
    speaker_012 "Aspiro à iluminação completa e suprema, mas ainda busco compreender como treinar e praticar a conduta de bodhisattva."
    speaker_057 "Posso compartilhar a libertação que alcancei; escutarei com atenção a tua pergunta."
    centered "Cena 2 — A libertação e a jornada inconcebível"
    narrator "Ananyagāmin disse ter alcançado a libertação de bodhisattva chamada surgimento de todas as portas. Quando Sudhana perguntou em que reino e aos pés de qual tathāgata ela fora obtida, Ananyagāmin advertiu que a explicação era difícil de compreender. Segundo ele, são necessários o cuidado de um bom amigo espiritual, a consideração dos budas, raízes de mérito acumuladas, motivação pura, faculdades de bodhisattva e olhos de sabedoria para ouvir, apreender, acreditar e compreender tal ensinamento. Sudhana pediu que prosseguisse, afirmando estar sob o cuidado de bons amigos espirituais e ter fé e aspiração. Ananyagāmin então identificou Śrīgarbhavatī, no leste, e o Tathāgata Samantaśrīsaṃbhava como a origem de sua realização."
    speaker_012 "De que tathāgata veio essa realização, e de que reino partiste? Peço que me expliques."
    speaker_057 "Alcancei-a aos pés de Samantaśrīsaṃbhava, em Śrīgarbhavatī, no leste; compreender esta jornada requer condições profundas."
    speaker_012 "Estou sob o cuidado de bons amigos espirituais e mantenho fé e aspiração. Por favor, continua."
    centered "Cena 3 — Servir os seres e indicar o próximo mestre"
    narrator "Ananyagāmin contou que, durante uma passagem de duração inconcebível por reinos búdicos, cada desenvolvimento de aspiração acompanhava passos que atravessavam incontáveis reinos, cada qual com um tathāgata. Ele percebeu esses budas e fez oferendas autorizadas por eles, compostas pela mente e seladas pela natureza não composta dos fenômenos. Também percebeu os seres e suas mentes e faculdades; manifestou corpos conforme suas aspirações, proclamou o Dharma, irradiou luz, ofereceu necessidades diversas e fortaleceu o próprio corpo para continuar a amadurecê-los e guiá-los. Disse ter vindo, de modo semelhante, de todas as demais direções, acima e abaixo. Contudo, conhecia apenas essa libertação e não podia descrever a conduta de bodhisattvas de alcance ilimitado. Indicou Mahādeva, na cidade de Dvāravatī, como próximo mestre. Sudhana reverenciou-o, circundou-o muitas centenas de milhares de vezes e partiu, olhando para trás repetidamente."
    speaker_057 "Em todos esses reinos, minha atividade foi perceber os seres e trabalhar para amadurecê-los e guiá-los."
    speaker_057 "Conheço apenas esta libertação. Em Dvāravatī, procura Mahādeva e pergunta como treinar e praticar a conduta de bodhisattva."
    speaker_012 "Recebo tua orientação e sigo adiante, mantendo tua instrução em mente."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Que aspecto do relato de Ananyagāmin você gostaria de ponderar antes de seguir? Esta escolha é opcional e não altera os acontecimentos."
        "As condições para compreender a libertação":
            narrator "A reflexão destaca o cuidado espiritual, o mérito, a motivação e a sabedoria mencionados por Ananyagāmin."
        "A atividade de amadurecer e guiar os seres":
            narrator "A reflexão acompanha as ações que Ananyagāmin descreveu durante sua jornada."
        "A humildade ao reconhecer os próprios limites":
            narrator "A reflexão retoma por que Ananyagāmin encaminhou Sudhana a Mahādeva."
    call quiz_ch31
    menu:
        "Continuar — capítulo 32":
            jump chapter_32
        "Voltar ao índice":
            jump chapter_index

label quiz_ch31:
    centered "Recordar a orientação"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito do capítulo."
    while True:
        menu:
            "A quem Ananyagāmin orienta Sudhana a visitar em Dvāravatī?"
            "Mahādeva":
                if 0 == 0:
                    narrator "Correto: Ananyagāmin indica Mahādeva, que reside em Dvāravatī."
                    return
                else:
                    narrator "Releia a orientação final: o próximo mestre indicado para Dvāravatī é Mahādeva."
            "Avalokiteśvara":
                if 1 == 0:
                    narrator "Correto: Ananyagāmin indica Mahādeva, que reside em Dvāravatī."
                    return
                else:
                    narrator "Releia a orientação final: o próximo mestre indicado para Dvāravatī é Mahādeva."
            "Samantaśrīsaṃbhava":
                if 2 == 0:
                    narrator "Correto: Ananyagāmin indica Mahādeva, que reside em Dvāravatī."
                    return
                else:
                    narrator "Releia a orientação final: o próximo mestre indicado para Dvāravatī é Mahādeva."

label chapter_32:
    hide screen master_provisional_badge
    scene bg_ch32 with dissolve
    show master_ch32_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 32 — Mahādeva"
    centered "Cena 1 — A busca no templo da encruzilhada"
    narrator "Sudhana chega a Dvāravatī com a aspiração de seguir a vasta conduta dos bodhisattvas e de compreender a sabedoria e as práticas associadas a ela. Ao perguntar por Mahādeva, ouve de muitas pessoas que o deva está no templo da encruzilhada, ensinando o Dharma aos seres. Sudhana vai até ele, inclina a cabeça aos seus pés e permanece diante dele com as mãos juntas. Expõe sua aspiração pela iluminação completa e pede instrução: quer saber como os bodhisattvas treinam na própria conduta e de que modo a praticam."
    speaker_012 "Vim buscando compreender como se cultiva a conduta dos bodhisattvas, não apenas como aspiração, mas como prática."
    speaker_058 "Você chegou ao lugar certo para perguntar. Traga sua questão com atenção."
    centered "Cena 2 — O louvor aos bodhisattvas"
    narrator "Mahādeva estende seus quatro braços e, com grande rapidez, traz água dos quatro grandes oceanos para lavar a boca. Depois espalha flores douradas sobre Sudhana. Ensina que encontrar ou ouvir bodhisattvas é raro e que sua presença é extraordinária: eles sustentam e abrigam os seres, iluminam-nos, mostram a verdade a quem está na ignorância e guiam os que seguem o Dharma rumo à onisciência. Mahādeva os chama de destruidores de visões errôneas: com mentes imaculadas, manifestam corpos e atividades puros, fazem brilhar a eloquência de uma fala sem falhas e permanecem manifestos com motivação pura."
    speaker_058 "A presença de um bodhisattva pode orientar muitos seres; por isso, não a tomem como algo comum."
    speaker_012 "O que você descreve une clareza, refúgio e direção para quem ainda não vê o caminho."
    centered "Cena 3 — A rede de nuvens e a generosidade"
    narrator "Mahādeva declara ter alcançado a libertação do bodhisattva chamada “rede de nuvens”. Quando Sudhana pergunta seu alcance, surgem em todas as direções, diante dele, montes de metais e joias, ornamentos, flores, perfumes, incensos, guirlandas, unguentos, pós, tecidos, guarda-sóis, estandartes, bandeiras e instrumentos musicais; também aparecem incontáveis jovens. Mahādeva exorta Sudhana a usar essas dádivas em grandes atos de generosidade: fazer oferendas aos tathāgatas, reunir discípulos por esse meio, praticar a perfeição da generosidade e ensinar o mundo. Acrescenta que estabelece incontáveis seres na disposição contínua de dar e os inspira a gerar mérito e aspirar à iluminação completa."
    speaker_012 "Que alcance tem a libertação que você chama de rede de nuvens?"
    speaker_058 "A abundância pode tornar-se ocasião para dar, fazer oferendas e conduzir outros à aspiração desperta."
    speaker_012 "Então o ensinamento não termina na dádiva: ele também aponta para o mérito e para a iluminação completa."
    centered "Cena 4 — Meios hábeis e a próxima mestra"
    narrator "Mahādeva descreve meios distintos para afastar seres do que não é virtuoso: aos apegados aos prazeres sensoriais, faz perceber a feiura dos objetos dos sentidos; aos dominados por ira e orgulho, manifesta formas terríveis; aos negligentes na diligência, manifesta perigos de fogo, água, reis e ladrões, levando-os à diligência. Por esses meios, estabelece seres na virtude e os orienta para as perfeições e o Dharma sem obscurecimentos. Diz conhecer apenas a libertação da rede de nuvens, compara as qualidades dos bodhisattvas a forças que vencem aflições e sofrimento, e encaminha Sudhana a Sthāvarā. Sudhana homenageia Mahādeva, circum-ambula-o centenas de milhares de vezes e parte, olhando para trás repetidamente."
    speaker_058 "Os meios variam conforme aquilo que precisa ser abandonado e a virtude que deve ser cultivada."
    speaker_058 "Procure Sthāvarā, a deusa da terra no bodhimaṇḍa de Magadha, e pergunte como se treina e pratica a conduta dos bodhisattvas."
    speaker_012 "Recebo sua orientação e seguirei para fazer essa pergunta à próxima mestra."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o ensinamento de Mahādeva, que aspecto você gostaria de considerar primeiro?"
        "A generosidade como prática":
            narrator "A dádiva pode servir à prática da perfeição da generosidade e ao benefício de outros."
        "Os meios adequados às condições":
            narrator "Mahādeva descreve métodos diferentes para conduzir seres à virtude."
        "A humildade diante do conhecimento":
            narrator "Mahādeva reconhece conhecer somente a libertação da rede de nuvens e indica outra mestra."
    call quiz_ch32
    menu:
        "Continuar — capítulo 33":
            jump chapter_33
        "Voltar ao índice":
            jump chapter_index

label quiz_ch32:
    centered "Reconheça o ensinamento"
    narrator "Escolha a resposta que corresponde ao que Mahādeva diz explicitamente no capítulo."
    while True:
        menu:
            "Qual libertação Mahādeva afirma ter alcançado?"
            "A rede de nuvens":
                if 0 == 0:
                    narrator "Correto: Mahādeva nomeia a libertação chamada rede de nuvens."
                    return
                else:
                    narrator "Releia o ensinamento: Mahādeva declara conhecer a libertação chamada rede de nuvens."
            "O oceano de samādhi":
                if 1 == 0:
                    narrator "Correto: Mahādeva nomeia a libertação chamada rede de nuvens."
                    return
                else:
                    narrator "Releia o ensinamento: Mahādeva declara conhecer a libertação chamada rede de nuvens."
            "A chama da onisciência":
                if 2 == 0:
                    narrator "Correto: Mahādeva nomeia a libertação chamada rede de nuvens."
                    return
                else:
                    narrator "Releia o ensinamento: Mahādeva declara conhecer a libertação chamada rede de nuvens."

label chapter_33:
    hide screen master_provisional_badge
    scene bg_ch33 with dissolve
    show master_ch33_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 33 — Sthāvarā"
    centered "Cena 1 — A chegada anunciada"
    narrator "Depois de chegar à bodhimaṇḍa de Magadha, Sudhana é reconhecido pelas deusas da terra. Um milhão delas anuncia umas às outras a chegada daquele que será refúgio dos seres, possui a essência dos tathāgatas e romperá a ignorância. Sthāvarā e as demais deusas fazem a grande terra tremer, produzem um som semelhante a trovão profundo e iluminam o mundo de bilhões de mundos com vasta luz. Adornadas de joias, elas se movem no céu como clarões. Ao se erguerem do solo, fazem brotar sementes, florescer árvores, fluir rios e elevar águas; seguem-se chuva perfumada, flores dispersas pelo vento, sons musicais, gritos de animais e seres, montanhas em choque e tesouros emergindo."
    speaker_059 "Aquele que será refúgio para os seres está chegando à bodhimaṇḍa!"
    speaker_012 "Cheguei ao lugar onde encontrarei Sthāvarā; que eu receba sua orientação com atenção."
    centered "Cena 2 — O testemunho dos méritos"
    narrator "Sthāvarā acolhe Sudhana e diz que aquela área foi o lugar onde, no passado, ele viveu e gerou raízes de mérito, e que ela própria é testemunha disso. Pergunta se ele deseja ver uma fração do amadurecimento desses méritos. Sudhana inclina a cabeça aos pés da deusa, dá muitas centenas de milhares de voltas ao redor dela mantendo-a à sua direita e, de mãos postas diante dela, responde afirmativamente. Então Sthāvarā bate o pé no chão e revela incontáveis milhões de tesouros preciosos. Explica que eles acompanham Sudhana, vão adiante dele, são protegidos pelo poder de seus méritos e podem ser usados conforme sua necessidade."
    speaker_060 "Este lugar testemunha raízes de mérito que você gerou no passado. Deseja ver um pouco de seu amadurecimento?"
    speaker_012 "Sim, venerável; desejo ver essa manifestação."
    speaker_060 "Os tesouros que surgem são fruto de seus méritos; tome deles o que precisar."
    centered "Cena 3 — A essência da sabedoria invencível"
    narrator "Sthāvarā revela ter alcançado a libertação do bodhisattva chamada essência da sabedoria invencível. Desde o tempo do Tathāgata Dīpaṅkara, diz ela, acompanha e protege bodhisattvas. Descreve uma prática que abrange conduta mental, sabedoria, votos, conduta pura e samādhis, além das motivações e cognições superiores dos bodhisattvas. Essa libertação também lhe permite dominar poderes, abarcar todos os reinos, receber profecias dos tathāgatas, ver a realização da budeidade, conhecer modos de girar a roda do Dharma e de elucidar sutras, irradiar o Dharma, amadurecer os seres e manifestar as atividades miraculosas dos budas. Ela a recebeu do Tathāgata Sunetra, em um passado além de incontáveis eras, no kalpa Avabhāsavyūha e no mundo Candradhvajā."
    speaker_060 "A libertação que conheço é a essência da sabedoria invencível; por ela, sigo e protejo bodhisattvas desde o tempo de Dīpaṅkara."
    speaker_012 "Sua descrição mostra a amplitude dessa libertação e de sua prática ao longo do tempo."
    centered "Cena 4 — A próxima mestra"
    narrator "Sthāvarā afirma que, ao cultivar e ampliar essa libertação até o presente kalpa Bhadra, nunca foi privada da visão dos tathāgatas. Durante esse período, reverenciou incontáveis tathāgatas, viu suas manifestações ao irem à bodhimaṇḍa e testemunhou suas raízes de mérito. Ainda assim, declara conhecer somente a libertação que alcançou, sem poder descrever a conduta e as qualidades dos bodhisattvas de vastas realizações. Em seguida, orienta Sudhana a procurar Vāsantī, deusa da noite, na cidade de Kapilavastu, em Magadha, e perguntar como um bodhisattva deve treinar e praticar a conduta do bodhisattva. Sudhana reverencia Sthāvarā, dá muitas voltas ao redor dela e parte, olhando para trás repetidamente."
    speaker_060 "Conheço esta libertação; para aprender sobre o treino e a prática da conduta do bodhisattva, procure Vāsantī em Kapilavastu."
    speaker_012 "Partirei para fazer a pergunta que você indicou e continuarei minha busca."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Que aspecto do ensinamento de Sthāvarā você gostaria de refletir antes de seguir?"
        "O mérito amadurecido":
            narrator "Os tesouros revelados são apresentados como fruto e proteção dos méritos de Sudhana."
        "A libertação da deusa":
            narrator "Sthāvarā explica a essência da sabedoria invencível e sua prática."
        "A orientação seguinte":
            narrator "A deusa indica Vāsantī e a pergunta sobre treinar e praticar a conduta do bodhisattva."
    call quiz_ch33
    menu:
        "Continuar — capítulo 34":
            jump chapter_34
        "Voltar ao índice":
            jump chapter_index

label quiz_ch33:
    centered "Recordar a libertação"
    narrator "Escolha a resposta que corresponde ao nome explícito da libertação de Sthāvarā."
    while True:
        menu:
            "Qual libertação do bodhisattva Sthāvarā diz ter alcançado?"
            "A essência da sabedoria invencível":
                if 0 == 0:
                    narrator "Correto: esse é o nome dado no capítulo."
                    return
                else:
                    narrator "Tente novamente: o capítulo nomeia a libertação de Sthāvarā explicitamente."
            "A libertação da visão dos tesouros":
                if 1 == 0:
                    narrator "Correto: esse é o nome dado no capítulo."
                    return
                else:
                    narrator "Tente novamente: o capítulo nomeia a libertação de Sthāvarā explicitamente."
            "A libertação da roda das montanhas":
                if 2 == 0:
                    narrator "Correto: esse é o nome dado no capítulo."
                    return
                else:
                    narrator "Tente novamente: o capítulo nomeia a libertação de Sthāvarā explicitamente."

label chapter_34:
    hide screen master_provisional_badge
    scene bg_ch34 with dissolve
    show master_ch34_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 34 — Vāsantī"
    centered "Cena 1 — À espera em Kapilavastu"
    narrator "Tendo presente o ensinamento da deusa da terra Sthāvarā, Sudhana chega a Kapilavastu, circunda a cidade mantendo-a à sua direita e entra pelo portão oriental. Após o pôr do sol, espera no cruzamento central, decidido a encontrar Vāsantī. No espaço acima da cidade, ela aparece sentada num lótus aromático, em um trono de leão, dentro de um pavilhão de joias. Seu corpo dourado traz adornos, e constelações, planetas e estrelas aparecem nele. Sudhana percebe, em seus poros, seres libertados de destinos desfavoráveis, outros conduzidos a estados superiores ou amadurecidos para diferentes metas, além de formas e sons usados para guiá-los."
    speaker_012 "Vim buscar a orientação de uma amiga espiritual e compreender o caminho da sabedoria."
    speaker_061 "Observa como a orientação pode alcançar seres de muitas condições e aspirações."
    centered "Cena 2 — A luz que guia seres"
    narrator "Sudhana reverencia Vāsantī e pergunta como um bodhisattva alcança a onisciência e manifesta as dez forças. Ela nomeia sua libertação como uma entrada para guiar seres pela radiância do Dharma que elimina a escuridão. Explica que seu cuidado se ajusta à necessidade: protege viajantes em mares tempestuosos, pessoas perdidas em planícies, montanhas, florestas ou regiões remotas e habitantes aflitos em povoados. Também ampara doentes, idosos, pobres, desprotegidos e encarcerados. Não se trata apenas de afastar perigos imediatos: Vāsantī aspira dissipar a ignorância, conduzir seres ao Dharma, afastá-los de ações nocivas e favorecer seu avanço rumo à iluminação, sem abandonar os seres enquanto houver quem precise ser guiado."
    speaker_012 "Que libertação orienta esse cuidado tão diverso?"
    speaker_061 "Guio seres pela luz do Dharma, respondendo aos perigos e às condições que encontram."
    speaker_061 "Minha aspiração é que o auxílio os conduza além do sofrimento e da confusão."
    centered "Cena 3 — Os versos e a pergunta de Sudhana"
    narrator "Com a bênção dos budas, Vāsantī olha nas dez direções e expõe sua libertação em versos. Fala de amor e compaixão vastos, do ensino do Dharma para beneficiar seres e da percepção de mundos, budas, assembleias, sons e línguas. Descreve conhecimento das mentes, faculdades e aspirações sem apego conceitual, e uma sabedoria que dissipa dúvidas. Também afirma ver mundos e budas em átomos, inclusive a presença de Vairocana junto à árvore da iluminação, ensinando o Dharma da paz. Ao terminar, Sudhana pergunta há quanto tempo ela se estabeleceu na iluminação completa e alcançou a libertação que beneficia os seres."
    speaker_061 "A sabedoria que remove a escuridão também permite perceber os seres em suas muitas condições."
    speaker_012 "Há quanto tempo percorres esse caminho e alcançaste essa libertação?"
    centered "Cena 4 — Memórias de vidas remotas"
    narrator "Vāsantī responde contando duas etapas remotas. Em Ratnaśrīsaṃbhava, a rainha Dharmamaticandrā ouviu da deusa da noite Suviśuddhacandrābhā que o tathāgata Sarvadharmanigarjitarāja alcançara a iluminação; a rainha foi iluminada por essa notícia, entrou sinceramente no caminho e fez oferendas. Vāsantī revela ter sido aquela rainha. Muito depois, como Prajñāvabhāsaśrī, filha de um mercador, ela recebeu a visita de outra deusa da noite, que louvou as qualidades dos budas e lhe mostrou um tathāgata. Ao vê-lo e ouvir o Dharma, Prajñāvabhāsaśrī alcançou samādhis, gerou a aspiração à iluminação e obteve a libertação que guia seres pela radiância do Dharma. Sua abrangência aumentou a cada instante mental."
    speaker_061 "A notícia do despertar de um tathāgata despertou em mim uma aspiração que amadureceu ao longo de vidas remotas."
    speaker_012 "Ouvir o Dharma e encontrar mestres espirituais marcou essa trajetória."
    centered "Cena 5 — A próxima mestra e a despedida"
    narrator "Vāsantī diz conhecer essa libertação, mas não poder descrever toda a conduta e as qualidades dos bodhisattvas de vastas aspirações. Em seguida, orienta Sudhana a procurar Samantagambhīraśrīvimalaprabhā, deusa da noite no bodhimaṇḍa de Magadha, e a perguntar como um bodhisattva deve treinar e praticar a conduta do bodhisattva. Sudhana responde louvando a pureza do corpo e do Dharma de Vāsantī, sua sabedoria sem conceitos e as muitas manifestações que, segundo ele, alcançam seres de acordo com suas aspirações. Então inclina a cabeça aos pés da deusa, circunda-a repetidas vezes mantendo-a à direita e parte, olhando para trás com saudade ainda não satisfeita."
    speaker_061 "Procura Samantagambhīraśrīvimalaprabhā e pergunta como treinar e praticar a conduta do bodhisattva."
    speaker_012 "Recebo tua orientação e seguirei em busca da próxima mestra."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Vāsantī você deseja levar como reflexão antes de seguir?"
        "Ajustar o auxílio à condição de cada ser":
            narrator "Reflita sobre a atenção de Vāsantī às necessidades diversas."
        "Dissipar a escuridão da ignorância":
            narrator "Reflita sobre a radiância do Dharma que orienta."
        "Buscar orientação de mestres espirituais":
            narrator "Reflita sobre a importância atribuída aos bons mestres."
    call quiz_ch34
    menu:
        "Continuar — capítulo 35":
            jump chapter_35
        "Voltar ao índice":
            jump chapter_index

label quiz_ch34:
    centered "Nome da libertação de Vāsantī"
    narrator "Escolha a resposta que corresponde ao nome explicitamente dado por Vāsantī à sua libertação."
    while True:
        menu:
            "Como Vāsantī chama a libertação que alcançou?"
            "A entrada para guiar seres pela radiância do Dharma que elimina a escuridão de todos os seres.":
                if 0 == 0:
                    narrator "Correto: esse é o nome da libertação que Vāsantī declara ter alcançado."
                    return
                else:
                    narrator "Releia a explicação de Vāsantī sobre sua libertação e escolha o nome que ela apresenta."
            "A essência da sabedoria invencível ensinada por Sthāvarā.":
                if 1 == 0:
                    narrator "Correto: esse é o nome da libertação que Vāsantī declara ter alcançado."
                    return
                else:
                    narrator "Releia a explicação de Vāsantī sobre sua libertação e escolha o nome que ela apresenta."
            "O samādhi que revela o domínio iluminado pela sabedoria dos três tempos.":
                if 2 == 0:
                    narrator "Correto: esse é o nome da libertação que Vāsantī declara ter alcançado."
                    return
                else:
                    narrator "Releia a explicação de Vāsantī sobre sua libertação e escolha o nome que ela apresenta."

label chapter_35:
    hide screen master_provisional_badge
    scene bg_ch35 with dissolve
    show master_ch35_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 35 — Samantagambhīraśrīvimalaprabhā"
    centered "Cena 1 — A pergunta de Sudhana e as dez qualidades"
    narrator "Tendo contemplado a realização de Vāsantī, Sudhana chega à deusa noturna Samantagambhīraśrīvimalaprabhā. Inclina a cabeça aos pés dela e a circum-ambula muitas centenas de milhares de vezes, mantendo-a à sua direita. De mãos postas, pergunta como se pratica, avança e realiza a conduta de bodhisattva. A deusa aprova a aspiração e apresenta dez qualidades: percepção dos tathāgatas em samādhi, visão de seus corpos e sinais, compreensão da extensão do reino dos fenômenos e das qualidades búdicas, percepção de luzes e emanações, compreensão da voz e do Dharma, e orientação dos seres por manifestações inconcebíveis. Quem reúne essas qualidades realiza a conduta de bodhisattva."
    speaker_012 "Aspiro à iluminação completa. Como posso praticar e realizar a conduta de bodhisattva?"
    speaker_062 "A conduta se realiza por qualidades que ampliam a percepção dos budas e orientam os seres."
    centered "Cena 2 — A libertação e os tathāgatas dos três tempos"
    narrator "Samantagambhīraśrīvimalaprabhā revela que alcançou a libertação chamada completa subjugação pela bem-aventurança da paz de śamatha. Por seu poder, percebe os tathāgatas dos três tempos, seus campos puros, assembleias, manifestações de samādhi, práticas passadas, nomes, ensinamentos, vozes e durações de vida. Ensina que eles não devem ser fixados como coisas existentes: não vêm nem chegam, são não nascidos e não cessam; fenômenos são como ilusões, mas deles surge benefício para os seres. A deusa amplia, contempla, examina e firma essa libertação por meio da radiância do domínio meditativo dos tathāgatas."
    speaker_062 "Por essa libertação, percebo os tathāgatas e os muitos modos como ensinam e beneficiam os seres."
    speaker_012 "Então essa percepção não os reduz a categorias fixas de vir ou partir."
    centered "Cena 3 — Os dhyānas a serviço dos seres"
    narrator "A deusa explica a finalidade dos quatro dhyānas: no primeiro, manter a grande compaixão e a mente unificada para salvar os seres; no segundo, pacificar a atividade mental e reuni-los com alegria; no terceiro, cultivar equanimidade diante do sofrimento do saṃsāra e realizar a natureza dos seres; no quarto, pôr fim às aflições e ao sofrimento. Com essa libertação, ela amadurece seres por vários meios. Na paz da noite, conduz quem se prende ao prazer sensual a perceber seus limites e a aspirar ao Dharma e à renúncia; também promove fé, ensina o Dharma profundo e favorece condições para virtudes, perfections, amor, grande compaixão e aspiração à onisciência."
    speaker_062 "A meditação não se separa da compaixão: cada dhyāna tem uma finalidade no cuidado dos seres."
    speaker_012 "E seu ensinamento também cria condições para que virtudes e aspiração à onisciência cresçam."
    centered "Cena 4 — Os versos e a indicação do próximo encontro"
    narrator "A deusa limita sua própria afirmação: conhece essa libertação, mas não pode descrever a conduta dos bodhisattvas de alcance inconcebível. Em versos, evoca a visão dos budas, suas aparições vastas, os raios que emergem de seus poros, a chuva sonora do Dharma e Vairocana sob a árvore Bodhi, ensinando conforme as aspirações dos seres. Afirma que a conduta de todos os tathāgatas e a libertação dos bodhisattvas perfeitos excedem seu conhecimento. Em prosa, envia Sudhana à deusa Pramuditanayanajagadviरोcanā, ao sul do bodhimaṇḍa de Vairocana; no verso final, nomeia Jyotirarcinayanā como próxima. Sudhana torna a homenageá-la e parte, olhando para trás repetidamente."
    speaker_062 "As manifestações dos budas são vastas, mas a conduta dos bodhisattvas perfeitos excede o que posso conhecer."
    speaker_062 "Segue adiante e pergunta à deusa que indico sobre a prática para a iluminação."
    speaker_012 "Recebo sua orientação. Partirei mantendo este ensinamento em mente."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o ensinamento da deusa, qual aspecto você gostaria de considerar primeiro?"
        "A compaixão orienta os quatro dhyānas":
            narrator "Uma boa reflexão: a deusa relaciona cada dhyāna ao benefício dos seres."
        "As emanações e o Dharma dos budas":
            narrator "Uma boa reflexão: seus versos descrevem luzes, aparições e ensinamento."
        "As condições que sustentam virtudes":
            narrator "Uma boa reflexão: ela favorece práticas benéficas e a aspiração à onisciência."
    call quiz_ch35
    menu:
        "Continuar — capítulo 36":
            jump chapter_36
        "Voltar ao índice":
            jump chapter_index

label quiz_ch35:
    centered "Finalidade do primeiro dhyāna"
    narrator "Escolha a finalidade explicitamente ensinada no capítulo."
    while True:
        menu:
            "Para que Samantagambhīraśrīvimalaprabhā medita no primeiro dhyāna?"
            "Para permanecer na grande compaixão e manter a mente unificada para salvar todos os seres.":
                if 0 == 0:
                    narrator "Correto: essa é a finalidade que ela atribui ao primeiro dhyāna."
                    return
                else:
                    narrator "Releia as finalidades dos quatro dhyānas e tente novamente."
            "Para pôr fim às aflições e ao sofrimento de todos os seres.":
                if 1 == 0:
                    narrator "Correto: essa é a finalidade que ela atribui ao primeiro dhyāna."
                    return
                else:
                    narrator "Releia as finalidades dos quatro dhyānas e tente novamente."
            "Para cultivar equanimidade diante do sofrimento do saṃsāra e realizar a natureza dos seres.":
                if 2 == 0:
                    narrator "Correto: essa é a finalidade que ela atribui ao primeiro dhyāna."
                    return
                else:
                    narrator "Releia as finalidades dos quatro dhyānas e tente novamente."

label chapter_36:
    hide screen master_provisional_badge
    scene bg_ch36 with dissolve
    show master_ch36_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 36 — Pramuditanayanajagadvirocanā"
    centered "Cena 1 — O encontro na assembleia"
    narrator "Após a instrução recebida de um mestre espiritual, Sudhana aproxima-se da deusa da noite Pramuditanayanajagadvirocanā. Ele a vê no círculo da assembleia do Bhagavat, sentada sobre uma flor no centro de um trono de leões e repousando no samādhi chamado estandarte do poder da vasta alegria imaculada e perfeitamente boa. De todos os poros dela surgem nuvens de manifestações da prática das perfeições. Essas aparições encantam e beneficiam seres, apresentando formas de beleza diversas. A visão não é descrita como uma mudança de lugar: diante de Sudhana, a presença da deusa e suas emanações constituem o foco da contemplação."
    speaker_012 "A presença da mestra abre diante de mim uma visão que não consigo abarcar de uma só vez."
    speaker_063 "Contempla como as práticas se manifestam de modos diversos para beneficiar os seres."
    centered "Cena 2 — As perfeições em incontáveis formas"
    narrator "Sudhana contempla manifestações de generosidade ajustadas às aspirações, percepções e linguagens dos seres: dar sem parcialidade, com respeito, inclusive oferecendo o que é difícil de oferecer. Vê também ensinamentos sobre disciplina e renúncia, paciência diante de dano e desprezo, diligência para alcançar a onisciência, meditação e sabedoria. As aparições ensinam o caráter impermanente e insatisfatório do condicionado, a conduta correta e os meios de abandonar aflições e visões errôneas. Surgem em cores, formas e vozes variadas, inclusive por sons da natureza e de diferentes classes de seres. O capítulo as apresenta como ensinamentos adequados às disposições dos destinatários, que os amadurecem e os conduzem por caminhos diversos."
    speaker_012 "Vejo que a generosidade e as demais práticas aparecem de incontáveis maneiras."
    speaker_063 "As formas e os ensinamentos correspondem às disposições dos seres; o propósito é amadurecê-los."
    centered "Cena 3 — A longa visão das emanações"
    narrator "As manifestações se multiplicam em corpos semelhantes a seres de muitas existências, deuses, humanos, nāgas e outras classes, além de sábios, śrāvakas e pratyekabuddhas. Em todas as direções, elas ensinam e conduzem seres, enquanto formas de bodhisattvas e tathāgatas expressam a amplitude da libertação da deusa. Sudhana vê ensinamentos que libertam do sofrimento dos estados inferiores e do saṃsāra, e outros que estabelecem seres em diferentes níveis, chegando às dez forças. A narrativa atribui essa amplitude ao samādhi e às práticas da deusa, às bênçãos dos tathāgatas e ao amadurecimento de suas raízes de mérito. Depois de contemplar, ouvir e compreender a visão, Sudhana junta as mãos e louva a mestra."
    speaker_012 "As formas são muitas, mas em cada uma reconheço o empenho de guiar os seres."
    speaker_063 "A visão que contemplas manifesta a amplitude da prática e da libertação que realizei."
    centered "Cena 4 — Bhadramati desperta para a aspiração"
    narrator "Respondendo à pergunta de Sudhana sobre o tempo de sua realização, Pramuditanayanajagadvirocanā rememora um passado de eras incontáveis. Em uma vida, foi Bhadramati, rainha principal de um soberano cakravartin. À noite, o Buda Śrisamudra apareceu; a luz e as manifestações do Jina alcançaram os mundos, e dez mil deusas da noite despertaram a rainha e louvaram a rara boa fortuna de um buda ter surgido. Bhadramati viu o Buda junto à árvore da iluminação, sentiu alegria e fez uma vasta aspiração para tornar-se como ele. Com o rei, a corte e muitos seres, foi à presença do Jina e lhe fez oferendas durante vinte mil anos. A deusa diz que aquela foi sua primeira geração da aspiração à iluminação."
    speaker_063 "Naquela vida, eu era Bhadramati; ao ver Śrisamudra, surgiu em mim a aspiração à iluminação."
    speaker_012 "Essa primeira aspiração permaneceu através das muitas existências que você relata?"
    centered "Cena 5 — A libertação e a próxima mestra"
    narrator "A deusa percorre em sua narrativa muitas vidas posteriores, com oferendas, encontros com budas e aprendizado do Dharma; por longo tempo, ainda não compreendia plenamente a natureza e a entrada no oceano dos ensinamentos. Em uma vida como Śaśivakra, ouviu sūtras de Ratnaśrīpradīpaguṇaketu e obteve vasta visão, samādhis e poder de retenção. Ela revela que o rei cakravartin de sua primeira aspiração era Mañjuśrī, e que a deusa da noite que despertou Bhadramati era uma emanação de Samantabhadra. A aspiração a sustentou sem renascimento nos estados inferiores; finalmente, ao ver Ratnaśrīpradīpaguṇaketu, ela alcançou a libertação que descreve. Diz conhecer apenas essa libertação e envia Sudhana a Samantasattvatrāṇojaḥśrī. Ele se curva, circunda a deusa e parte."
    speaker_063 "Conheço esta libertação; vá perguntar a Samantasattvatrāṇojaḥśrī como treinar e praticar a conduta de bodhisattva."
    speaker_012 "Recebo sua orientação e seguirei para encontrar a deusa que indicou."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto da visão da deusa você deseja levar como reflexão antes de prosseguir?"
        "A generosidade adequada às disposições dos seres":
            narrator "Uma reflexão sobre dar com respeito e sem parcialidade."
        "A paciência diante de dano e desrespeito":
            narrator "Uma reflexão sobre a prática da paciência ensinada nas manifestações."
        "A diligência para amadurecer e guiar os seres":
            narrator "Uma reflexão sobre empenho contínuo no caminho."
    call quiz_ch36
    menu:
        "Continuar — capítulo 37":
            jump chapter_37
        "Voltar ao índice":
            jump chapter_index

label quiz_ch36:
    centered "Reconheça o ensinamento"
    narrator "Escolha a resposta que corresponde ao que Sudhana vê no capítulo."
    while True:
        menu:
            "O que Pramuditanayanajagadvirocanā manifesta de seus poros?"
            "Nuvens de manifestações que ensinam as práticas das perfeições e beneficiam os seres.":
                if 0 == 0:
                    narrator "Correto: as emanações ensinam as práticas das perfeições e amadurecem os seres."
                    return
                else:
                    narrator "Relembre a visão de Sudhana: as manifestações emanam da deusa e ensinam as perfeições."
            "Um exército que combate o rei cakravartin.":
                if 1 == 0:
                    narrator "Correto: as emanações ensinam as práticas das perfeições e amadurecem os seres."
                    return
                else:
                    narrator "Relembre a visão de Sudhana: as manifestações emanam da deusa e ensinam as perfeições."
            "Um mapa que revela um único reino futuro.":
                if 2 == 0:
                    narrator "Correto: as emanações ensinam as práticas das perfeições e amadurecem os seres."
                    return
                else:
                    narrator "Relembre a visão de Sudhana: as manifestações emanam da deusa e ensinam as perfeições."

label chapter_37:
    hide screen master_provisional_badge
    scene bg_ch37 with dissolve
    show master_ch37_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 37 — Samantasattvatrāṇojaḥśrī"
    centered "Cena 1 — A luz que abre mundos"
    narrator "Mantendo na memória a orientação recebida de Pramuditanayanajagadvirocanā, Sudhana procura Samantasattvatrāṇojaḥśrī com dedicação e sem orgulho. Para revelar sua libertação, a deusa manifesta o corpo adornado com os sinais de um grande ser e emite da ūrṇā uma luz sem centro nem limite. Os raios iluminam os mundos, entram pelo alto da cabeça de Sudhana e se espalham por seu corpo; ele alcança o samādhi chamado “área completamente livre de partículas”. Então percebe, nos átomos do caminho entre as duas deusas, incontáveis mundos, de formas e condições diversas."
    speaker_012 "A luz que me alcança transforma até o modo como percebo este caminho."
    speaker_064 "Observa sem limitar o olhar: a libertação se manifesta para guiar seres em todos os mundos."
    centered "Cena 2 — Uma presença para cada necessidade"
    narrator "Sudhana vê mundos puros, impuros e mistos, com diferentes formas, seres e destinos. Em cada existência, Samantasattvatrāṇojaḥśrī se faz presente de acordo com a duração da vida, as aspirações, o corpo, a linguagem e a prática de cada ser. Sua ação é descrita como resposta a medos concretos: sofrimento nos infernos, ameaça entre animais, fome e sede, medo da morte, da pobreza, de perder bons mestres ou de decair na aspiração à iluminação. A deusa também se orienta para o conhecimento do Dharma, o amadurecimento das faculdades e a dissipação da ignorância. Comovido, Sudhana presta homenagem e canta sua admiração antes de perguntar sobre a libertação e sua prática."
    speaker_012 "Como compreender uma prática que se ajusta a tantas condições sem abandonar nenhum ser?"
    speaker_064 "A compaixão e os votos orientam a presença conforme aquilo de que cada ser necessita."
    centered "Cena 3 — O mundo que aguardava um buda"
    narrator "Samantasattvatrāṇojaḥśrī relata que, num passado remoto, o rei cakravartin Vairocanaratnapadmagarbhaśrīcūḍa governava uma terra abundante, mas muitos habitantes se julgavam superiores por aparência e condição; o desprezo mútuo fazia diminuir mérito, força e felicidade. Quando se aproximava a manifestação do buda Samantajñānaratnārciśrīguṇaketurāja, a árvore da iluminação irradiou luzes sucessivas: seres viram formas sutis, compreenderam o karma, perceberam os budas e foram amadurecidos para o encontro. No sétimo dia, os habitantes se dirigiram ao local da iluminação. Samantabhadra apareceu sobre a capital e anunciou ao rei que um tathāgata surgira naquela terra."
    speaker_064 "As luzes da árvore prepararam os seres, cada qual segundo o tempo indicado na narrativa."
    speaker_008 "Rei, um tathāgata apareceu nesta terra; ele está no local da iluminação chamado Samantāvabhāsanadharmameghanirghoṣadhvaja."
    centered "Cena 4 — A oferta da princesa"
    narrator "A filha do rei, Padmabhadrābhirāmanetraśrīcandrā, sente alegria ao ver Samantabhadra e aspira a beneficiar os seres como ele. O rei convoca os habitantes para ver o buda e conduz sua comitiva ao local da iluminação, onde presta homenagem. A princesa espalha suas joias sobre o buda; elas se manifestam como um grande para-sol precioso, e ela contempla Vairocana, bodhisattvas, budas e vastos campos de atividade. Ao ouvir o ensinamento, alcança a libertação que Sudhana está estudando. A deusa identifica aquela princesa como ela própria. Também recorda que, dez kalpas antes, Samantabhadra a inspirara a reparar, pintar e adornar uma estátua de um tathāgata, ocasião em que surgiu sua aspiração à iluminação."
    speaker_012 "A princesa que fez a oferta e contemplou essas manifestações eras você?"
    speaker_064 "Sim; a narrativa liga aquela aspiração à orientação de Samantabhadra e à escuta do Dharma."
    centered "Cena 5 — Quinhentos budas e uma prática contínua"
    narrator "A deusa prossegue a cronologia: honrou incontáveis tathāgatas e, no kalpa Mahāprabha, fez oferendas aos quinhentos budas que surgiram. Em diferentes vidas, foi deusa noturna, cakravartin, filha de mercador, rei dos devas, filha de um senhor nāga, deusa do oceano, ṛṣi e deusa da terra. Cada buda lhe ensinou um sūtra e ensinamentos associados; ela os ouviu, reteve e não esqueceu. Diante de cada tathāgata, recitou o Dharma e beneficiou seres. A sucessão de encontros fez surgir em sua mente ensinamentos antes não alcançados, sem afastá-la da conduta excelente. Ela afirma que a libertação é vasta e não tem limite ou centro."
    speaker_064 "Em cada encontro, ouvi e preservei o ensinamento recebido, seguindo a conduta excelente."
    speaker_012 "Então a continuidade da escuta e da prática acompanha suas muitas vidas."
    centered "Cena 6 — O próximo mestre"
    narrator "Samantasattvatrāṇojaḥśrī explica que sua libertação se expressa por manifestações que guiam seres em todos os mundos e que sua própria prática inclui homenagear budas, ouvir e conservar o Dharma e manter os votos de bodhisattva. Ela declara conhecer apenas essa libertação e não poder descrever toda a conduta dos bodhisattvas que se dedicam a um oceano ilimitado de práticas. Em seguida, orienta Sudhana a procurar a deusa noturna Praśantarutasāgaravatī e perguntar como um bodhisattva deve treinar e praticar sua conduta. Sudhana reverencia Samantasattvatrāṇojaḥśrī, dá voltas ao redor dela mantendo-a à direita e parte, olhando para trás repetidas vezes."
    speaker_064 "Não conheço todas as práticas; procure Praśantarutasāgaravatī e pergunte como treinar e praticar a conduta de bodhisattva."
    speaker_012 "Partirei para ouvi-la, levando comigo o ensinamento que você preservou e compartilhou."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre a libertação de Samantasattvatrāṇojaḥśrī, que aspecto você gostaria de considerar?"
        "Adaptar a orientação às condições de cada ser":
            narrator "A deusa é vista manifestando-se de acordo com as condições dos seres."
        "Preservar e praticar os ensinamentos ouvidos":
            narrator "A deusa relata ter ouvido, retido e seguido os ensinamentos dos budas."
        "Manter a aspiração e a conduta de bodhisattva":
            narrator "A narrativa associa a libertação à continuidade dos votos e da conduta excelente."
    call quiz_ch37
    menu:
        "Continuar — capítulo 38":
            jump chapter_38
        "Voltar ao índice":
            jump chapter_index

label quiz_ch37:
    centered "Nome da libertação"
    narrator "Escolha a alternativa que corresponde ao nome da libertação descrita neste capítulo."
    while True:
        menu:
            "Como o capítulo denomina a libertação de Samantasattvatrāṇojaḥśrī?"
            "Manifestações que guiam seres que aparecem em todos os mundos":
                if 0 == 0:
                    narrator "Correto: o capítulo a chama de manifestações que guiam seres que aparecem em todos os mundos."
                    return
                else:
                    narrator "Releia a denominação dada à libertação da deusa: ela trata de manifestações que guiam seres em todos os mundos."
            "O caminho que transforma todos os mundos em um único reino":
                if 1 == 0:
                    narrator "Correto: o capítulo a chama de manifestações que guiam seres que aparecem em todos os mundos."
                    return
                else:
                    narrator "Releia a denominação dada à libertação da deusa: ela trata de manifestações que guiam seres em todos os mundos."
            "A luz que elimina a necessidade de ouvir o Dharma":
                if 2 == 0:
                    narrator "Correto: o capítulo a chama de manifestações que guiam seres que aparecem em todos os mundos."
                    return
                else:
                    narrator "Releia a denominação dada à libertação da deusa: ela trata de manifestações que guiam seres em todos os mundos."

label chapter_38:
    hide screen master_provisional_badge
    scene bg_ch38 with dissolve
    show master_ch38_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 38 — Praśantarutasāgaravatī"
    centered "Cena 1 — A pergunta diante da deusa noturna"
    narrator "Enquanto contempla a libertação que Samantasattvatrāṇojaḥśrī lhe ensinara, Sudhana aproxima-se da deusa noturna Praśantarutasāgaravatī. Inclina a cabeça aos pés dela, dá centenas de milhares de voltas ao redor da mestra e fica diante dela. Explica que busca a iluminação completa e perfeita e que, apoiando-se em bons amigos espirituais, treina e pratica a conduta do bodhisattva. Pede orientação sobre como cultivá-la para fazer surgir a onisciência. A deusa acolhe a pergunta e apresenta a libertação que realizou: a manifestação, em cada instante de mente, do surgimento do poder da vasta alegria. Descreve uma mente equânime, firme, sem apego a um lugar e dedicada a todos os seres."
    speaker_012 "Mestra, busco aprender como se treina na conduta do bodhisattva e como se pratica esse caminho."
    speaker_065 "É louvável que procures essa conduta apoiando-te em bons amigos espirituais; compartilho contigo a libertação que realizei."
    centered "Cena 2 — Alegria que se volta a todos os seres"
    narrator "Praśantarutasāgaravatī descreve seu empenho em amparar os seres, afastá-los do sofrimento e conduzi-los à felicidade suprema dos tathāgatas. Ela ensina o Dharma conforme as condições de cada um: a quem se prende aos sentidos, à raiva, à preguiça, à ignorância ou a visões errôneas, oferece orientações que conduzem às qualidades do caminho. A deusa reúne os seres pelo dom do Dharma e os amadurece para a onisciência. Também diz contemplar assembleias de bodhisattvas nas direções e o corpo de Vairocana, cujas luzes, emanações e manifestações do Dharma se estendem por mundos incontáveis. Ao ver esse campo de manifestações, ela experimenta vasta alegria a cada instante mental."
    speaker_065 "O ensinamento se ajusta às condições dos seres e os conduz, gradualmente, para longe do sofrimento."
    speaker_012 "E contemplar as manifestações dos budas também faz parte dessa libertação?"
    centered "Cena 3 — Uma libertação descrita por analogias"
    narrator "Para explicar a libertação, a deusa a compara, entre outras imagens, à terra que sustenta, à água que satura os seres de compaixão, ao fogo que seca o apego, ao sol que dissipa a ignorância e a uma grande nuvem que faz chover o Dharma. Ela a descreve como ilimitada, não nascida e benéfica, capaz de abranger manifestações e ensinamentos. Sudhana pergunta como se pratica para alcançá-la. A resposta enumera dez grandes qualidades: generosidade que satisfaz os seres; conduta correta que entra nas qualidades dos tathāgatas; paciência que realiza a natureza dos fenômenos; diligência voltada à onisciência; meditação que pacifica aflições; sabedoria do Dharma; métodos para guiar e amadurecer seres; aspiração, força e conhecimento amplos."
    speaker_012 "Como se pratica para realizar uma libertação tão vasta?"
    speaker_065 "Cultivam-se as dez grandes qualidades do bodhisattva: generosidade, conduta, paciência, diligência, meditação, sabedoria, métodos, aspiração, força e conhecimento."
    centered "Cena 4 — A longa trajetória da mestra"
    narrator "Praśantarutasāgaravatī conta que, num passado remoto, foi uma deusa junto à árvore da iluminação no mundo Kanakavimalaprabhāvyūha. Ao ver Avivartyadharmadhātunirghoṣa alcançar o despertar, gerou a aspiração à iluminação. Relata que reverenciou muitos tathāgatas naquele bodhimaṇḍa, ouviu seus ensinamentos e praticou a conduta do bodhisattva por incontáveis kalpas; depois renasceu no mundo Sahā. Venerou Krakucchanda, Kanakamuni e Kāśyapa, entre outros, e alcançou a libertação atual ao contemplar Vairocana manifestando, a cada instante, os caminhos do despertar. Sua narrativa descreve Vairocana e as manifestações em incontáveis mundos e átomos. Ao resumir a duração de sua busca, ela também a situa em um passado de kalpas incontáveis, empregando outra medida temporal no relato."
    speaker_012 "Há quanto tempo começaste a buscar a iluminação e a cultivar essa libertação?"
    speaker_065 "Minha aspiração começou ao contemplar o despertar de Avivartyadharmadhātunirghoṣa; desde então, servi e ouvi muitos budas."
    centered "Cena 5 — Versos, louvor e a próxima mestra"
    narrator "Em versos, a deusa recorda sua aspiração vasta, a escuta dos budas e o cuidado, em vidas passadas, com pais, mães, mestres, pessoas idosas, doentes, pobres e sem proteção. Relata também ter salvado seres de perigos e de sofrimentos ligados ao nascimento, envelhecimento, doença e morte; sua aspiração é aliviar o sofrimento do saṃsāra e conduzir todos à felicidade do despertar. Diz conhecer apenas esta libertação e orienta Sudhana a procurar, no bodhimaṇḍa de Vairocana, a deusa noturna Sarvanagararakṣāsaṃbhavatejaḥśrī, para perguntar sobre a conduta do bodhisattva. Sudhana responde com versos de louvor à mestra, dá centenas de milhares de voltas ao redor dela, mantendo-a à direita, olha para trás repetidamente e parte."
    speaker_065 "No bodhimaṇḍa de Vairocana, procura Sarvanagararakṣāsaṃbhavatejaḥśrī e pergunta-lhe sobre a prática do bodhisattva."
    speaker_012 "Recebi tua orientação, mestra; levarei comigo o ensinamento e seguirei para encontrar a próxima deusa."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Praśantarutasāgaravatī você escolheria levar como reflexão nesta jornada?"
        "Adequar o ensinamento às condições dos seres":
            narrator "Uma reflexão centrada em orientar cada ser conforme suas condições."
        "Cultivar as dez grandes qualidades":
            narrator "Uma reflexão centrada nas práticas enumeradas pela mestra."
        "Contemplar as manifestações de Vairocana":
            narrator "Uma reflexão centrada na visão que desperta a vasta alegria."
    call quiz_ch38
    menu:
        "Continuar — capítulo 39":
            jump chapter_39
        "Voltar ao índice":
            jump chapter_index

label quiz_ch38:
    centered "As dez grandes qualidades"
    narrator "Escolha a resposta que reúne as dez práticas enumeradas por Praśantarutasāgaravatī."
    while True:
        menu:
            "Qual conjunto corresponde às dez grandes qualidades do bodhisattva mencionadas no capítulo?"
            "Generosidade, conduta correta, paciência, diligência, meditação, sabedoria, métodos, aspiração, força e conhecimento.":
                if 0 == 0:
                    narrator "Correto: esse é o conjunto das dez qualidades enumeradas pela deusa."
                    return
                else:
                    narrator "Releia a enumeração da mestra: ela inclui generosidade, métodos, aspiração, força e conhecimento, além das demais qualidades."
            "Generosidade, paciência, concentração, renúncia, compaixão, memória, visão, proteção, silêncio e equanimidade.":
                if 1 == 0:
                    narrator "Correto: esse é o conjunto das dez qualidades enumeradas pela deusa."
                    return
                else:
                    narrator "Releia a enumeração da mestra: ela inclui generosidade, métodos, aspiração, força e conhecimento, além das demais qualidades."
            "Conduta correta, diligência, meditação, sabedoria, oferta, serenidade, disciplina, percepção, contemplação e libertação.":
                if 2 == 0:
                    narrator "Correto: esse é o conjunto das dez qualidades enumeradas pela deusa."
                    return
                else:
                    narrator "Releia a enumeração da mestra: ela inclui generosidade, métodos, aspiração, força e conhecimento, além das demais qualidades."

label chapter_39:
    hide screen master_provisional_badge
    scene bg_ch39 with dissolve
    show master_ch39_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 39 — Sarvanagararakṣāsaṃbhavatejaḥśrī"
    centered "Cena 1 — A chegada diante da deusa"
    narrator "Sudhana segue refletindo, familiarizando-se e praticando a libertação ensinada por Praśantarutasāgaravatī, guardando suas palavras e compreendendo seus aspectos. Ao chegar diante de Sarvanagararakṣāsaṃbhavatejaḥśrī, vê a deusa com uma forma que se manifesta em relação a todos os seres, capaz de aparecer diante deles e de conduzi-los. Tomado de alegria, ele se inclina aos pés dela, faz centenas de milhares de circunvoluções e permanece diante da mestra. Com as mãos unidas em homenagem, pergunta como os bodhisattvas devem treinar para beneficiar os seres e conduzi-los à reunião suprema."
    speaker_012 "Mestra, como pode a conduta do bodhisattva tornar-se remédio e orientação para os seres?"
    speaker_066 "Sua pergunta aponta para uma prática ampla: amadurecer os seres e sustentar a família dos tathāgatas."
    centered "Cena 2 — Uma libertação que ensina em muitas escalas"
    narrator "A deusa chama sua libertação de entrada em sons belos e manifestações profundas. Por meio dela, assume a tarefa de ensinar o Dharma, guiada por grande amor e compaixão, e busca conduzir os seres à aspiração pela iluminação e ao caminho da onisciência. Expõe dez maneiras de compreender o reino dos fenômenos: entre elas, como ilimitado, indiviso, vasto, igual para todos os seres e indestrutível. Ensina também através de numerosos domínios de retenção mental e das sabedorias que vêm de ouvir, contemplar e meditar. Parte de uma existência, escritura ou veículo e amplia o ensino até abarcar todos os tathāgatas e mundos, sem diferenciação no reino do Dharma."
    speaker_066 "Investigo o reino dos fenômenos por dez perspectivas, reunindo mérito e buscando compreender a grandeza dos buddhas."
    speaker_012 "Então o ensino pode começar por um único exemplo e ainda se abrir para uma vastidão sem limite."
    centered "Cena 3 — A lâmpada do Dharma em Vimalābha"
    narrator "A deusa conta que, em um passado remoto, surgiu naquele mundo o tathāgata Sarvadharmasāgaranirghoṣaprabharāja. O rei cakravartin Vimalavakrabhānuprabha recebeu dele o sūtra O Oceano de Todos os Dharmas e, depois, entrou na vida sem lar. Quando o ensinamento se aproximava do fim e os seres estavam obscurecidos por ações e aflições, um seguidor do Dharma lamentou o declínio. Elevando-se à altura de sete palmeiras, manifestou luzes multicoloridas que pacificaram o tormento das aflições e restabeleceram seres na iluminação; assim, o ensinamento permaneceu por mais sessenta mil anos. A monja Dharmacakranirmāṇaprabhā e cem mil monjas desenvolveram a aspiração à iluminação e alcançaram realizações descritas pela deusa."
    speaker_066 "Naquela época, a luz manifestada pelo seguidor do Dharma sustentou o ensinamento quando ele estava prestes a desaparecer."
    speaker_012 "E a monja e sua comitiva receberam essa inspiração ao testemunhar a manifestação?"
    centered "Cena 4 — A monja e os tathāgatas do passado"
    narrator "Sarvanagararakṣāsaṃbhavatejaḥśrī identifica a si mesma como a antiga monja Dharmacakranirmāṇaprabhā e diz que o rei Vimalavakrabhānuprabha era Samantabhadra. Ela explica que ajudou as cem mil monjas a avançar irreversivelmente rumo à iluminação e a estabelecer-se em samādhi, retenção mental e perfeição da sabedoria. Depois, venerou uma sucessão de tathāgatas, desde Sarvadharmasāgaranirghoṣaprabharāja até Dharmadhātunagarābhajñānapradīparāja, ouvindo e preservando seus ensinamentos. Diante deles, obteve essa libertação de várias maneiras e amadureceu incontáveis seres. Ao longo de kalpas, continuou a fazer oferendas e a vigiar seres adormecidos na ignorância, conduzindo-os para fora dos três reinos e em direção à onisciência."
    speaker_066 "Eu fui aquela monja; sob os ensinamentos dos tathāgatas, sustentei a prática e conduzi seres ao amadurecimento."
    speaker_012 "Sua trajetória mostra como a escuta do Dharma e o cuidado com os seres atravessam muitos tempos."
    centered "Cena 5 — Versos, realização e despedida"
    narrator "A deusa afirma conhecer apenas essa libertação e não pretender descrever a conduta dos bodhisattvas que dominam todas as linguagens e ensinam de acordo com as disposições dos seres. Ela orienta Sudhana a procurar Sarvavṛkṣpraphullanasukhasaṃvāsā, deusa da noite que está junto a Vairocana, e perguntar como os bodhisattvas treinam para a onisciência. Em versos, recorda a vastidão da libertação e sua longa veneração aos tathāgatas. Sudhana então alcança a libertação da entrada em sons belos e manifestações profundas, além de samādhis, compreensão e discernimento. Louva a deusa, inclina-se, circunvaga-a muitas vezes e parte, voltando o olhar para ela repetidamente."
    speaker_066 "Procure Sarvavṛkṣpraphullanasukhasaṃvāsā e pergunte como treinar para conduzir todos os seres à onisciência."
    speaker_012 "Recebo sua orientação e louvo a amplitude da libertação que você me apresentou."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual dimensão dos ensinamentos de Sarvanagararakṣāsaṃbhavatejaḥśrī você gostaria de refletir antes de prosseguir?"
        "A amplitude do reino dos fenômenos":
            narrator "A deusa o contempla de dez maneiras, incluindo como ilimitado e indiviso."
        "O cuidado e a orientação dos seres":
            narrator "Ela descreve sua prática de conduzi-los rumo à iluminação e à onisciência."
        "A preservação do ensinamento":
            narrator "A narrativa recorda a manifestação de luz que prolongou o ensinamento por sessenta mil anos."
    call quiz_ch39
    menu:
        "Continuar — capítulo 40":
            jump chapter_40
        "Voltar ao índice":
            jump chapter_index

label quiz_ch39:
    centered "Qual é a libertação da deusa?"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito do capítulo."
    while True:
        menu:
            "Como se chama a libertação que Sarvanagararakṣāsaṃbhavatejaḥśrī diz ter alcançado?"
            "A entrada em sons belos e manifestações profundas":
                if 0 == 0:
                    narrator "Correto: esse é o nome da libertação apresentada pela deusa."
                    return
                else:
                    narrator "Revise o nome que a deusa dá à sua libertação e tente novamente."
            "A contemplação das dez direções do Monte Sumeru":
                if 1 == 0:
                    narrator "Correto: esse é o nome da libertação apresentada pela deusa."
                    return
                else:
                    narrator "Revise o nome que a deusa dá à sua libertação e tente novamente."
            "A reunião de todos os mundos numa única cidade":
                if 2 == 0:
                    narrator "Correto: esse é o nome da libertação apresentada pela deusa."
                    return
                else:
                    narrator "Revise o nome que a deusa dá à sua libertação e tente novamente."

label chapter_40:
    hide screen master_provisional_badge
    scene bg_ch40 with dissolve
    show master_ch40_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 40 — Sarvavṛkṣpraphullanasukhasaṃvāsā"
    centered "Cena 1 — O pedido de Sudhana"
    narrator "Prosseguindo sua contemplação da libertação ligada a sons belos e manifestações profundas, Sudhana chega à presença de Sarvavṛkṣpraphullanasukhasaṃvāsā. Ele se inclina aos pés da deusa e, com as mãos unidas, pede que ela explique como os bodhisattvas praticam e treinam sua conduta e como avançam rumo à onisciência. A deusa responde descrevendo sua atuação no mundo Sahā ao pôr do sol: seres de diferentes modos de vida retornam a seus lares, abrigos, florestas, águas ou terras de origem, buscando segurança e tranquilidade durante a noite."
    speaker_012 "Deusa, como devo compreender a prática que conduz a conduta do bodhisattva em direção à onisciência?"
    speaker_067 "Observa primeiro como os seres procuram abrigo e segurança; cuidar deles também integra o caminho que desejo te explicar."
    centered "Cena 2 — A alegria que reúne os seres"
    narrator "Sarvavṛkṣpraphullanasukhasaṃvāsā relata que conduz seres a raízes de mérito e a práticas adequadas: generosidade, conduta correta, amor, paciência, diligência, meditação, sabedoria e o caminho Mahāyāna. Ela chama sua libertação de “surgimento da vasta luz radiante da alegria”. Explica que a felicidade dos seres se relaciona ao mérito, às instruções e aos caminhos dos tathāgatas. A deusa alcançou essa libertação ao recordar e compreender o oceano da antiga conduta de Vairocana como bodhisattva: uma aspiração compassiva, sem apego a recompensas, voltada ao benefício de todos, em mundos e tempos incontáveis."
    speaker_012 "Essa alegria nasce de um resultado pessoal ou do benefício oferecido aos outros?"
    speaker_067 "A lembrança que compartilho aponta para a felicidade dos seres e para a prática que a favorece, não para uma recompensa isolada."
    centered "Cena 3 — O rei diante dos aflitos"
    narrator "A deusa descreve uma época de declínio em que ações nocivas, falta de chuva, colheitas perdidas e doenças trouxeram sofrimento. Pessoas famintas e sedentas cercaram a capital e clamaram por proteção ao rei Sarvadharmanirnādacchatramaṇḍalanirghoṣa. Ele foi tomado por grande compaixão e formulou aspirações para tornar-se refúgio, guia e fonte de sabedoria para os seres. Em seguida, anunciou que atenderia aos pedidos: depósitos, tesouros, alimentos, roupas, remédios, moradias e outros recursos foram disponibilizados. Sua generosidade foi descrita como abrangendo tudo o que possuía, sem excluir bens exteriores ou interiores."
    speaker_067 "Ao ouvir os aflitos, o rei voltou sua intenção para o alívio deles, sem pedir que retribuíssem sua bondade."
    speaker_068 "Que cada pessoa receba o necessário segundo seu pedido; quero que a generosidade alcance a todos igualmente."
    centered "Cena 4 — Ratnaprabhā reconhece o bom amigo espiritual"
    narrator "Ratnaprabhā, filha de um mercador-chefe, chega com sessenta jovens. Ela presta homenagem ao rei, mas não toma para si os bens oferecidos. Reconhecendo nele um bom amigo espiritual, um mestre compassivo e alguém que beneficia os outros, lança suas joias junto à plataforma do trono e aspira a tornar-se como ele e a renascer onde quer que ele renasça. O rei a encoraja a aceitar o que necessita; ela então o louva em versos, relacionando a generosidade dele à mudança nas condições dos seres. Ao final, ele lhe oferece uma joia preciosa e roupas preciosas para ela e seu grupo."
    speaker_069 "Não vim buscar riqueza para mim; diante deste exemplo, minha aspiração é aprender a beneficiar os seres."
    speaker_068 "Recebe estas vestes e a joia; reconheço tua aspiração e desejo que aceites o que te ofereço."
    centered "Cena 5 — A identidade revelada e o próximo encontro"
    narrator "Concluído o relato, a deusa revela a Sudhana que o rei era Vairocana, que Jyotiṣprabha e Padmaprabhā eram seus pais e que ela própria fora Ratnaprabhā. Os seres reunidos na antiga Jambudvīpa correspondem à assembleia atual, cujos integrantes avançam por diferentes bhūmis do caminho do bodhisattva. Em versos, ela expõe sua libertação: contempla budas em todas as direções, ouve os ensinamentos, compreende as mentes dos seres e recorda incontáveis kalpas e existências. Afirma não conhecer toda a conduta dos bodhisattvas e envia Sudhana a Sarvajagadrakṣāpraṇidhānavīryaprabhā, com perguntas sobre amadurecer seres, purificar terras búdicas, honrar os tathāgatas e dedicar-se ao Dharma."
    speaker_067 "Eu conheço esta libertação, não todo o alcance da conduta dos bodhisattvas. Outra mestra poderá responder às perguntas que te indico."
    speaker_012 "Levarei comigo as perguntas sobre beneficiar os seres, as terras búdicas e o Dharma dos budas."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do relato você gostaria de contemplar antes de prosseguir?"
        "A compaixão diante do sofrimento":
            narrator "A resposta do rei começa ao ouvir o clamor dos seres aflitos."
        "A generosidade sem expectativa de retorno":
            narrator "A deusa destaca a doação que busca satisfazer os seres sem exigir retribuição."
        "O reconhecimento de um bom amigo espiritual":
            narrator "Ratnaprabhā reconhece no rei um mestre e aspira a seguir seu caminho."
    call quiz_ch40
    menu:
        "Continuar — capítulo 41":
            jump chapter_41
        "Voltar ao índice":
            jump chapter_index

label quiz_ch40:
    centered "A libertação da deusa"
    narrator "Escolha a resposta que corresponde ao ensinamento explicitado no capítulo."
    while True:
        menu:
            "Como se chama a libertação que Sarvavṛkṣpraphullanasukhasaṃvāsā diz ter alcançado?"
            "O surgimento da vasta luz radiante da alegria":
                if 0 == 0:
                    narrator "Correto: esse é o nome da libertação que a deusa apresenta."
                    return
                else:
                    narrator "Relembre o nome que a deusa declara ao explicar sua libertação."
            "A entrada no oceano das terras búdicas":
                if 1 == 0:
                    narrator "Correto: esse é o nome da libertação que a deusa apresenta."
                    return
                else:
                    narrator "Relembre o nome que a deusa declara ao explicar sua libertação."
            "A pacificação dos sons da noite":
                if 2 == 0:
                    narrator "Correto: esse é o nome da libertação que a deusa apresenta."
                    return
                else:
                    narrator "Relembre o nome que a deusa declara ao explicar sua libertação."

label chapter_41:
    hide screen master_provisional_badge
    scene bg_ch41 with dissolve
    show master_ch41_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 41 — Sarvajagadrakṣāpraṇidhānavīryaprabhā"
    centered "Cena 1 — A visão da deusa noturna"
    narrator "Sudhana chega diante de Sarvajagadrakṣāpraṇidhānavīryaprabhā e a contempla no centro de seu séquito. O corpo da deusa, coberto por uma rede de jóias, manifesta imagens celestes e aparências percebidas de acordo com os seres; sua presença alcança os mundos e se volta a beneficiá-los. Depois de prostrar-se longamente, Sudhana obtém dez percepções puras, entre elas a aspiração diligente à onisciência, a prática das instruções dos tathāgatas e a intenção de completar raízes de mérito para atender aos seres. Essas percepções o aproximam dos kalyāṇamitras e de incontáveis qualidades da conduta bodhisattva. Ele louva a mestra e pergunta o nome de sua libertação."
    speaker_012 "Ao contemplar tua conduta, compreendo melhor a amplitude do caminho dos amigos espirituais."
    speaker_070 "A contemplação abriu em ti percepções que sustentam a aspiração e o benefício dos seres."
    centered "Cena 2 — A libertação que amadurece os seres"
    narrator "A deusa nomeia sua libertação como a origem das raízes de mérito que inspiram o amadurecimento de todos os seres. Compreendendo a natureza dos fenômenos como sem divisão e sem localização, ela manifesta corpos de incontáveis formas e cores. De cada manifestação surgem luzes, imagens de campos de budas e tathāgatas; por esses meios, inspira quem já possui raízes de mérito e leva outros a gerá-las, ampliá-las e torná-las vastas. Ela explica que a sabedoria bodhisattva não fixa o saṃsāra nem os éons como longos ou curtos; como o sol que parece refletido sem entrar nos objetos, os bodhisattvas aparecem entre os seres sem serem maculados por suas aflições."
    speaker_012 "Como se chama a libertação que orienta tuas manifestações para tantos seres?"
    speaker_070 "É a origem das raízes de mérito que inspiram o amadurecimento de todos os seres."
    speaker_070 "Aparecer no mundo não exige prender a sabedoria às medidas do tempo ou às aflições."
    centered "Cena 3 — O príncipe diante da prisão"
    narrator "Para responder sobre sua trajetória, a deusa recorda um passado remoto no mundo Ratnaprabhā, durante o éon Suprabha. Na capital Rativyūhā, o príncipe Vijitāvin ouve os gritos dos encarcerados por ordem do rei Jayaprabha. Ao vê-los na escuridão, presos e atormentados por fome, sede e sofrimento, sente grande compaixão e promete libertá-los. Pede ao rei que os solte, mas os quinhentos ministros aconselham a execução dos prisioneiros e apresentam a intervenção do príncipe como ameaça. Jayaprabha condena à morte o filho e os encarcerados. Mesmo diante da sentença, Vijitāvin não abandona sua intenção de assumir o sofrimento alheio."
    speaker_071 "Não consigo ignorar o sofrimento de quem está preso; peço que os libertem."
    speaker_072 "Os ministros dizem que tua intervenção ameaça a ordem do reino; abandona os condenados."
    speaker_071 "Se for preciso, aceito sofrer em lugar deles; não retiro meu pedido de libertação."
    centered "Cena 4 — Meio mês de generosidade"
    narrator "A mãe do príncipe suplica por sua vida e consegue para ele meio mês de atos de generosidade antes da execução. No parque Sūryaprabha, Vijitāvin oferece sem restrição o que lhe pedem: alimentos, bebidas, vestes, animais, flores, objetos preciosos e outras necessidades. No último dia, reúne-se uma grande assembleia. O Buda Dharmacakranirghoṣagaganameghapradīparāja também chega, acompanhado por seres celestiais e outros grupos, pois era o momento de conduzir e amadurecer os presentes. Vijitāvin e a assembleia o recebem com reverência. O príncipe prepara um assento para o Buda; ao vê-lo, os presentes tornam-se aptos a receber o Dharma."
    speaker_073 "Conceda ao príncipe meio mês para dar o que lhe pedirem; depois, decida como quiser."
    speaker_071 "Que cada pessoa receba aquilo de que necessita; nada reservo desta distribuição."
    speaker_071 "Bem-vindo, Bhagavat. Este assento foi preparado para tua chegada."
    centered "Cena 5 — O ensinamento e a revelação da mestra"
    narrator "O Buda ensina gradualmente o sūtra A Iluminação do Campo das Causas, usando as línguas, definições e sons dos seres. Muitos ouvintes são conduzidos: alguns alcançam a visão do Dharma, outros o estado além do treinamento, e dez mil entram no Mahāyāna. Vijitāvin também alcança a libertação descrita pela deusa. Ela revela a Sudhana que foi aquele príncipe; os quinhentos ministros, os prisioneiros, o rei e sua corte correspondem a seres de outros contextos, entre eles futuros budas e praticantes que receberam profecias. O relato não transforma o passado em motivo de recompensa pessoal: a mestra destaca a compaixão e o empenho em beneficiar os seres."
    speaker_070 "Naquela vida, fui Vijitāvin; a compaixão pelos encarcerados orientou minha ação."
    speaker_012 "A libertação que explicas nasceu junto à decisão de não abandonar aqueles seres."
    centered "Cena 6 — Renúncia, cultivo e oferendas aos budas"
    narrator "Depois de libertar os prisioneiros e honrar o Buda, Vijitāvin recebe permissão dos pais para renunciar à vida principesca e tornar-se mendicante sob Dharmacakranirghoṣagaganameghapradīparāja. Mantém o celibato por cinco mil anos e cultiva samādhis, retenções mentais, discernimentos, conhecimento e preces bodhisattvas. Em vidas posteriores, assume diversas posições e formas de existência, sempre honrando tathāgatas. No éon Suprabha, presta homenagem a seiscentos milhões de budas; em incontáveis éons, ouve, conserva e serve os ensinamentos recebidos. A deusa associa essa continuidade ao amadurecimento de seres e à obtenção de diversas entradas na libertação, sem reduzir sua prática a um único encontro."
    speaker_070 "Após a renúncia, continuei a honrar os tathāgatas e a receber seus ensinamentos."
    speaker_012 "A prática se estende por muitas vidas, preservando o compromisso de amadurecer os seres."
    centered "Cena 7 — Formas hábeis e o próximo guia"
    narrator "Em seus versos finais, a deusa descreve corpos e manifestações sem limite, luzes que alcançam os mundos e ensinamentos apresentados conforme as aspirações dos seres; essa é a libertação que conhece, não a totalidade das qualidades de todos os grandes bodhisattvas. Então encaminha Sudhana à deusa Sutejomaṇḍalaratiśrī, na Floresta de Lumbinī, em Jambudvīpa, para perguntar como os bodhisattvas nascem na família dos tathāgatas, aparecem no mundo e praticam incansavelmente até os últimos éons futuros. Sudhana reverencia a mestra, circum-ambula-a muitas centenas de milhares de vezes, mantendo-a à sua direita, e parte olhando para trás com as mãos unidas."
    speaker_070 "Procura Sutejomaṇḍalaratiśrī na Floresta de Lumbinī e pergunta sobre o nascimento e a prática dos bodhisattvas."
    speaker_012 "Parto levando comigo estas perguntas e a orientação recebida."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Que aspecto do ensinamento da deusa você gostaria de refletir antes de seguir?"
        "A compaixão que move Vijitāvin":
            narrator "A compaixão orienta o príncipe a agir em favor dos prisioneiros."
        "A sabedoria que não fixa os éons":
            narrator "A deusa explica que a sabedoria bodhisattva não concebe os éons como longos ou curtos."
        "As manifestações conforme as aspirações":
            narrator "A deusa ensina que suas formas e cores podem conduzir seres segundo suas disposições."
    call quiz_ch41
    menu:
        "Continuar — capítulo 42":
            jump chapter_42
        "Voltar ao índice":
            jump chapter_index

label quiz_ch41:
    centered "Reconheça a libertação"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito da deusa."
    while True:
        menu:
            "Qual é o nome da libertação que Sarvajagadrakṣāpraṇidhānavīryaprabhā ensina a Sudhana?"
            "A origem das raízes de mérito que inspiram o amadurecimento de todos os seres":
                if 0 == 0:
                    narrator "Correto: esse é o nome que a deusa dá à sua libertação."
                    return
                else:
                    narrator "Relembre o nome dado pela deusa à libertação ligada ao amadurecimento dos seres."
            "A libertação que mede os éons como longos ou curtos":
                if 1 == 0:
                    narrator "Correto: esse é o nome que a deusa dá à sua libertação."
                    return
                else:
                    narrator "Relembre o nome dado pela deusa à libertação ligada ao amadurecimento dos seres."
            "A libertação que abandona a prática para permanecer fora dos mundos":
                if 2 == 0:
                    narrator "Correto: esse é o nome que a deusa dá à sua libertação."
                    return
                else:
                    narrator "Relembre o nome dado pela deusa à libertação ligada ao amadurecimento dos seres."

label chapter_42:
    hide screen master_provisional_badge
    scene bg_ch42 with dissolve
    show master_ch42_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 42 — Sutejomaṇḍalaratiśrī"
    centered "Cena 1 — A mestra no Bosque de Lumbinī"
    narrator "Depois de recordar a instrução recebida da deusa noturna Sarvajagadrakṣāpraṇidhānavīryaprabhā e de meditar sobre a libertação que ela lhe ensinara, Sudhana chega ao Bosque de Lumbinī. Ele o circunda mantendo-o à direita e procura Sutejomaṇḍalaratiśrī. Encontra-a ensinando o Dharma a uma assembleia de duzentas mil trilhões de deusas da floresta. A lição em curso é o ensinamento sobre o oceano de vidas dos bodhisattvas, que faz crescer as qualidades dos que nasceram na família dos tathāgatas. Sudhana se aproxima, reverencia os pés da mestra e, de mãos postas, pergunta como os bodhisattvas nascem nessa família e iluminam os seres ao praticarem sua conduta."
    speaker_012 "Mestra, despertei a aspiração à iluminação completa. Como compreender o nascimento na família dos tathāgatas e a prática que ilumina os seres?"
    speaker_074 "Escuta, nobre viajante: explicarei os dez nascimentos que dão forma a essa trajetória dos bodhisattvas."
    centered "Cena 2 — Dez nascimentos na família dos tathāgatas"
    narrator "Sutejomaṇḍalaratiśrī apresenta dez essências: dedicação ao serviço de todos os budas; origem dos aspectos da aspiração à iluminação; certeza nos caminhos do Dharma; motivação superior e pura que ilumina os três tempos; luz que tudo ilumina; origem da linhagem dos tathāgatas; luz que adorna e ilumina as forças dos budas; análise completa das entradas do conhecimento; manifestação de emanações pelo reino dos fenômenos; e poder de ascender ao nível dos tathāgatas. A primeira amadurece com serviço e oferendas aos budas; a segunda envolve compaixão, amor e compromisso de não abandonar os seres. As demais reúnem compreensão do Dharma, firmeza, perfeições, sabedoria, samādhis e meios hábeis. Em conjunto, sustentam a prática sem retrocesso e a orientação dos seres rumo à onisciência."
    speaker_012 "Os dez nomes mostram uma progressão: da dedicação inicial até a capacidade de manifestação e ensino?"
    speaker_074 "Sim; cada nascimento reúne qualidades para completar a via e amadurecer os seres, sem abandonar a aspiração à onisciência."
    centered "Cena 3 — Os sinais e as manifestações do nascimento"
    narrator "Para explicar sua libertação, a deusa recorda primeiro os dez presságios do tempo em que Vairocana desceu de Tuṣita: o bosque se tornou plano, adornado com chão de diamante, árvores preciosas, flores e oferendas, enquanto seres celestiais se reuniam e raios de luz chegavam dos tathāgatas. Quando Māyādevī veio de Kapilavastu, outros sinais luminosos anunciaram o nascimento. Seguiram-se dez manifestações: luz que emanava de Māyādevī; mundos vistos em seu corpo; budas passados e seus ensinamentos nos poros; reinos e vidas de Vairocana; suas antigas formas e atos de generosidade; adornos e prazeres de mundos búdicos; bodhisattvas semelhantes a Vairocana; e, por fim, um lótus imenso feito de joias. Então o bodhisattva nasceu, descrito como reflexo, sonho e aparição sem vir ou partir."
    speaker_012 "As manifestações tornam visíveis muitos mundos e vidas no próprio cenário do nascimento."
    speaker_074 "Assim as percebo: o nascimento e suas manifestações não se limitam a uma única escala de mundos."
    centered "Cena 4 — A enfermeira de um buda remoto"
    narrator "A deusa conta que, em um passado remoto, no mundo Samantaratnā, a rainha Suharṣitaprabheśvarā deu à luz o príncipe Īśvaraguṇāparājitadhvaja no parque Suvarṇapuṣpābhamaṇḍala, dentro de um pavilhão. Sutejomaṇḍalaratiśrī revela a Sudhana que naquela existência era Vimalasaṃbhavaprabhā, a enfermeira presente ao nascimento. Quando os governantes do mundo colocaram o recém-nascido em seu colo, ela alcançou grande alegria e fé, obteve o samādhi chamado “visão de tudo” e contemplou tathāgatas nos mundos das dez direções. Entrou então, como quem ingressa numa matriz de consciência, na libertação das manifestações dos nascimentos dos bodhisattvas e fez a grande aspiração de contemplar os nascimentos de todos os tathāgatas. Māyādevī era aquela rainha, e Śuddhodana, o rei Ratnārcinetraprabha."
    speaker_012 "Foi ao receber o recém-nascido que a senhora alcançou essa visão e fez sua grande aspiração?"
    speaker_074 "Foi então que alcancei o samādhi e entrei nesta libertação; desde aquele tempo contemplo esses oceanos de manifestações."
    centered "Cena 5 — Uma visão sem fim e o próximo mestre"
    narrator "A deusa descreve como contempla, em cada instante e através dos átomos dos mundos, oceanos de reinos, budas e manifestações de nascimento; também lhes faz oferendas, ouve seus ensinamentos e pratica o Dharma. Seus versos recordam a aspiração que surgiu ao ver o buda remoto e a visão de nascimentos, ensinamentos e liberações em incontáveis mundos. Ainda assim, ela afirma conhecer apenas essa libertação e não poder expor por completo as qualidades ou a conduta de todos os bodhisattvas. Em seguida, orienta Sudhana a ir à grande cidade de Kapilavastu e procurar a jovem Śākya chamada Gopā, a quem deverá perguntar como um bodhisattva continua no saṃsāra para amadurecer os seres. Sudhana se inclina, circunda a mestra muitas vezes mantendo-a à direita, olha para trás de mãos postas e parte."
    speaker_012 "Levarei comigo esta instrução e seguirei até Kapilavastu para encontrar Gopā."
    speaker_074 "Pergunta-lhe como um bodhisattva continua no saṃsāra a fim de amadurecer os seres."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto das dez essências dos nascimentos dos bodhisattvas você gostaria de contemplar primeiro?"
        "A dedicação a servir todos os budas":
            narrator "A primeira essência é a dedicação a servir e fazer oferendas aos budas."
        "A compaixão e o compromisso com os seres":
            narrator "A aspiração à iluminação inclui proteger e não abandonar os seres."
        "A análise dos caminhos do conhecimento":
            narrator "A oitava essência é a análise completa das entradas do conhecimento."
    call quiz_ch42
    menu:
        "Continuar — capítulo 43":
            jump chapter_43
        "Voltar ao índice":
            jump chapter_index

label quiz_ch42:
    centered "Identifique a sexta essência"
    narrator "Escolha a resposta correta; este menu é um minijogo opcional e não canônico."
    while True:
        menu:
            "Como Sutejomaṇḍalaratiśrī denomina o sexto nascimento de um bodhisattva?"
            "A essência da luz que tudo ilumina":
                if 0 == 1:
                    narrator "Correto: o sexto nascimento é a origem da linhagem da família dos tathāgatas."
                    return
                else:
                    narrator "Releia a lista das dez essências: o sexto diz respeito à linhagem dos tathāgatas."
            "A essência da origem da linhagem da família dos tathāgatas":
                if 1 == 1:
                    narrator "Correto: o sexto nascimento é a origem da linhagem da família dos tathāgatas."
                    return
                else:
                    narrator "Releia a lista das dez essências: o sexto diz respeito à linhagem dos tathāgatas."
            "A essência da manifestação de emanações pelo reino dos fenômenos":
                if 2 == 1:
                    narrator "Correto: o sexto nascimento é a origem da linhagem da família dos tathāgatas."
                    return
                else:
                    narrator "Releia a lista das dez essências: o sexto diz respeito à linhagem dos tathāgatas."

label chapter_43:
    hide screen master_provisional_badge
    scene bg_ch43 with dissolve
    centered "Capítulo 43 — Gopā"
    centered "Cena 1 — Acolhida em Kapilavastu"
    narrator "Depois de deixar Sutejomaṇḍalaratiśrī, a deusa da floresta de Lumbinī, Sudhana segue para Kapilavastu enquanto contempla a libertação ligada às manifestações do nascimento dos bodhisattvas. No salão Luz Iluminadora do Reino do Dharma, Aśokaśrī o recebe com dez mil deusas domésticas e o saúda como alguém dedicado a encontrar bons amigos espirituais e a beneficiar os seres. Sudhana responde que sua maior alegria está em aliviar aflições e carmas nocivos. Compara a dor do bodhisattva diante do sofrimento dos seres à de um pai amoroso que vê o filho sofrer; por isso, a felicidade e as ações virtuosas dos seres também são motivo de alegria."
    speaker_075 "Sua chegada revela uma busca firme: aprender com os bons amigos e conduzir os seres sem se cansar."
    speaker_012 "O sofrimento dos seres não me é indiferente; desejo que encontrem causas de felicidade e abandonem as aflições."
    centered "Cena 2 — O encontro com Gopā"
    narrator "Após entrar no salão à procura da jovem Śākya Gopā, Sudhana a encontra no centro, num trono precioso, rodeada por uma assembleia de mulheres cujas virtudes e práticas passadas são descritas. Ele se inclina diante dela e expõe suas dúvidas: como agir no saṃsāra sem ser contaminado por ele, compreender a igualdade dos fenômenos sem abandonar a atividade compassiva, conhecer o Dharma sem deixar de ensiná-lo e perceber que os seres não têm existência própria sem renunciar a guiá-los? Gopā acolhe as perguntas como expressão de uma aspiração correta e pede que ele escute com atenção o ensinamento que oferecerá pela bênção dos budas."
    speaker_012 "Como posso compreender a igualdade dos fenômenos e ainda assim permanecer junto aos seres para ajudá-los?"
    speaker_076 "Perguntar como sabedoria e atividade se acompanham já aponta para a prática que você procura. Escute com atenção."
    centered "Cena 3 — As qualidades da prática e a visão de Gopā"
    narrator "Gopā enumera dez qualidades que sustentam a conduta dos bodhisattvas: confiar em bons amigos espirituais, desenvolver aspiração vasta e motivação pura, reunir mérito e sabedoria, ouvir ensinamentos, voltar-se aos tathāgatas dos três tempos, compreender a igualdade dos campos de prática, receber a bênção dos budas, cultivar grande compaixão e interromper a continuidade do saṃsāra. Também ensina dez modos de servir e agradar aos bons amigos, entre eles não se apegar à própria vida ou aos bens do saṃsāra, manter aspiração irrevogável à onisciência e purificar a percepção. Sua libertação permite conhecer os seres, seus carmas, os budas e as vastas sucessões de kalpas e mundos."
    speaker_076 "A prática se apoia em aspiração ampla, compaixão e sabedoria, amadurecidas sem recuar diante do caminho longo."
    speaker_012 "Então servir a um bom amigo não é buscar recompensa, mas transformar a própria conduta em benefício duradouro."
    centered "Cena 4 — Tejodhipati e a jovem nascida do lótus"
    narrator "Gopā recua a um passado remoto: em Drumameruśrī, o rei Dhanapati tem como filho Tejodhipati, príncipe dotado dos 32 sinais de um grande ser. Em outra parte da mesma narrativa, Sudarśanā recorda que sua filha Sucalitaratiprabhāsaśrī nasceu de um lótus precioso num lago, ao fim da noite, acompanhada por luz e sons auspiciosos. Quando o príncipe vai ao parque Gandhāṅkuraprabhamegha, a jovem o vê e se sente atraída. Um sonho lhe revela o buda Sūryagātrapravara, recentemente desperto; ao ouvir sobre ele e contemplar suas qualidades, ela encontra serenidade. Tejodhipati declara que sua meta é a iluminação e que praticará generosidade e as demais perfeições por incontáveis eras."
    speaker_077 "Minha filha veio ao mundo dentro de um lótus; sua história começou entre sinais extraordinários."
    speaker_078 "Meu compromisso é com a iluminação de todos. O caminho exigirá prática contínua e generosidade sem medida."
    centered "Cena 5 — O encontro com Sūryagātrapravara"
    narrator "Sucalitaratiprabhāsaśrī aceita acompanhar Tejodhipati e declara que deseja praticar a mesma conduta, não obter riqueza ou prazer. Juntos vão ao bodhimaṇḍa e fazem oferendas ao tathāgata Sūryagātrapravara. O buda ensina o sūtra A Lâmpada para Ver Todas as Entradas; Tejodhipati alcança oceanos de samādhis, e Sucalita obtém uma realização que a torna irreversível rumo à iluminação. Tejodhipati retorna à capital, informa o pai sobre o buda e Dhanapati entrega-lhe o reino antes de renunciar. Gopā revela as identidades daquela vida: Tejodhipati era Śākyamuni, Sucalita era ela própria, Dhanapati era Ratnakusumaprabha, e a rainha Padmaśrīgarbhasaṃbhavā era Māyādevī."
    speaker_079 "Quero acompanhar sua prática e permanecer dedicada ao caminho, não às posses que ele possa trazer."
    speaker_012 "As identidades que você revela ligam aquela história a esta assembleia de um modo inesperado."
    centered "Cena 6 — Vidas de serviço e a vastidão dos mundos"
    narrator "Gopā conta que ela e Tejodhipati serviram Sūryagātrapravara e, depois, muitos outros tathāgatas. Na época do buda Vipuladharmādhimuktisaṃbhavatejas, ela ouviu o ensinamento A Lâmpada do Surgimento dos Nascimentos de Todos os Tathāgatas, alcançou os olhos da sabedoria e sua libertação. Ao repousar nessa visão, percebia em cada poro do bodhisattva vastos conjuntos de mundos, budas, assembleias, ensinamentos, seres e caminhos de prática, sem começo nem meio. Seres atraídos pela conduta do bodhisattva podiam tornar-se seguidores e avançar irreversivelmente. Ainda assim, Gopā ressalva que conhece apenas essa libertação e não consegue abarcar toda a conduta dos bodhisattvas perfeitamente bons, cuja medida é como o espaço e a percepção dos tathāgatas."
    speaker_076 "Minha visão alcança oceanos de mundos e práticas, mas não esgota o campo inteiro da conduta perfeitamente boa."
    speaker_012 "Reconhecer o limite do que se conhece também me mostra quanto ainda há para aprender."
    centered "Cena 7 — Bhānuprabhā e a oferenda a Suraśmi"
    narrator "Em outro relato de vidas remotas, Gopā recorda o kalpa Vyūhasa e o mundo Meruprabhā, onde surgiram sessenta sextilhões de sábios; o último foi Dharmadhvaja. O príncipe Suraśmi abandona o reino, torna-se mendicante e ensina o Dharma. Gopā, então Bhānuprabhā, filha do mercador Suvighuṣṭakīrti, sente atração ao vê-lo e oferece uma joia em sua tigela de esmolas e suas próprias joias. Ela explica que essa oferenda, embora motivada pela paixão, a protegeu de renascer nos estados inferiores por 250 kalpas; depois, em outras vidas, encontrou o príncipe Tejodhipati, fez oferendas com ele a Sūryagātrapravara e desenvolveu a aspiração à iluminação. Após venerar incontáveis budas, alcançou olhos puros do Dharma e iluminação."
    speaker_076 "Mesmo uma oferenda nascida de uma motivação imperfeita teve consequências descritas em meu percurso; depois, continuei encontrando os budas."
    speaker_012 "Sua lembrança percorre muitas vidas, mas você também distingue a motivação que acompanhou cada ato."
    centered "Cena 8 — A próxima mestra e a despedida"
    narrator "Ao concluir, Gopā descreve sua visão de incontáveis budas, terras puras e impuras, samādhis, libertações e orações, sem apego ou aversão às diferentes terras. Ela recorda que, mesmo contemplando por eras as manifestações que surgiam nos poros do bodhisattva, não podia compreender toda a extensão de suas ações de corpo, fala e mente. Então orienta Sudhana a procurar Māyādevī, mãe do bodhisattva, junto aos pés de Vairocana. Propõe perguntas sobre como os bodhisattvas permanecem sem máculas, fazem oferendas continuamente, percebem os tathāgatas e não desistem de reunir os seres. Sudhana se inclina, circunda Gopā muitas vezes e parte, olhando para trás repetidamente."
    speaker_076 "Procure Māyādevī e pergunte como a prática permanece sem mácula e sem esmorecer no cuidado de todos os seres."
    speaker_012 "Parto com respeito e levarei comigo as perguntas que você me confiou."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o ensinamento de Gopā, qual aspecto da prática você gostaria de examinar primeiro?"
        "A confiança em bons amigos espirituais":
            narrator "Uma reflexão sobre a importância de aprender com quem orienta a prática."
        "A compaixão que não abandona os seres":
            narrator "Uma reflexão sobre permanecer dedicado ao bem-estar dos seres."
        "A sabedoria que reconhece a igualdade dos fenômenos":
            narrator "Uma reflexão sobre compreender sem se afastar da atividade no mundo."
    call quiz_ch43
    menu:
        "Continuar — capítulo 44":
            jump chapter_44
        "Voltar ao índice":
            jump chapter_index

label quiz_ch43:
    centered "As dez qualidades"
    narrator "Escolha a opção que corresponde a uma das dez qualidades dos bodhisattvas ensinadas por Gopā. Este menu é não canônico."
    while True:
        menu:
            "Qual qualidade aparece explicitamente na lista de Gopā?"
            "Buscar os prazeres do saṃsāra como finalidade da onisciência.":
                if 0 == 1:
                    narrator "Correto: a confiança em bons amigos espirituais integra a lista de dez qualidades."
                    return
                else:
                    narrator "Revise a lista de Gopā: ela começa pela confiança em bons amigos espirituais."
            "Confiar em bons amigos espirituais.":
                if 1 == 1:
                    narrator "Correto: a confiança em bons amigos espirituais integra a lista de dez qualidades."
                    return
                else:
                    narrator "Revise a lista de Gopā: ela começa pela confiança em bons amigos espirituais."
            "Abandonar a compaixão para alcançar a igualdade dos fenômenos.":
                if 2 == 1:
                    narrator "Correto: a confiança em bons amigos espirituais integra a lista de dez qualidades."
                    return
                else:
                    narrator "Revise a lista de Gopā: ela começa pela confiança em bons amigos espirituais."

label chapter_44:
    hide screen master_provisional_badge
    scene bg_ch44 with dissolve
    show master_ch44_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 44 — Māyādevī"
    centered "Cena 1 — A cidade da mente"
    narrator "A caminho de Māyādevī, Sudhana reflete sobre como encontrar, honrar e aprender com os bons amigos espirituais. Ratnanetrā, deusa da cidade, surge no céu cercada por deusas, adornada e espalhando flores divinas. Ela transforma a mente em uma cidade a ser cuidada: protegida contra o apego ao saṃsāra, purificada da inveja e da ganância, pacificada pela compreensão dos fenômenos e fortalecida pela dedicação à onisciência. Também associa essa cidade ao amor por todos os seres, à grande compaixão, à sabedoria, às preces dos bodhisattvas e à generosidade. A deusa explica que remover obscuridades facilita ver os budas, ouvir o Dharma e encontrar bons amigos espirituais, dos quais depende a onisciência do bodhisattva."
    speaker_012 "Quero aprender a reconhecer e acompanhar aqueles que me conduzem ao Dharma."
    speaker_080 "Cuida da cidade da mente com sabedoria e compaixão; assim, a busca por bons amigos não fica encoberta."
    centered "Cena 2 — Luz, qualidades e samādhis"
    narrator "Duas deusas, Dharmapadmaśrīkuśalā e Hrīśrīmañjariprabhāvā, surgem do bodhimaṇḍa e louvam Māyādevī. Raios emanados de suas joias alcançam Sudhana; ele obtém diversas visões, entre elas a natureza dos seres e dos fenômenos, os corpos do Dharma dos tathāgatas e os mundos búdicos. Em seguida, Sunetra, líder dos rākṣasas e guardião da sala dos bodhisattvas, descreve dez qualidades que aproximam o bodhisattva dos bons amigos: motivação pura, compaixão sem discriminação, aspiração à onisciência e sabedoria, entre outras. Também apresenta dez portas de samādhi. Sudhana pergunta como e onde buscar os mestres. Sunetra orienta-o a ir com a mente voltada à lembrança deles, sem se limitar a um modo ordinário de deslocamento."
    speaker_081 "Aproxima-te dos mestres com motivação pura, compaixão e aspiração firme à onisciência."
    speaker_012 "Como devo me aplicar a encontrá-los e para onde devo dirigir minha busca?"
    speaker_081 "Segue com a lembrança dos bons amigos como foco e com a mente aberta ao samādhi que alcança todos os lugares."
    centered "Cena 3 — O lótus e a forma de Māyādevī"
    narrator "Praticando conforme a instrução de Sunetra, Sudhana vê diante de si um grande lótus de joias. Sobre ele se ergue um edifício resplandecente, com pilares, adornos preciosos e um trono central. Māyādevī está sentada ali. Sua forma, explica a narrativa, transcende os três mundos e pode ser percebida de acordo com as aspirações dos seres, sem nascer nem desaparecer em um mundo. É comparada a reflexo, sonho, miragem e ilusão, embora aja para guiar os seres e surja da grande compaixão. Conforme as aspirações, ela pode manifestar formas diversas; Sudhana reconhece nela mérito, generosidade, paciência, diligência, sabedoria e dedicação ao amadurecimento dos seres. Ele se prostra e alcança muitas entradas em samādhi antes de dirigir-se a ela."
    speaker_012 "Vejo uma forma que se apresenta de muitos modos, sem se prender a uma existência comum."
    speaker_082 "Minha forma é percebida conforme as aspirações dos seres e se manifesta para orientá-los."
    centered "Cena 4 — A liberação das grandes preces"
    narrator "Após homenageá-la, Sudhana pergunta como um bodhisattva treina sua conduta e alcança a onisciência. Māyādevī responde que realizou a liberação chamada conjurações ilusórias da sabedoria das grandes preces. Por meio dela, tornou-se mãe dos bodhisattvas em suas existências finais, inclusive das manifestações de Vairocana: eles habitam seu ventre e saem pelo lado direito. Ela conta que, quando o bodhisattva deixou Tuṣita, raios de luz entraram em seu corpo e lhe revelaram nascimentos, residências, comitivas e atividades de incontáveis bodhisattvas. Seu ventre continha essas manifestações e visitantes de muitos mundos, embora seu corpo continuasse com aparência humana. Māyādevī diz que sua forma não é nem dual nem não dual, nem singular nem múltipla, e que foi mãe de tathāgatas passados e será de futuros."
    speaker_012 "Como se treina a conduta do bodhisattva e se realiza a onisciência?"
    speaker_082 "Conheço a liberação das conjurações ilusórias da sabedoria das grandes preces; por ela, manifestações incontáveis podem ser acolhidas sem alterar a aparência humana do corpo."
    centered "Cena 5 — Uma prece antiga e o próximo mestre"
    narrator "Para explicar quando obteve sua liberação, Māyādevī recorda o kalpa Śubhaprabha. No bodhimaṇḍa Citramañjariprabhāsa, a deusa Netraśrī viu o rei cakravartin Mahātejaḥparākrama como filho; depois que ele dispersou o exército de Māra e o Tathāgata Vimaladhvaja alcançou a iluminação, Netraśrī fez a prece de ser mãe dele em renascimentos futuros. Māyādevī revela que ela era Netraśrī, e que Mahātejaḥparākrama era Vairocana. Desde então, afirma, foi mãe dele em suas vidas. Ela diz conhecer apenas essa liberação, sem poder descrever todas as qualidades dos bodhisattvas. Então envia Sudhana a Surendrābhā, filha do deva Smṛtimat, no paraíso de Trāyastriṃśa, para perguntar sobre a conduta do bodhisattva. Sudhana a homenageia e parte."
    speaker_082 "A antiga prece de Netraśrī expressou o desejo de ser mãe do rei que alcançaria a iluminação."
    speaker_012 "Receberei a orientação de Surendrābhā sobre a prática da conduta do bodhisattva."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre a busca de Sudhana, que aspecto você escolheria levar consigo? A escolha é apenas reflexiva e não altera a narrativa."
        "A compaixão sem discriminação":
            narrator "Uma reflexão alinhada à ênfase de Ratnanetrā e Sunetra no cuidado de todos os seres."
        "A mente purificada de obscuridades":
            narrator "Uma reflexão ligada ao ensinamento sobre ver os budas e encontrar bons amigos espirituais."
        "A dedicação à sabedoria e às preces":
            narrator "Uma reflexão sobre as qualidades e práticas apresentadas neste capítulo."
    call quiz_ch44
    menu:
        "Continuar — capítulo 45":
            jump chapter_45
        "Voltar ao índice":
            jump chapter_index

label quiz_ch44:
    centered "Reconheça a liberação"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito de Māyādevī."
    while True:
        menu:
            "Qual liberação Māyādevī diz ter alcançado?"
            "A liberação das conjurações ilusórias da sabedoria das grandes preces":
                if 0 == 0:
                    narrator "Correto: esse é o nome da liberação que Māyādevī declara conhecer."
                    return
                else:
                    narrator "Releia a resposta de Māyādevī: o capítulo nomeia a liberação das conjurações ilusórias da sabedoria das grandes preces."
            "A liberação da cidade da mente sem obscurações":
                if 1 == 0:
                    narrator "Correto: esse é o nome da liberação que Māyādevī declara conhecer."
                    return
                else:
                    narrator "Releia a resposta de Māyādevī: o capítulo nomeia a liberação das conjurações ilusórias da sabedoria das grandes preces."
            "A liberação do samādhi das dez portas da visão":
                if 2 == 0:
                    narrator "Correto: esse é o nome da liberação que Māyādevī declara conhecer."
                    return
                else:
                    narrator "Releia a resposta de Māyādevī: o capítulo nomeia a liberação das conjurações ilusórias da sabedoria das grandes preces."

label chapter_45:
    hide screen master_provisional_badge
    scene bg_ch45 with dissolve
    show master_ch45_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 45 — Surendrābhā"
    centered "Cena 1 — A pergunta de Sudhana"
    narrator "Sudhana vai ao paraíso do senhor de Trāyastriṃśa e se aproxima de Surendrābhā, filha do deva Smṛtimat. Em sinal de homenagem, inclina a cabeça aos pés dela, dá muitas centenas de milhares de voltas mantendo-a à sua direita e então permanece diante dela com as palmas unidas. Sudhana declara que despertou a aspiração pela iluminação completa e suprema, mas não sabe como os bodhisattvas devem se treinar na conduta de bodhisattva nem como devem praticá-la. Tendo ouvido que Surendrābhā ensina bodhisattvas, pede que ela explique o caminho do treinamento e da prática."
    speaker_012 "Despertei a aspiração à iluminação suprema, mas ainda busco compreender como treinar e praticar a conduta de bodhisattva."
    speaker_083 "Posso compartilhar contigo a liberação que alcancei e o que ela me permite recordar."
    centered "Cena 2 — Memória através dos kalpas"
    narrator "Surendrābhā nomeia sua realização: a liberação do bodhisattva chamada manifestação da memória pura e sem impedimentos. Ela recorda o kalpa Utpala, quando serviu tantos tathāgatas quantos grãos de areia há no Ganges; quando eles partiram, protegeu-os, fez oferendas e lhes deu parques para desfrutar. Recorda também suas trajetórias: o tempo como bodhisattvas, no ventre materno, o nascimento, os sete primeiros passos, o rugido do leão, a juventude, os haréns, a partida para a vida sem lar, a iluminação, o giro da roda do Dharma e as manifestações milagrosas, até amadurecerem e guiarem seres e proferirem o ensinamento final. Em outros kalpas, serviu quantidades igualmente vastas de tathāgatas."
    speaker_083 "Minha realização é a manifestação da memória pura e sem impedimentos."
    speaker_012 "Essa memória abrange os percursos dos tathāgatas ao longo de muitos kalpas."
    centered "Cena 3 — O próximo mestre"
    narrator "A enumeração segue em ordem: no kalpa Subhūti, Surendrābhā serviu tathāgatas em número igual aos grãos de areia de dez rios Ganges; em Subhaga, tantos quantos átomos num reino de buda; em Anilambha, 84 × 100 mil quintilhões; em Suprabha, tantos quantos átomos em Jambudvīpa; em Atulaprabha, tantos quantos grãos de areia em vinte rios Ganges; em Uttaptaśrī, tantos quantos grãos em um; em Sūryodaya, em oitenta; em Jayaṃgama, em sessenta; e em Sucandra, em setenta. Ela diz ter ouvido e retido essa liberação dos tathāgatas ao longo de kalpas incontáveis e reconhece que conhece apenas essa realização. Então indica Viśvāmitra, mestre de crianças na grande cidade de Kapilavastu. Sudhana, alegre, presta homenagem, dá voltas ao redor dela e parte, olhando para trás repetidamente."
    speaker_083 "Conheço esta liberação, mas não sei descrever as qualidades dos bodhisattvas livres das obscuridades e das limitações que mencionei."
    speaker_083 "Segue para a grande cidade de Kapilavastu e pergunta a Viśvāmitra, mestre de crianças, como treinar e praticar a conduta de bodhisattva."
    speaker_012 "Recebo tua orientação com alegria e seguirei ao encontro do mestre indicado."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Pausa reflexiva opcional: qual aspecto do ensinamento de Surendrābhā você destacaria?"
        "A memória que acompanha os tathāgatas por suas trajetórias":
            narrator "Uma reflexão sobre recordar os percursos e ensinamentos dos tathāgatas."
        "O reconhecimento dos limites do próprio conhecimento":
            narrator "Uma reflexão sobre nomear com clareza aquilo que se conhece."
        "A indicação de outro mestre a Sudhana":
            narrator "Uma reflexão sobre a orientação recebida para prosseguir a busca."
    call quiz_ch45
    menu:
        "Continuar — capítulo 46":
            jump chapter_46
        "Voltar ao índice":
            jump chapter_index

label quiz_ch45:
    centered "Reconheça a liberação"
    narrator "Escolha a resposta correta com base no ensinamento apresentado."
    while True:
        menu:
            "Qual liberação Surendrābhā afirma ter alcançado?"
            "A manifestação da memória pura e sem impedimentos":
                if 0 == 0:
                    narrator "Correto: essa é a liberação que Surendrābhā diz conhecer."
                    return
                else:
                    narrator "Releia a passagem em que Surendrābhā nomeia sua realização."
            "A purificação das dez forças puras":
                if 1 == 0:
                    narrator "Correto: essa é a liberação que Surendrābhā diz conhecer."
                    return
                else:
                    narrator "Releia a passagem em que Surendrābhā nomeia sua realização."
            "A libertação da vida sem lar":
                if 2 == 0:
                    narrator "Correto: essa é a liberação que Surendrābhā diz conhecer."
                    return
                else:
                    narrator "Releia a passagem em que Surendrābhā nomeia sua realização."

label chapter_46:
    hide screen master_provisional_badge
    scene bg_ch46 with dissolve
    show master_ch46_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 46 — Viśvāmitra"
    centered "Cena 1 — A pergunta de Sudhana"
    narrator "Após descer do paraíso do senhor de Trāyastriṃśa, Sudhana chega a Kapilavastu e encontra Viśvāmitra, o mestre de crianças. Ele se inclina aos pés do mestre e o circunda centenas de milhares de vezes, mantendo-o à sua direita. Então para diante dele com as mãos unidas em homenagem. Sudhana conta que desenvolveu a aspiração pela iluminação suprema e completa, mas ainda não sabe como os bodhisattvas devem se treinar na conduta de bodhisattva nem de que modo devem praticá-la. Como ouviu que Viśvāmitra oferece instrução e ensinamentos a bodhisattvas, pede que lhe explique esse caminho de treino e prática."
    speaker_012 "Desenvolvi a aspiração à iluminação suprema, mas ainda busco compreender o treino e a prática da conduta de bodhisattva."
    speaker_012 "Ouvi que ofereces ensinamentos a bodhisattvas. Peço tua orientação sobre como seguir essa conduta."
    speaker_084 "Recebo tua pergunta, Sudhana; vou indicar-te alguém a quem podes recorrer para esse ensinamento."
    centered "Cena 2 — O encaminhamento a Śilpābhijña"
    narrator "Viśvāmitra responde a Sudhana, identificado também como filho de um chefe mercador. Em vez de explicar pessoalmente a conduta, nomeia Śilpābhijña, também filho de um chefe mercador. Segundo Viśvāmitra, Śilpābhijña estudou com bodhisattvas o conhecimento das palavras. Ele orienta Sudhana a procurá-lo e perguntar-lhe sobre o treino e a prática da conduta de bodhisattva, afirmando que Śilpābhijña lhe ensinará isso. O capítulo termina com esse encaminhamento: não narra a visita seguinte nem relata ensinamento adicional de Viśvāmitra. Seu papel aqui é receber a pergunta de Sudhana e apontá-lo ao próximo mestre indicado."
    speaker_084 "Procura Śilpābhijña, filho de um chefe mercador; ele estudou o conhecimento das palavras com bodhisattvas."
    speaker_084 "Pergunta-lhe sobre o treino e a prática da conduta de bodhisattva; ele poderá ensinar-te."
    speaker_012 "Seguirei tua indicação e buscarei Śilpābhijña para aprender sobre essa conduta."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Como você gostaria de refletir sobre a resposta de Viśvāmitra? (A escolha é opcional e não altera o encaminhamento de Sudhana.)"
        "Observar que Sudhana pediu orientação sobre treino e prática.":
            narrator "A pergunta de Sudhana abrange os dois aspectos."
        "Observar que Viśvāmitra indicou Śilpābhijña como próximo mestre.":
            narrator "A indicação conduz Sudhana ao mestre nomeado."
        "Refletir sobre o conhecimento das palavras estudado por Śilpābhijña.":
            narrator "Viśvāmitra menciona esse estudo como contexto da indicação."
    call quiz_ch46
    menu:
        "Continuar — capítulo 47":
            jump chapter_47
        "Voltar ao índice":
            jump chapter_index

label quiz_ch46:
    centered "Quem é o próximo mestre?"
    narrator "Escolha a resposta que corresponde ao encaminhamento narrado no capítulo. Minijogo não canônico."
    while True:
        menu:
            "A quem Viśvāmitra orienta Sudhana a procurar?"
            "Śilpābhijña, filho de um chefe mercador que estudou o conhecimento das palavras com bodhisattvas.":
                if 0 == 0:
                    narrator "Correto: Viśvāmitra encaminha Sudhana a Śilpābhijña."
                    return
                else:
                    narrator "Revise a indicação de Viśvāmitra: o capítulo nomeia Śilpābhijña."
            "Outro mestre de crianças de Kapilavastu.":
                if 1 == 0:
                    narrator "Correto: Viśvāmitra encaminha Sudhana a Śilpābhijña."
                    return
                else:
                    narrator "Revise a indicação de Viśvāmitra: o capítulo nomeia Śilpābhijña."
            "Um bodhisattva não nomeado que ensinou Viśvāmitra.":
                if 2 == 0:
                    narrator "Correto: Viśvāmitra encaminha Sudhana a Śilpābhijña."
                    return
                else:
                    narrator "Revise a indicação de Viśvāmitra: o capítulo nomeia Śilpābhijña."

label chapter_47:
    hide screen master_provisional_badge
    scene bg_ch47 with dissolve
    show master_ch47_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 47 — Śilpābhijña"
    centered "Cena 1 — A pergunta de Sudhana"
    narrator "Sudhana encontra Śilpābhijña, filho do chefe dos mercadores, inclina a cabeça aos pés dele e permanece diante dele com as mãos unidas em homenagem. Expõe que já desenvolveu a aspiração pela iluminação suprema e completa, mas não sabe como os bodhisattvas devem treinar na conduta de bodhisattva nem como devem praticá-la. Sabendo que Śilpābhijña instrui bodhisattvas, pede que lhe explique esse caminho. O mestre responde identificando a libertação que alcançou: o conhecimento superior das artes. A conversa, assim, passa da pergunta sobre treinamento para a apresentação do conhecimento que sustenta a resposta do mestre."
    speaker_012 "Desenvolvi a aspiração pela iluminação completa, mas ainda procuro compreender como treinar e praticar a conduta de bodhisattva."
    speaker_085 "Posso compartilhar a libertação que alcancei: ela é chamada conhecimento superior das artes."
    centered "Cena 2 — O alfabeto como entradas para a sabedoria"
    narrator "Śilpābhijña relata que, ao estudar o alfabeto e recitar suas letras, realizou entradas para a perfeição da sabedoria. A letra A conduziu à entrada chamada esfera indiferenciada; ra, à dos particulares infinitos das bases; pa, à integração da base do reino dos fenômenos; e ca, à divisão da roda. Entre as associações seguintes estão a ausência de localização e de base, a união irreversível, o campo vajra, a essência do oceano e a cessação de todo tormento. Ele prossegue, ligando sucessivas letras a denominações de sabedoria, até declarar que realizou incontáveis entradas desse tipo. O texto apresenta essas associações como ensinamento de Śilpābhijña, sem descrever manifestações visuais ou outros efeitos."
    speaker_085 "Ao recitar as letras, realizei entradas da perfeição da sabedoria, cada qual nomeada de modo próprio."
    speaker_012 "Então, o estudo do alfabeto se tornou para você uma via de incontáveis entradas para a sabedoria."
    centered "Cena 3 — O limite declarado e a próxima amiga espiritual"
    narrator "Śilpābhijña ressalva que conhece apenas a libertação por ele alcançada. Por isso, não pretende descrever plenamente os bodhisattvas que dominam artes mundanas e supramundanas: enumera conhecimentos de escrita, cálculo, mantras, remédios e cura; de materiais preciosos; de parques, florestas, povoações e residências; e de zodíaco, presságios, sinais, fome e colheitas, entre outros, além das qualidades supramundanas. Em seguida, orienta Sudhana a procurar Bhadrottamā, amiga espiritual residente em Vartanaka, na região de Kevalaka, em Magadha. Sudhana curva-se aos pés de Śilpābhijña, circunda-o muitas centenas de milhares de vezes mantendo-o à direita e parte, olhando para trás repetidamente."
    speaker_085 "Conheço esta libertação, mas não posso descrever por completo as qualidades de quem aperfeiçoou todas as artes."
    speaker_085 "Procure Bhadrottamā, em Vartanaka, na região de Kevalaka, em Magadha, e pergunte como praticar a conduta de bodhisattva."
    speaker_012 "Recebo sua orientação e sigo para encontrar a amiga espiritual que indicou."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Śilpābhijña você gostaria de ponderar antes de seguir?"
        "As letras como entradas para a perfeição da sabedoria":
            narrator "A reflexão acompanha as associações que Śilpābhijña descreveu; Sudhana prossegue conforme a narrativa."
        "A amplitude das artes mundanas e supramundanas":
            narrator "A reflexão retoma a ressalva do mestre sobre a amplitude dessas qualidades; Sudhana prossegue conforme a narrativa."
        "A orientação para procurar Bhadrottamā":
            narrator "A reflexão considera a próxima amiga espiritual indicada; Sudhana prossegue conforme a narrativa."
    call quiz_ch47
    menu:
        "Continuar — capítulo 48":
            jump chapter_48
        "Voltar ao índice":
            jump chapter_index

label quiz_ch47:
    centered "Letra e entrada de sabedoria"
    narrator "Escolha a associação explicitamente ensinada por Śilpābhijña. Minijogo não canônico; não altera a narrativa."
    while True:
        menu:
            "Segundo Śilpābhijña, a recitação de qual letra realizou a entrada chamada ‘cessação de todo tormento’?"
            "ṣṭa":
                if 0 == 0:
                    narrator "Correto: Śilpābhijña associa ṣṭa à cessação de todo tormento."
                    return
                else:
                    narrator "Releia a sequência ensinada: a entrada chamada cessação de todo tormento corresponde a ṣṭa."
            "ra":
                if 1 == 0:
                    narrator "Correto: Śilpābhijña associa ṣṭa à cessação de todo tormento."
                    return
                else:
                    narrator "Releia a sequência ensinada: a entrada chamada cessação de todo tormento corresponde a ṣṭa."
            "pa":
                if 2 == 0:
                    narrator "Correto: Śilpābhijña associa ṣṭa à cessação de todo tormento."
                    return
                else:
                    narrator "Releia a sequência ensinada: a entrada chamada cessação de todo tormento corresponde a ṣṭa."

label chapter_48:
    hide screen master_provisional_badge
    scene bg_ch48 with dissolve
    show master_ch48_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 48 — Bhadrottamā"
    centered "Cena 1 — O ensinamento e a próxima visita"
    narrator "Sudhana, filho de um grande mercador, saúda Bhadrottamā e pergunta como os bodhisattvas devem treinar e praticar sua conduta. Ela explica que conhece e ensina o Dharma chamado “O Campo Sem Localização” e alcançou o samādhi “Sem Impedimentos”. Nesse estado, enumera faculdades e manifestações da onisciência sem impedimentos, incluindo olhos, ouvidos, nariz, língua, corpo, mente, ondas, relâmpago e poder, bem como o campo de iluminação dos seres. Bhadrottamā delimita o que pode ensinar: conhece apenas esse Dharma, não a conduta completa. Indica Muktāsāra, ourives em Bharukaccha, ao sul. Sudhana se despede, circum-ambula a mestra muitas centenas de milhares de vezes, mantendo-a à direita, olha para trás repetidamente e parte."
    speaker_012 "Bhadrottamā, como devo compreender o treinamento e a prática da conduta de bodhisattva?"
    speaker_086 "O ensinamento que conheço chama-se O Campo Sem Localização; nele alcancei o samādhi Sem Impedimentos."
    speaker_086 "Não conheço toda a conduta. Procure Muktāsāra, o ourives de Bharukaccha, ao sul, e pergunte-lhe sobre essa prática."
    speaker_012 "Recebo sua indicação e sigo adiante, levando comigo a pergunta sobre a conduta dos bodhisattvas."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do encontro você quer considerar antes de Sudhana seguir viagem?"
        "O nome do ensinamento de Bhadrottamā":
            narrator "O Campo Sem Localização é o Dharma que ela diz conhecer e ensinar."
        "A indicação de outro mestre":
            narrator "Bhadrottamā encaminha Sudhana a Muktāsāra, em Bharukaccha."
        "A despedida reverente de Sudhana":
            narrator "Ele circum-ambula Bhadrottamā e olha para trás ao partir."
    call quiz_ch48
    menu:
        "Continuar — capítulo 49":
            jump chapter_49
        "Voltar ao índice":
            jump chapter_index

label quiz_ch48:
    centered "Identifique o ensinamento"
    narrator "Escolha a resposta que corresponde ao que Bhadrottamā declara conhecer e ensinar."
    while True:
        menu:
            "Como se chama o Dharma ensinado por Bhadrottamā?"
            "A Conduta Sem Desvio":
                if 0 == 1:
                    narrator "Correto: ela chama seu ensinamento de O Campo Sem Localização."
                    return
                else:
                    narrator "Tente novamente: recorde o nome do Dharma que Bhadrottamā diz ensinar."
            "O Campo Sem Localização":
                if 1 == 1:
                    narrator "Correto: ela chama seu ensinamento de O Campo Sem Localização."
                    return
                else:
                    narrator "Tente novamente: recorde o nome do Dharma que Bhadrottamā diz ensinar."
            "A Luz de Bharukaccha":
                if 2 == 1:
                    narrator "Correto: ela chama seu ensinamento de O Campo Sem Localização."
                    return
                else:
                    narrator "Tente novamente: recorde o nome do Dharma que Bhadrottamā diz ensinar."

label chapter_49:
    hide screen master_provisional_badge
    scene bg_ch49 with dissolve
    show master_ch49_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 49 — Muktāsāra"
    centered "Cena 1 — A orientação de Muktāsāra"
    narrator "Em Bharukaccha, Sudhana se aproxima do ourives Muktāsāra, reverencia seus pés e, de mãos unidas, expõe sua aspiração à iluminação completa. Quer saber como os bodhisattvas devem treinar e praticar sua conduta. Muktāsāra declara conhecer a libertação dos bodhisattvas denominada exibição da memória pura e desimpedida; diz também que busca continuamente o Dharma aos pés dos tathāgatas nas dez direções. Mas delimita o que pode ensinar: conhece somente essa libertação, não a conduta nem as qualidades daqueles bodhisattvas estabelecidos em grande mérito e sabedoria. Então encaminha Sudhana a Sucandra, chefe de família que reside na floresta junto à cidade e tem uma casa continuamente brilhante. Sudhana circunda Muktāsāra muitas centenas de milhares de vezes, mantendo-o à direita; olha para trás repetidas vezes e parte."
    speaker_012 "Muktāsāra, aspira à iluminação completa e busco compreender como praticar a conduta dos bodhisattvas."
    speaker_087 "O que conheço é a libertação chamada exibição da memória pura e desimpedida; continuamente busco o Dharma aos pés dos tathāgatas nas dez direções."
    speaker_012 "A quem devo perguntar sobre o treinamento e a prática dessa conduta?"
    speaker_087 "Procura Sucandra, na floresta junto a Bharukaccha; pergunta-lhe como um bodhisattva deve treinar e praticar."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto da resposta de Muktāsāra você escolheria levar como reflexão durante a partida de Sudhana?"
        "Reconhecer com precisão o limite do próprio conhecimento":
            narrator "Essa é uma reflexão possível; a jornada de Sudhana segue como narrada."
        "Continuar buscando o Dharma":
            narrator "Essa é uma reflexão possível; a jornada de Sudhana segue como narrada."
        "Atentar à indicação do próximo mestre":
            narrator "Essa é uma reflexão possível; a jornada de Sudhana segue como narrada."
    call quiz_ch49
    menu:
        "Continuar — capítulo 50":
            jump chapter_50
        "Voltar ao índice":
            jump chapter_index

label quiz_ch49:
    centered "O próximo encontro"
    narrator "Escolha a resposta baseada no capítulo."
    while True:
        menu:
            "A quem Muktāsāra encaminha Sudhana?"
            "Ao chefe de família Sucandra, que vive na floresta junto a Bharukaccha.":
                if 0 == 0:
                    narrator "Correto: Muktāsāra indica Sucandra, na floresta junto à cidade."
                    return
                else:
                    narrator "Releia a orientação: o próximo mestre indicado é Sucandra, que reside na floresta junto a Bharukaccha."
            "A outro ourives que vive no centro da cidade.":
                if 1 == 0:
                    narrator "Correto: Muktāsāra indica Sucandra, na floresta junto à cidade."
                    return
                else:
                    narrator "Releia a orientação: o próximo mestre indicado é Sucandra, que reside na floresta junto a Bharukaccha."
            "Aos tathāgatas nas dez direções, para uma conversa na cidade.":
                if 2 == 0:
                    narrator "Correto: Muktāsāra indica Sucandra, na floresta junto à cidade."
                    return
                else:
                    narrator "Releia a orientação: o próximo mestre indicado é Sucandra, que reside na floresta junto a Bharukaccha."

label chapter_50:
    hide screen master_provisional_badge
    scene bg_ch50 with dissolve
    show master_ch50_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 50 — Sucandra"
    centered "Cena 1 — A indicação de Sucandra"
    narrator "Sudhana vai à casa do chefe de família Sucandra, inclina a cabeça aos pés dele e, com as mãos unidas em homenagem, pergunta como os bodhisattvas devem treinar e praticar sua conduta. Sucandra responde que conhece a libertação de bodhisattva chamada luz imaculada da sabedoria. Ele delimita o alcance do próprio saber: não pode explicar a conduta nem as qualidades daqueles que alcançaram incontáveis liberações. Então indica Ajitasena, chefe de família que reside em Roruka, na região sul, e orienta Sudhana a lhe fazer a mesma pergunta. Sudhana reverencia Sucandra, circunda-o centenas de milhares de vezes mantendo-o à direita e parte, voltando o olhar para ele repetidas vezes."
    speaker_012 "Sucandra, busco compreender como se treinam e se praticam as ações de um bodhisattva."
    speaker_088 "O que conheço é a libertação chamada luz imaculada da sabedoria; não posso descrever todas as outras realizações."
    speaker_012 "Agradeço por indicar alguém a quem posso levar minha pergunta."
    speaker_088 "Procure Ajitasena em Roruka, na região sul, e pergunte a ele sobre essa prática."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao refletir sobre o encontro com Sucandra, que aspecto você gostaria de guardar?"
        "A clareza sobre o que se conhece":
            narrator "Reconhecer os limites do próprio saber também orienta a busca."
        "A indicação de Ajitasena":
            narrator "A jornada de Sudhana segue para o mestre indicado."
        "A reverência na despedida":
            narrator "A homenagem acompanha a partida de Sudhana."
    call quiz_ch50
    menu:
        "Continuar — capítulo 51":
            jump chapter_51
        "Voltar ao índice":
            jump chapter_index

label quiz_ch50:
    centered "O que Sucandra conhece?"
    narrator "Escolha a resposta apoiada explicitamente pelo capítulo."
    while True:
        menu:
            "Qual libertação de bodhisattva Sucandra diz conhecer?"
            "A luz imaculada da sabedoria":
                if 0 == 0:
                    narrator "Correto: Sucandra conhece a libertação chamada luz imaculada da sabedoria."
                    return
                else:
                    narrator "Revise o nome da libertação mencionado por Sucandra."
            "A chama da compaixão sem limites":
                if 1 == 0:
                    narrator "Correto: Sucandra conhece a libertação chamada luz imaculada da sabedoria."
                    return
                else:
                    narrator "Revise o nome da libertação mencionado por Sucandra."
            "O caminho da visão celeste":
                if 2 == 0:
                    narrator "Correto: Sucandra conhece a libertação chamada luz imaculada da sabedoria."
                    return
                else:
                    narrator "Revise o nome da libertação mencionado por Sucandra."

label chapter_51:
    hide screen master_provisional_badge
    scene bg_ch51 with dissolve
    show master_ch51_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 51 — Ajitasena"
    centered "Cena 1 — A pergunta de Sudhana em Roruka"
    narrator "Sudhana chega à cidade de Roruka e se aproxima de Ajitasena, chefe de família. Ele se inclina aos pés do mestre e permanece diante dele com as mãos unidas em reverência. Sudhana explica que despertou a aspiração à iluminação suprema e completa, mas não sabe como os bodhisattvas devem se treinar na conduta de bodhisattva nem como devem praticá-la. Ele pede que Ajitasena lhe explique. Em resposta, Ajitasena identifica a realização que alcançou: a libertação de bodhisattva chamada características incessantes, pela qual obteve o tesouro da visão incessante dos budas."
    speaker_012 "Aspiro à iluminação completa, mas ainda busco compreender como treinar e praticar a conduta de bodhisattva."
    speaker_012 "Ajitasena, peço que me oriente nessa questão."
    speaker_089 "Minha realização é a libertação chamada características incessantes e o tesouro da visão incessante dos budas."
    centered "Cena 2 — O direcionamento ao mestre seguinte"
    narrator "Ajitasena orienta Sudhana a seguir para a região sul, até a aldeia chamada Dharma, onde reside o brâmane Śivarāgra. Recomenda que Sudhana lhe pergunte como um bodhisattva deve se treinar na conduta de bodhisattva e como deve praticá-la. O texto não conta a chegada à aldeia nem um encontro com Śivarāgra. Antes de partir, Sudhana inclina a cabeça aos pés de Ajitasena e circumambula o chefe de família centenas de milhares de vezes, mantendo-o à sua direita. Ele olha para trás repetidamente enquanto se afasta. Assim termina a visita a Ajitasena e o encaminhamento para o mestre indicado."
    speaker_089 "Na região sul, na aldeia Dharma, vive o brâmane Śivarāgra; leve a ele sua pergunta sobre a conduta de bodhisattva."
    speaker_012 "Recebo sua orientação e sigo em busca de Śivarāgra."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao ouvir a orientação de Ajitasena, em que aspecto você prefere refletir antes de prosseguir?"
        "A libertação de Ajitasena":
            narrator "Você reflete sobre a libertação chamada características incessantes e sobre a visão incessante dos budas."
        "A pergunta que seguirá com Sudhana":
            narrator "Você retoma a questão sobre como treinar e praticar a conduta de bodhisattva."
        "O gesto de despedida":
            narrator "Você considera a reverência e a circumambulação descritas na partida de Sudhana."
    call quiz_ch51
    menu:
        "Continuar — capítulo 52":
            jump chapter_52
        "Voltar ao índice":
            jump chapter_index

label quiz_ch51:
    centered "Identifique a orientação de Ajitasena"
    narrator "Escolha a resposta sustentada pelo capítulo. Esta atividade é não canônica e não altera a história."
    while True:
        menu:
            "Para qual mestre e local Ajitasena encaminha Sudhana?"
            "Ao brâmane Śivarāgra, na aldeia Dharma, na região sul.":
                if 0 == 0:
                    narrator "Correto: Ajitasena indica Śivarāgra, que reside na aldeia Dharma, na região sul."
                    return
                else:
                    narrator "Revise a orientação explícita de Ajitasena: o destino indicado é a aldeia Dharma, na região sul."
            "A outro chefe de família em Roruka.":
                if 1 == 0:
                    narrator "Correto: Ajitasena indica Śivarāgra, que reside na aldeia Dharma, na região sul."
                    return
                else:
                    narrator "Revise a orientação explícita de Ajitasena: o destino indicado é a aldeia Dharma, na região sul."
            "A um buda numa cidade da região norte.":
                if 2 == 0:
                    narrator "Correto: Ajitasena indica Śivarāgra, que reside na aldeia Dharma, na região sul."
                    return
                else:
                    narrator "Revise a orientação explícita de Ajitasena: o destino indicado é a aldeia Dharma, na região sul."

label chapter_52:
    hide screen master_provisional_badge
    scene bg_ch52 with dissolve
    centered "Capítulo 52 — Śivarāgra"
    centered "Cena 1 — O pedido de Sudhana"
    narrator "Depois de chegar à aldeia de Dharma, Sudhana aproxima-se do brâmane Śivarāgra. Curva a cabeça aos pés dele e permanece diante do mestre com as mãos unidas em homenagem. Sudhana declara que desenvolveu a aspiração à iluminação suprema e completa, mas ainda não sabe como os bodhisattvas devem se treinar na conduta de bodhisattva nem como devem praticá-la. Sabendo que Śivarāgra oferece instruções e ensinamentos a bodhisattvas, pede que explique esse treinamento e essa prática. O pedido estabelece o tema da visita: aprender a conduta, sem que o capítulo descreva qualquer outro acontecimento antes da resposta do brâmane."
    speaker_012 "Aspiro à iluminação suprema e completa, mas ainda busco compreender como se treinam e praticam a conduta de bodhisattva."
    speaker_012 "Brâmane Śivarāgra, peço que me instrua sobre esse caminho de treinamento e prática."
    centered "Cena 2 — A fala fortalecida pela verdade e o próximo ensinamento"
    narrator "Śivarāgra diz conhecer a conduta fortalecida pela verdade e explica que a fala de verdade está ligada à perseverança dos bodhisattvas dos três tempos na busca da iluminação suprema e completa. Quando declara que determinada necessidade seja atendida, seus desejos se realizam. Ainda assim, limita sua afirmação: conhece somente essa capacitação e não sabe explicar as qualidades dos bodhisattvas que alcançaram a fala devotada à verdade. Orienta Sudhana a ir à cidade de Sumanāmukha, na região sul, e perguntar ao menino Śrīsaṃbhava e à menina Śrīmati como treinar e praticar a conduta. Sudhana reverencia o brâmane, dá centenas de milhares de voltas ao redor dele mantendo-o à direita e parte, olhando para trás repetidamente."
    speaker_090 "Conheço a conduta fortalecida pela verdade e o poder da fala de verdade, mas meu conhecimento se limita a essa capacitação."
    speaker_090 "Procure Śrīsaṃbhava e Śrīmati em Sumanāmukha e pergunte a eles sobre o treinamento e a prática da conduta."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao ouvir a orientação de Śivarāgra, em que aspecto Sudhana poderia refletir antes de partir?"
        "A relação entre a fala de verdade e a perseverança dos bodhisattvas":
            narrator "Essa é a capacitação que Śivarāgra diz conhecer."
        "O limite do conhecimento que o brâmane declara":
            narrator "Ele afirma conhecer somente essa capacitação."
        "A quem perguntar sobre treinamento e prática":
            narrator "Śrīsaṃbhava e Śrīmati são os indicados."
    call quiz_ch52
    menu:
        "Continuar — capítulo 53":
            jump chapter_53
        "Voltar ao índice":
            jump chapter_index

label quiz_ch52:
    centered "A indicação de Śivarāgra"
    narrator "Escolha a resposta que corresponde ao ensinamento explícito do capítulo."
    while True:
        menu:
            "O que Śivarāgra afirma conhecer?"
            "A conduta fortalecida pela verdade.":
                if 0 == 0:
                    narrator "Correto: Śivarāgra declara conhecer a capacitação da verdade."
                    return
                else:
                    narrator "Releia o limite que Śivarāgra atribui ao próprio conhecimento."
            "Todas as qualidades de todos os bodhisattvas.":
                if 1 == 0:
                    narrator "Correto: Śivarāgra declara conhecer a capacitação da verdade."
                    return
                else:
                    narrator "Releia o limite que Śivarāgra atribui ao próprio conhecimento."
            "O treinamento completo de Śrīsaṃbhava e Śrīmati.":
                if 2 == 0:
                    narrator "Correto: Śivarāgra declara conhecer a capacitação da verdade."
                    return
                else:
                    narrator "Releia o limite que Śivarāgra atribui ao próprio conhecimento."

label chapter_53:
    hide screen master_provisional_badge
    scene bg_ch53 with dissolve
    show master_ch53_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 53 — Śrīsaṃbhava and Śrīmati"
    centered "Cena 1 — O pedido de Sudhana"
    narrator "Sudhana chega a Sumanāmukha e se aproxima do menino Śrīsaṃbhava e da menina Śrīmati. Ele inclina a cabeça aos pés dos dois e permanece diante deles com as mãos unidas em homenagem. Diz que já despertou a aspiração pela iluminação completa, mas ainda não sabe como os bodhisattvas devem treinar na conduta nem como devem praticá-la. Tendo ouvido que os dois ensinam bodhisattvas, pede que expliquem esse caminho. A cena estabelece a pergunta que orienta o capítulo: como aprender a conduta sem confundir a aspiração com a realização de toda a prática?"
    speaker_012 "Aspiro à iluminação completa, mas ainda preciso compreender como se treina e se pratica a conduta de bodhisattva."
    speaker_091 "Escutaremos tua pergunta e compartilharemos a libertação que realizamos."
    speaker_092 "Que a explicação te ajude a prosseguir no aprendizado."
    centered "Cena 2 — A aparência de ilusão"
    narrator "Śrīsaṃbhava e Śrīmati explicam que ambos realizaram a libertação chamada aparência de ilusão. Por meio dela, veem os mundos como aparências que surgem de causas e condições ilusórias. Também compreendem como ilusórios o karma, as aflições, os seres e os fenômenos dependentes de condições. A percepção se estende aos três reinos e aos processos de concepção, nascimento, envelhecimento e morte, além do sofrimento e da agitação, relacionados a pensamentos incorretos. Não dizem que conhecem toda a conduta dos bodhisattvas: afirmam conhecer somente essa libertação e reconhecem os limites do que podem descrever."
    speaker_092 "Nossa realização é a libertação chamada aparência de ilusão."
    speaker_091 "Ela nos permite ver mundos e fenômenos como aparências surgidas de causas e condições."
    speaker_012 "Compreendo que essa visão abrange também o modo como surgem os seres e seus sofrimentos."
    centered "Cena 3 — O caminho até Maitreya"
    narrator "Depois de ensinar sua libertação, os dois orientam Sudhana a seguir para o sul, até o parque Mahāvyūha, na região de Samudrakaccha. Ali, dizem, encontra-se o grande kūṭāgāra Vairocana-vyūhālaṃkāragarbha, manifestado por mérito, aspirações, conhecimento, poder e compaixão de um bodhisattva. Nele reside Maitreya, com propósitos ligados ao amadurecimento e à orientação de seres e ao fortalecimento do Mahāyāna. Śrīsaṃbhava e Śrīmati recomendam que Sudhana lhe pergunte sobre a conduta, o caminho, os treinamentos, as aspirações, as perfeições, os estágios e o serviço aos bons amigos espirituais."
    speaker_091 "No sul, no parque Mahāvyūha, encontrarás Maitreya no grande kūṭāgāra."
    speaker_092 "Pergunta-lhe como purificar o caminho e completar as práticas de bodhisattva."
    speaker_012 "Levarei comigo essas perguntas e seguirei a orientação de vocês."
    centered "Cena 4 — Uma prática sem medida"
    narrator "Os mestres alertam Sudhana para não tomar um só mérito, uma oração, um estágio ou uma quantidade limitada de terras de budas como objetivo final. A atividade do bodhisattva deve alcançar incontáveis seres, disposições, condutas, aflições e meios de guiá-los. Eles descrevem essa prática como abrangente em todos os tempos, nascimentos, domínios e relações com budas e bodhisattvas. Em seguida, enfatizam a importância dos kalyāṇamitras: aprender conduta, desenvolver qualidades, sustentar aspirações e realizar práticas depende desses bons amigos. A instrução os compara a pais, professores, médicos, guias, capitães de balsa e navegadores, destacando funções de proteção, ensino e condução."
    speaker_091 "Não limites a aspiração a uma medida pequena de mérito ou prática."
    speaker_092 "Os bons amigos espirituais orientam o aprendizado e sustentam o desenvolvimento da conduta."
    speaker_012 "Vou manter a disposição de aprender e de praticar sem tomar um limite como conclusão."
    centered "Cena 5 — Instruções para buscar bons amigos"
    narrator "Śrīsaṃbhava e Śrīmati aconselham Sudhana a aproximar-se continuamente dos kalyāṇamitras, sem se cansar de encontrá-los, perguntar, reverenciá-los ou preservar corretamente suas instruções. Propõem imagens para a atitude do aprendiz e para a relação com o ensinamento: considerar-se doente, o mestre como médico e a instrução como remédio; ou considerar-se viajante, o mestre como guia e o ensinamento como caminho. A prática é o que corresponde à cura ou à jornada segura. Ao final, Sudhana ouve com alegria, inclina-se aos pés dos dois e os circunda muitas centenas de milhares de vezes, mantendo-os à sua direita. Olha para trás repetidamente e então parte."
    speaker_092 "Recebe a instrução como remédio e dedica-te à prática que pode curar as aflições."
    speaker_091 "Aproxima-te dos bons amigos sem cansaço e guarda corretamente o que ensinam."
    speaker_012 "Parto agradecido, levando estas orientações comigo."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual reflexão você levaria deste ensinamento sobre a busca de kalyāṇamitras?"
        "Continuar perguntando e aprendendo com eles.":
            narrator "Essa disposição corresponde à exortação de não se cansar de buscar e consultar bons amigos."
        "Considerar suficientes um único ensinamento e uma medida limitada de prática.":
            narrator "Os mestres alertam contra tomar uma medida limitada como conclusão."
        "Lembrar a imagem do mestre como guia e da instrução como caminho.":
            narrator "Essa é uma das comparações usadas para orientar a prática."
    call quiz_ch53
    menu:
        "Continuar — capítulo 54":
            jump chapter_54
        "Voltar ao índice":
            jump chapter_index

label quiz_ch53:
    centered "Lembrete da instrução"
    narrator "Escolha a resposta apoiada explicitamente no ensinamento deste capítulo."
    while True:
        menu:
            "Segundo Śrīsaṃbhava e Śrīmati, de que depende a conduta de bodhisattva?"
            "Dos kalyāṇamitras, os bons amigos espirituais.":
                if 0 == 0:
                    narrator "Correto: o capítulo afirma que a conduta e as realizações de bodhisattva dependem dos kalyāṇamitras."
                    return
                else:
                    narrator "Releia a instrução sobre a importância dos bons amigos espirituais e tente outra opção."
            "Da realização de apenas uma oração.":
                if 1 == 0:
                    narrator "Correto: o capítulo afirma que a conduta e as realizações de bodhisattva dependem dos kalyāṇamitras."
                    return
                else:
                    narrator "Releia a instrução sobre a importância dos bons amigos espirituais e tente outra opção."
            "Da busca de uma quantidade mensurável de terras de budas.":
                if 2 == 0:
                    narrator "Correto: o capítulo afirma que a conduta e as realizações de bodhisattva dependem dos kalyāṇamitras."
                    return
                else:
                    narrator "Releia a instrução sobre a importância dos bons amigos espirituais e tente outra opção."

label chapter_54:
    hide screen master_provisional_badge
    scene bg_ch54 with dissolve
    show master_ch54_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 54 — Maitreya"
    centered "Cena 1 — Diante do kūṭāgāra"
    narrator "Instruído por seu mestre espiritual, Sudhana revê sua vida passada: reconhece que seu corpo e sua mente estiveram presos a ações sem proveito, motivações equivocadas e falta de diligência. Em vez de se deter no arrependimento, decide orientar corpo e mente à conduta dos bodhisattvas, beneficiar todos os seres, buscar o Dharma dos budas e servir aos mestres espirituais. Diante do kūṭāgāra Vairocanavyūhālaṃkāragarbha, sua homenagem se amplia em contemplação e aspiração. Ele observa o lugar por longo tempo, mantém as mãos unidas e o circunda muitas centenas de milhares de vezes, aguardando Maitreya."
    speaker_012 "Que minhas ações de agora sejam úteis aos seres, não apenas a mim."
    speaker_012 "Farei da diligência e da busca pelo Dharma a direção desta jornada."
    centered "Cena 2 — A chegada de Maitreya"
    narrator "Maitreya vem de fora do kūṭāgāra acompanhado por numerosos seres e por líderes de devas, nāgas, yakṣas, gandharvas, asuras, garuḍas, kinnaras e mahoragas. Śakra está à sua direita e Brahmā à esquerda; governantes do mundo e muitos brâmanes também o cercam. Ao vê-lo, Sudhana se prostra com o corpo inteiro. Maitreya o indica à comitiva e o recebe, reconhecendo sua busca pela conduta dos bodhisattvas e sua perseverança. Em seguida, diante da assembleia, descreve a importância do empenho de Sudhana e ensina que a aspiração à iluminação sustenta as qualidades e práticas dos bodhisattvas, como semente, campo, remédio, joia e lâmpada."
    speaker_093 "Sua busca pela conduta dos bodhisattvas o trouxe até esta assembleia; seja bem-vindo."
    speaker_012 "Quero aprender como treinar nessa conduta e como praticá-la."
    speaker_093 "A aspiração à iluminação é fundamento para reunir qualidades e orientar a atividade compassiva."
    centered "Cena 3 — A aspiração como fundamento"
    narrator "Sudhana pergunta como os bodhisattvas devem se treinar, praticar e adquirir os Dharmas dos budas sem abandonar o cuidado pelos seres. Maitreya apresenta sua pergunta à assembleia e exalta a diligência com que Sudhana buscou mestres espirituais. O ensino se concentra na aspiração à iluminação: ela é comparada a remédio contra as aflições, joia que não perde seu valor, lâmpada que dissipa a escuridão e diamante capaz de cortar concepções errôneas. As imagens convergem numa instrução: a aspiração, acompanhada de grande compaixão, sabedoria e motivação elevada, dá suporte às práticas e orações dos bodhisattvas. Maitreya então o convida a entrar no kūṭāgāra para contemplar como se manifesta essa conduta."
    speaker_093 "A aspiração à iluminação sustenta a prática e reúne qualidades voltadas ao benefício dos seres."
    speaker_012 "Então, ver essas manifestações poderá esclarecer como a conduta é treinada."
    speaker_093 "Entre e observe; é assim que conhecerás as manifestações da conduta dos bodhisattvas."
    centered "Cena 4 — Mundos refletidos no palácio"
    narrator "Maitreya abre a porta com um estalar de dedos, e Sudhana entra; a porta se fecha por si. O interior se revela vasto, adornado por incontáveis joias, estandartes, flores, espelhos e outros ornamentos, com inúmeros kūṭāgāras refletidos sem se confundirem. Pela bênção de Maitreya, Sudhana percebe mundos, assembleias e ensinamentos em uma sucessão de visões. Vê Maitreya em diferentes contextos de orientação dos seres, além de cenas de suas práticas passadas e da transmissão do Dharma. A experiência inclui manifestações variadas, não um único cenário isolado. Quando Maitreya estala os dedos novamente, Sudhana sai do samādhi. Maitreya explica que as aparições são como conjurações, sonhos e reflexos, sem natureza própria independente."
    speaker_012 "As visões se apresentam em incontáveis formas, sem se misturarem umas às outras."
    speaker_093 "O que viste manifesta a bênção da sabedoria e da prática dos bodhisattvas."
    speaker_093 "Como sonhos e reflexos, essas aparições não possuem existência independente."
    centered "Cena 5 — Perguntas, origem e próximo mestre"
    narrator "Sudhana reconhece que viu as manifestações pela bênção de Maitreya e pergunta o nome da libertação contemplada. Maitreya a identifica como a essência da manifestação da memória infalível, ligada ao conhecimento dos objetos nos três tempos. Ao ser perguntado de onde veio, explica que a atividade dos bodhisattvas não se define por vir ou partir; ainda assim, conta que nasceu em Kuṭi, na terra dos Māladas, onde ensinou o Dharma e conduziu familiares e habitantes ao Mahāyāna. Expõe dez lugares de nascimento dos bodhisattvas, incluindo aspiração à iluminação, grande compaixão, prática do Dharma, método e sabedoria. Diz que se manifestará em Tuṣita e encaminha Sudhana de volta a Mañjuśrī. Sudhana homenageia Maitreya e parte."
    speaker_012 "Como se chama a libertação que me foi revelada nessa experiência?"
    speaker_093 "Ela é a essência da manifestação da memória infalível que abrange os três tempos."
    speaker_093 "Retorna a Mañjuśrī e pergunta como compreender e praticar a conduta excelente."
    speaker_012 "Partirei com gratidão por este ensinamento e seguirei a orientação recebida."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Maitreya você gostaria de levar como reflexão opcional?"
        "A aspiração à iluminação como fundamento":
            narrator "Uma reflexão possível: como uma aspiração firme orienta a prática?"
        "A compaixão que beneficia os seres":
            narrator "Uma reflexão possível: como a compaixão sustenta o cuidado pelos seres?"
        "A natureza semelhante a sonho e reflexo":
            narrator "Uma reflexão possível: o que muda ao contemplar os fenômenos como reflexos?"
    call quiz_ch54
    menu:
        "Continuar — capítulo 55":
            jump chapter_55
        "Voltar ao índice":
            jump chapter_index

label quiz_ch54:
    centered "A imagem e seu ensinamento"
    narrator "Escolha a resposta que corresponde a um ensinamento explícito deste capítulo. Minijogo opcional, não canônico."
    while True:
        menu:
            "Segundo Maitreya, qual imagem expressa que a aspiração à iluminação dissipa a escuridão da ignorância?"
            "Uma lâmpada que ilumina o escuro":
                if 0 == 0:
                    narrator "Correto: Maitreya compara a aspiração à iluminação a uma lâmpada que dissipa a escuridão da ignorância."
                    return
                else:
                    narrator "Relembre o símile da lâmpada: no ensinamento, ela representa a luz da sabedoria que dissipa a ignorância."
            "Um barco que atravessa um rio físico":
                if 1 == 0:
                    narrator "Correto: Maitreya compara a aspiração à iluminação a uma lâmpada que dissipa a escuridão da ignorância."
                    return
                else:
                    narrator "Relembre o símile da lâmpada: no ensinamento, ela representa a luz da sabedoria que dissipa a ignorância."
            "Uma montanha que permanece imóvel":
                if 2 == 0:
                    narrator "Correto: Maitreya compara a aspiração à iluminação a uma lâmpada que dissipa a escuridão da ignorância."
                    return
                else:
                    narrator "Relembre o símile da lâmpada: no ensinamento, ela representa a luz da sabedoria que dissipa a ignorância."

label chapter_55:
    hide screen master_provisional_badge
    scene bg_ch55 with dissolve
    show master_ch55_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 55 — Mañjuśrī"
    centered "Cena 1 — A busca em Sumanāmukha"
    narrator "Após atravessar cento e dez cidades, Sudhana, filho do chefe dos mercadores, chega ao distrito chamado Sumanāmukha. Sua atenção está voltada para Mañjuśrī Kumārabhūta: ele pensa no mestre, procura por ele, aspira a vê-lo, ora por esse encontro e continua desejando encontrá-lo. O capítulo não descreve ruas, edifícios, paisagem ou outros elementos do cenário, por isso a cena permanece restrita à informação textual: Sudhana está na cidade de Sumanāmukha, dedicado à busca. A espera não é apresentada como um acontecimento separado; o texto destaca sua intenção constante de encontrar Mañjuśrī."
    narrator "Depois de cento e dez cidades, Sudhana chega a Sumanāmukha, ainda voltado à procura de Mañjuśrī Kumārabhūta."
    speaker_012 "Que eu possa ver Mañjuśrī Kumārabhūta; mantenho essa aspiração enquanto o procuro."
    centered "Cena 2 — A mão que alcança de longe"
    narrator "Mañjuśrī Kumārabhūta, a cento e dez yojanas de distância, estende a mão e a coloca sobre a cabeça de Sudhana, que se encontra em Sumanāmukha. Ele o encoraja e enumera condições que impedem alguém de conhecer esse caminho: falta de fé, cansaço mental, desalento, abandono da prática, afastamento da diligência, contentamento com poucas qualidades, apego a uma única raiz de mérito, falta de habilidade na conduta e nas aspirações, ausência do cuidado de um amigo espiritual e falta de consideração pelos budas. Sem esses apoios, diz o ensinamento, não se pode conhecer a verdadeira natureza dos fenômenos nem conhecer, examinar, compreender ou alcançar aquele campo e modo de atividade."
    speaker_094 "Sudhana, prossiga com fé, prática e diligência; não se contente com pouco nem se prenda a uma só raiz de mérito."
    speaker_094 "Sem esses apoios e sem o cuidado de um amigo espiritual, esse campo não pode ser conhecido nem alcançado."
    speaker_012 "Recebo o encorajamento e volto minha atenção ao caminho que você aponta."
    centered "Cena 3 — Portas do Dharma e partida"
    narrator "Mañjuśrī ensina o Dharma a Sudhana; inspira-o, louva-o e o alegra. Como resultado, Sudhana torna-se possuidor de incontáveis portas do Dharma e alcança a grande iluminação da sabedoria infinita. Mañjuśrī também o abençoa com retenção, eloquência, samādhi, cognições superiores e sabedoria infinita de um bodhisattva, e o estabelece no campo da conduta completamente boa. O capítulo não detalha cada porta do Dharma nem descreve a forma do ensinamento. Ao concluir, Mañjuśrī permanece em sua própria região e parte da presença de Sudhana; o texto não relata outra ação de Sudhana após essa partida."
    speaker_012 "O ensinamento abriu diante de mim incontáveis portas do Dharma e a grande iluminação da sabedoria infinita."
    speaker_094 "Que as qualidades de bodhisattva e a conduta completamente boa permaneçam como seu campo."
    narrator "Mañjuśrī permanece em sua própria região e parte da presença de Sudhana."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Qual aspecto do ensinamento de Mañjuśrī você escolheria contemplar antes de seguir? A escolha é apenas reflexiva e não altera a narrativa."
        "A importância de manter fé, prática e diligência":
            narrator "A reflexão acompanha as condições que Mañjuśrī apresenta para conhecer o caminho."
        "O papel do amigo espiritual e da consideração pelos budas":
            narrator "A reflexão retoma apoios explicitamente mencionados no ensinamento."
        "As incontáveis portas do Dharma e a sabedoria infinita":
            narrator "A reflexão se volta ao resultado descrito após o ensinamento."
    call quiz_ch55
    menu:
        "Continuar — capítulo 56":
            jump chapter_56
        "Voltar ao índice":
            jump chapter_index

label quiz_ch55:
    centered "Lembrete do ensinamento"
    narrator "Escolha a resposta baseada no que o capítulo afirma explicitamente. Minijogo não canônico."
    while True:
        menu:
            "O que Mañjuśrī ensina a Sudhana após inspirá-lo e alegrá-lo?"
            "Ele se torna possuidor de incontáveis portas do Dharma e alcança a grande iluminação da sabedoria infinita.":
                if 0 == 0:
                    narrator "Correto: esses são os resultados explicitamente narrados após o ensinamento do Dharma."
                    return
                else:
                    narrator "Releia o desfecho do capítulo: ele relata incontáveis portas do Dharma e a grande iluminação da sabedoria infinita."
            "Ele retorna a Sumanāmukha depois de percorrer outras cento e dez cidades.":
                if 1 == 0:
                    narrator "Correto: esses são os resultados explicitamente narrados após o ensinamento do Dharma."
                    return
                else:
                    narrator "Releia o desfecho do capítulo: ele relata incontáveis portas do Dharma e a grande iluminação da sabedoria infinita."
            "Ele recebe a incumbência de visitar um novo mestre em outra cidade.":
                if 2 == 0:
                    narrator "Correto: esses são os resultados explicitamente narrados após o ensinamento do Dharma."
                    return
                else:
                    narrator "Releia o desfecho do capítulo: ele relata incontáveis portas do Dharma e a grande iluminação da sabedoria infinita."

label chapter_56:
    hide screen master_provisional_badge
    scene bg_ch56 with dissolve
    show master_ch56_provisional at master_provisional_portrait with dissolve
    show screen master_provisional_badge
    centered "Capítulo 56 — Samantabhadra and “The Prayer for Completely Good Conduct”"
    centered "Cena 1 — Sinais por todos os mundos"
    narrator "Sudhana chega a este momento após longa dedicação aos kalyāṇamitras e uma aspiração vasta, livre de apego, voltada à onisciência e ao amadurecimento dos seres. Surgem dez sinais: os campos búdicos são purificados, os seres se tornam alegres e benevolentes, e os bodhimaṇḍas recebem adornos. Em seguida aparecem dez luzes: raios, imagens de Budas, joias, flores, perfumes, astros e formas de bodhisattvas. Cada sinal se estende pelo reino dos fenômenos. Ao contemplá-los, Sudhana recebe a oportunidade de ver Samantabhadra e concentra suas faculdades, sem abandonar a diligência."
    speaker_012 "Que minha atenção permaneça voltada à conduta que conduz à onisciência."
    narrator "Os sinais se multiplicam por todos os campos búdicos; a cena anuncia a presença de Samantabhadra."
    centered "Cena 2 — O corpo que contém mundos"
    narrator "Sudhana vê Samantabhadra rodeado por uma assembleia de bodhisattvas. Raios que emergem de seus poros iluminam os mundos e põem fim ao sofrimento; nuvens de flores, perfumes, vestes, joias e seres se manifestam. Sudhana contempla, em cada parte e poro do corpo do mestre, mundos com seus ambientes, seres e Budas, incluindo sucessões passadas e futuras. As visões se estendem às dez direções, sem se confundirem. Ele também ouve as vozes dos seres, os ensinamentos dos Budas e as rodas do Dharma. Dessa experiência surgem dez práticas da perfeição do conhecimento, entre elas servir aos Budas, compreender seus ensinamentos e perceber a conduta de Samantabhadra."
    speaker_012 "Em cada aspecto que contemplo, abrem-se mundos sem medida."
    speaker_008 "Nobre, contempla com clareza a vastidão da conduta e de seus campos de atividade."
    centered "Cena 3 — A bênção e o caminho percorrido"
    narrator "Samantabhadra pousa a mão direita sobre a cabeça de Sudhana. O gesto abre incontáveis portais de samādhi e do Dharma, amplia suas acumulações de conhecimento e o faz apreender mundos e votos. O bodhisattva explica que buscou a mente onisciente por eras incontáveis, servindo aos Tathāgatas, fazendo oferendas e praticando generosidade. Relata ter oferecido bens e, em sua descrição da perseverança, até o próprio corpo, sem abandonar a aspiração ao Dharma. Afirma que cultivou compaixão, protegeu e amadureceu seres, e serviu mestres espirituais. Sua aspiração não se apoiava em raiva, apropriação de um eu ou distinção entre si e os outros."
    speaker_008 "Minha prática se estendeu por eras, sustentada pela aspiração ao Dharma e pelo benefício dos seres."
    speaker_012 "Vejo que a vastidão dessa prática não cabe numa medida comum."
    centered "Cena 4 — Ver, aprender e amadurecer"
    narrator "Samantabhadra explica que a realização de seus corpos do Dharma e da forma dependeu de acumulações, aspiração vasta, sabedoria, grandes votos, compaixão, bênçãos dos Tathāgatas e cuidado dos bons mestres. Diz que seres com raízes de mérito podem ouvi-lo ou vê-lo; ouvir seu nome, vê-lo, tocá-lo ou mesmo encontrá-lo em sonho pode torná-los irreversíveis no caminho à iluminação. Sudhana volta a contemplar o mestre e vê oceanos de campos búdicos em cada poro. Instruído por Samantabhadra, entra nesses mundos e amadurece seres. Sua realização se amplia até igualar a vastidão dos votos e da conduta do bodhisattva."
    speaker_008 "A aspiração e as raízes de mérito sustentam o caminho; dedica a prática ao amadurecimento dos seres."
    speaker_012 "Que eu aprenda a agir sem separar minha busca do benefício de todos."
    centered "Cena 5 — Os gestos da oração"
    narrator "Para esclarecer a extensão de eras e mundos, Samantabhadra compõe a oração de boa conduta. Ela começa com homenagem aos Budas dos três tempos e das dez direções, imaginando cada átomo repleto de Budas. Seguem-se louvores e oferendas, inclusive flores, música, perfumes, luzes e vestes. A oração reconhece ações nocivas feitas por corpo, fala e mente sob desejo, raiva e ignorância; alegra-se com o mérito de seres, praticantes, bodhisattvas e Budas. Pede aos Budas que girem a roda do Dharma e, aos que manifestariam o nirvāṇa, que permaneçam pelo bem dos seres. Por fim, dedica toda virtude à iluminação."
    speaker_008 "Que homenagem, oferenda, confissão, alegria e súplica se unam à dedicação à iluminação."
    speaker_012 "A oração reúne a lembrança dos Budas e o compromisso com todos os seres."
    centered "Cena 6 — Votos sem limite e dedicação"
    narrator "Nos versos seguintes, a oração pede que os campos das dez direções se purifiquem, que os seres tenham felicidade e que a conduta de iluminação seja praticada sem cansaço, em todas as vidas e eras. Expressa votos de ensinar o Dharma nas línguas dos seres, agir sem dano e libertá-los do sofrimento. A aspiração abrange incontáveis Budas, mundos e kalpas, e dedica o mérito para que as orações virtuosas dos seres se realizem. O encerramento dirige-se a Amitābha e a Sukhāvatī e enuncia benefícios para quem tem fé, recita ou ensina a oração, incluindo a aspiração à iluminação. O capítulo conclui com a dedicação da virtude à boa conduta suprema."
    speaker_012 "Que a prática alcance todos os seres, sem limite de tempo ou direção."
    narrator "A oração termina como dedicação: a aspiração de Samantabhadra se volta ao benefício dos seres."
    # Optional authored reflection; branches reconverge by design.
    menu:
        "Ao acompanhar a oração, em qual aspecto você prefere concentrar sua reflexão?"
        "A homenagem e as oferendas":
            narrator "A reflexão destaca como a oração honra os Budas e lhes oferece louvor."
        "A confissão e a alegria pelo mérito":
            narrator "A reflexão reúne reconhecer ações nocivas e alegrar-se com o mérito alheio."
        "A dedicação ao benefício dos seres":
            narrator "A reflexão enfatiza dedicar a virtude à iluminação e ao bem dos seres."
    call quiz_ch56
    menu:
        "Voltar ao índice":
            jump chapter_index
        "Rever a dedicação final":
            jump chapter_56
        "Voltar ao índice":
            jump chapter_index

label quiz_ch56:
    centered "As seis práticas da oração"
    narrator "Escolha a alternativa que corresponde ao conjunto de ações explicitamente reunido nos versos iniciais da oração."
    while True:
        menu:
            "Quais práticas são reunidas na dedicação de virtude em 56.83?"
            "Homenagem, oferenda, confissão, alegria, súplica e pedido para que os Budas permaneçam.":
                if 0 == 0:
                    narrator "Correto: os versos enumeram homenagem, oferenda, confissão, alegria, súplica e pedido para que os Budas permaneçam."
                    return
                else:
                    narrator "Revise as seis ações de 56.83: homenagem, oferenda, confissão, alegria, súplica e pedido para que os Budas permaneçam."
            "Meditação, jejum, peregrinação, silêncio, estudo e retiro.":
                if 1 == 0:
                    narrator "Correto: os versos enumeram homenagem, oferenda, confissão, alegria, súplica e pedido para que os Budas permaneçam."
                    return
                else:
                    narrator "Revise as seis ações de 56.83: homenagem, oferenda, confissão, alegria, súplica e pedido para que os Budas permaneçam."
            "Generosidade, disciplina, paciência, esforço, concentração e sabedoria.":
                if 2 == 0:
                    narrator "Correto: os versos enumeram homenagem, oferenda, confissão, alegria, súplica e pedido para que os Budas permaneçam."
                    return
                else:
                    narrator "Revise as seis ações de 56.83: homenagem, oferenda, confissão, alegria, súplica e pedido para que os Budas permaneçam."
